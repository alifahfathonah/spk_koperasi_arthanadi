<div class="modal-footer" style="border-top: 0px;">
    <button type="button" class="btn btn-danger tombolform" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i>  Batal</button>
    <button type="submit" class="btn btn-success tombolform"><i class="fa fa-check" aria-hidden="true"></i> Perbarui</button>
</div>