<div class="modal fade" id="modalLogout" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" align="center"><strong>PERHATIAN!</strong></h4>
      </div>
      <div class="modal-body">
        <p align="center">Anda yakin keluar dari aplikasi ini?</p>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Tidak</button>
          <a href="{{url('logout')}}" class="btn btn-success">Ya</a>
        </div>
      </div>
    </div>
  </div>
</div>