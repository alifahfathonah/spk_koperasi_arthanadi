<html>
<?php echo $__env->make('themes.login.head_login', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition clBgBody">
<?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="login-box clLoginBox">
    <p><h3 align="center"><?php echo e(config('app.app_alias')); ?></h3></p>
    <h4 align="center" style="padding: 0px 10px 0px 10px"><small><?php echo e(config('app.app_name')); ?></small></h4>
      <div class="login-logo">
        <img src="<?php echo e(url('themes/default/images/logo maarif.png')); ?>" width="200">
      </div>
        <div class="login-box-body">  
            <form action="<?php echo e(url('/auth')); ?>" method="post">
                 <?php echo e(csrf_field()); ?>

                <div class="form-group has-feedback ">
                    <input type="text" name="username" class="form-control" placeholder="Username" required="" autofocus autocomplete="off">
                    <span class="glyphicon glyphicon-user form-control-feedback" style="color: #000"></span>
                </div>
                <div class="form-group has-feedback ">
                    <input type="password" name="password" id="password" class="form-control" placeholder="Password" required="">
                    <span class="glyphicon glyphicon-lock form-control-feedback" style="color: #000"></span>
                </div>
                <div class="row">
                    <div class="col-xs-8">
                               <input type="checkbox" onclick="myFunction()"> <span style="font-size: 12.5px;vertical-align: 2.5;color:#585858">Show Password</span>
                    </div>
                    <!-- /.col -->
                    <div class="col-xs-4">
                        <button type="submit" class="btn btn-primary btn-block btn-flat"> Login</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>
        </div>
    </div>
    <ul class="bg-bubbles">
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
      <li></li>
    </ul>
</body>
</html>

<script>
function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>