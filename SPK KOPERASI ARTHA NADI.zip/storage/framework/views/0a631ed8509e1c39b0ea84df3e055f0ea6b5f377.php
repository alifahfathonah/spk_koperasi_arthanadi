<form action="<?php echo e(route ('kategori_produk.update',[$category_produk->id])); ?>" method="POST" id="formEditKategoriProduk" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

<div class="form-group">
  <input type="hidden" name="id" value="<?php echo e($category_produk->id); ?>">
    <label for="nama">Nama Kategori</label>
    <input type="text" class="form-control" name="txtNama" value="<?php echo e($category_produk->nama_category); ?>">
</div>
<div class="form-group">
           <label>Status</label>
              <select class="form-control" name="txtStatus">
                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k->id); ?>" <?php if($category_produk->status==$k->id): ?> selected <?php endif; ?>><?php echo e($k->nama_status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
                <?php if($errors->has('txtStatus')): ?>
                        <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('txtStatus')); ?></strong>
                        </span>
                    <?php endif; ?>
        </div>
<div class="modal-footer">
    <button type="submit" class="btn btn-primary">Simpan</button>
    <button type="button" class="btn btn-warning" data-dismiss="modal">Batal</button>
</div>
</form>
