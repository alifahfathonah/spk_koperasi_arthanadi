<?php $__env->startSection('content'); ?>
<div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title"><?php echo e($header); ?></h3>
      <div class="box-tools pull-right">
          <div class="btn-group">
              <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown" title="Aksi">
                  <i class="fa fa-bars fa-lg tip" style="color: #3c8dbc"></i> Tindakan</button>
              <ul class="dropdown-menu" role="menu">
                  <li><a href="" data-toggle="modal" data-target="#<?php echo e($idModalTambah); ?>" title="<?php echo e($headerModalTambah); ?>"><i class="fa fa-plus" aria-hidden="true"></i>Tambah Baru</a></li>
              </ul>
          </div>
      </div>
  </div>
<div class="row kotak">
  <div class="box-body">
    <div align="left">          
        <table width="100%" class="table table-hover table-striped" id="<?php echo e($idDataTable); ?>">
          <thead>
            <tr>
              <th width="5%">No</th>
              <th>No Akun</th>
              <th>Nama Akun</th>
              <th>Kategori</th>
              <th>Normal Pos</th>
              
              
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
          
        </tbody>
        </table>
    </div>

<!-- MODAL TAMBAH & EDIT--> 
<?php echo $__env->make('modal.header.modal_create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('akun.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modal.header.modal_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- DataTable -->
<script type="text/javascript">
  $(document).ready(function() {
    var   id_datatables = "<?php echo e($idDataTable); ?>";
          id_modal_edit =  "<?php echo e($idModalEdit); ?>";
          id_load_edit = "<?php echo e($idLoadEdit); ?>";
          table = $('#'+id_datatables).DataTable({
          processing: true,
          serverSide: false,								
          info: true,
          responsive: true,
          ajax: "<?php echo e(url("{$url_datatables}")); ?>",
            language: {
            "loadingRecords": "Memuat...",
            "processing": "<div class='table-loader'>Memuat...<br><span class='loading'></span></div>",
            "lengthMenu": "Tampilkan _MENU_ Per Halaman",
            "zeroRecords": "Tidak ada data ditemukan",
            "info": "Menampilkan halaman _PAGE_ dari _PAGES_ total halaman",
            "infoEmpty": "Tidak ada data yang tersedia",
            "infoFiltered": "(Pencarian dari _MAX_ total data)",
            "search": "Pencarian",
            "paginate": {
                "previous": "Sebelumnya",
                "next": "Berikutnya"
              }
            },
          columns: [
              {
                  data: "id",
                  render: function (data, type, row, meta) {
                      return meta.row + meta.settings._iDisplayStart + 1;
                  }
              },
              { 
										data: "no_akun", 
										render: function ( val, type, row ){
												return val
											}
							},
              { 
										data: "nama_akun", 
										render: function ( val, type, row ){
												return val
											}
							},
              { 
										data: "kategori", 
										render: function ( val, type, row ){
												return val
											}
							},
              // { 
							// 			data: "debet", 
              //       render: function ( val, type, row ){
							// 					return 'Rp' + currency_add(val)
							// 				}
							// },
              // { 
							// 			data: "kredit", 
              //       render: function ( val, type, row ){
							// 					return 'Rp' + currency_add(val)
							// 				}
							// },
              { 
										data: "normal_pos", 
										render: function ( val, type, row ){
                        return val
											}
							},
              { 
										data: "id",
										className: "text-center",
										orderable: false,
										render: function ( val, type, row ){
												var buttons = '<div class="btn-group" role="group">';
													buttons += '<a title=\"Ubah Data Akun\" data-toggle=\"modal\" data-target=\"#'+id_modal_edit+'\" data-id=\"'+val+'\" class=\"btn btn-info btn-xs\"><i class=\"fa fa-pencil\"></i> Edit</a>';
													buttons += "</div>";
												return buttons
											}
									},
          ]
      });
  

   // SHOW MODAL EDIT BARANG
   $(document).on('shown.bs.modal','#'+id_modal_edit, function (e) {
        $('.overlay').css('display','block');
        var id = $(e.relatedTarget).data('id');
        $('#'+id_load_edit).load('akun/'+id+'/edit');
        setTimeout(function() {
                $('.overlay').css('display','none');
        }, 1500);
    });
  } );
  </script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>