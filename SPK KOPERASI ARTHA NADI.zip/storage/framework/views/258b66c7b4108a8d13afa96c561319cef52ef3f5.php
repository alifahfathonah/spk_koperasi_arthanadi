<form action="<?php echo e(route ('obat.update',[$obat->id])); ?>" method="POST" id="formEditObat" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($obat->id); ?>">
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Kode Obat</label>
        <input type="text" class="form-control" name="txtKd_obat" value="<?php echo e($obat->kd_obat); ?>" readonly="">
    </div>
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Nama Obat</label>
        <input type="text" class="form-control" name="txtNama_obat" value="<?php echo e($obat->nama_obat); ?>">
    </div>
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Jenis Obat</label>
        <select name="txtJenis_obat" class="form-control">
            <option value="<?php echo e($obat->jenis_obat); ?>"><?php echo e($obat->jenis_obat); ?></option>
                <?php if($obat->jenis_obat=='Serbuk'): ?>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Tablet'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Pil'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Kapsul'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Kablet'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Larutan'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Suspensi'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Emulsi'): ?>
                 <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Galenik'): ?>
                 <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Ektrak'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Infusa'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Imunoserum'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                 <?php elseif($obat->jenis_obat=='Obat Tetes'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Suppositoria'): ?>
                 <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                 <?php elseif($obat->jenis_obat=='Injeksi'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Cairan">Cairan</option>
                <?php elseif($obat->jenis_obat=='Cairan'): ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <?php else: ?>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
                <?php endif; ?>
        </select>
    </div>
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Kategori Obat</label>
        <select name="txtKategori_obat" class="form-control">
            <option value="<?php echo e($obat->kategori_obat); ?>"><?php echo e($obat->kategori_obat); ?></option>
                <?php if($obat->kategori_obat=='Obat Bebas'): ?>
                    <option value="Obat Bebas Terbatas">Obat Bebas Terbatas</option>
                    <option value="Obat Keras">Obat Keras</option>
                    <option value="Jamu">Jamu</option>
                    <option value="Obat Herbal">Obat Herbal</option>
                    <option value="Fitofarmaka">Fitofarmaka</option>
                <?php elseif($obat->kategori_obat=='Obat Bebas Terbatas'): ?>
                    <option value="Obat Bebas">Obat Bebas</option>
                    <option value="Obat Keras">Obat Keras</option>
                    <option value="Jamu">Jamu</option>
                    <option value="Obat Herbal">Obat Herbal</option>
                    <option value="Fitofarmaka">Fitofarmaka</option>
                <?php elseif($obat->kategori_obat=='Obat Keras'): ?>
                    <option value="Obat Bebas">Obat Bebas</option>
                    <option value="Obat Bebas Terbatas">Obat Bebas Terbatas</option>
                    <option value="Jamu">Jamu</option>
                    <option value="Obat Herbal">Obat Herbal</option>
                    <option value="Fitofarmaka">Fitofarmaka</option>
                <?php elseif($obat->kategori_obat=='Jamu'): ?>
                    <option value="Obat Bebas">Obat Bebas</option>
                    <option value="Obat Bebas Terbatas">Obat Bebas Terbatas</option>
                    <option value="Obat Keras">Obat Keras</option>
                    <option value="Obat Herbal">Obat Herbal</option>
                    <option value="Fitofarmaka">Fitofarmaka</option>
                <?php elseif($obat->kategori_obat=='Obat Herbal'): ?> 
                    <option value="Obat Bebas">Obat Bebas</option>
                    <option value="Obat Bebas Terbatas">Obat Bebas Terbatas</option>
                    <option value="Obat Keras">Obat Keras</option>
                    <option value="Jamu">Jamu</option>
                    <option value="Fitofarmaka">Fitofarmaka</option>
                <?php elseif($obat->kategori_obat=='Fitofarmaka'): ?> 
                    <option value="Obat Bebas">Obat Bebas</option>
                    <option value="Obat Bebas Terbatas">Obat Bebas Terbatas</option>
                    <option value="Obat Keras">Obat Keras</option>
                    <option value="Jamu">Jamu</option>
                    <option value="Obat Herbal">Obat Herbal</option>
                <?php else: ?>
                    <option value="Obat Bebas">Obat Bebas</option>
                    <option value="Obat Bebas Terbatas">Obat Bebas Terbatas</option>
                    <option value="Obat Keras">Obat Keras</option>
                    <option value="Jamu">Jamu</option>
                    <option value="Obat Herbal">Obat Herbal</option>
                    <option value="Fitofarmaka">Fitofarmaka</option>
                <?php endif; ?>
        </select>
    </div>
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Stok</label>
        <input type="number" class="form-control" name="txtStok_obat" value="<?php echo e($obat->stok_obat); ?>" readonly="">
    </div>
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Satuan</label>
        <select name="txtSatuan_obat" class="form-control">
            <option value="<?php echo e($obat->satuan_obat); ?>"><?php echo e($obat->satuan_obat); ?></option>
                <?php if($obat->satuan_obat=='Botol'): ?>
                    <option value="PCS">PCS</option>
                    <option value="Buah">Buah</option>
                <?php elseif($obat->satuan_obat=='PCS'): ?>
                    <option value="Botol">Botol</option>
                    <option value="Buah">Buah</option>
                <?php elseif($obat->satuan_obat=='Buah'): ?>
                    <option value="Botol">Botol</option>
                    <option value="PCS">PCS</option>
                <?php else: ?>
                    <option value="Botol">Botol</option>
                    <option value="PCS">PCS</option>
                    <option value="Buah">Buah</option>
                <?php endif; ?>
          </select>
      </div>
      
<div class="modal-footer">
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
</div>
</form>
