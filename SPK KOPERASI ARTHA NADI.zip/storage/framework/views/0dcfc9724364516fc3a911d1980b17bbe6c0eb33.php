<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(@$title); ?> <?php echo e(config('app.app_name')); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="shortcut icon" href="<?php echo e(url('themes/default/images/favicon.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('themes/default/css/style_report.css')); ?>">
</head>
<body>
  <table style="border:none;">
    <tr>
      <td width="100px" style="border:none;"><img src="<?php echo e(url('themes/login/images/logo.png')); ?>" alt="" style="width: 100px;text-align:center"><br></td>
      <td style="border:none;">
        <h4 align="center">
          <?php echo e(config('app.app_name')); ?> <?php echo e(config('app.area')); ?> <br>
          Alamat : <?php echo e(config('app.address')); ?> <br>Telepon : <?php echo e(config('app.phone')); ?>

        </h4>
      </td>
    </tr>
  </table>
  <hr>
    <h5 align="center">
      <?php echo e(@$title); ?> <br> SMP WIDYA SUARA SUKAWATI <br>
      Tahun Ajaran : <?php echo e($params->periode); ?>

    </h5>
    <div class="container">
        <table width="100%">
          <thead>
            <tr>
              <th style="text-align: center!important">No</th>
              <th>Kode Akun</th>
              <th>Keterangan</th>
              <th>Anggaran</th>
              <th>Pengeluaran</th>
            </tr>
          </thead>
          <tbody>
            <?php  $no = 1;$angaran = 0;$pengeluaran = 0; ?>
              <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $angaran += $row['anggaran']; $pengeluaran += $row['pengeluaran'];  ?>
                <tr>
                  <td align="center"><?php echo e($no++); ?></td>
                  <td><?php echo e($row['kode_akun']); ?></td>
                  <td><?php echo e($row['keterangan']); ?></td>
                  <td align="right">Rp. <?php echo e(number_format($row['anggaran'])); ?></td>
                  <td align="right">Rp. <?php echo e(number_format($row['pengeluaran'])); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
              <td align="right" colspan="3"><strong>TOTAL</strong></td>
              <td align="right"><strong>Rp. <?php echo e(number_format($angaran)); ?></strong></td>
              <td align="right"><strong>Rp. <?php echo e(number_format($pengeluaran)); ?></strong></td>
            </tr>
          </tfoot>

        </table>
      </div>
    <p style="z-index: 100;position: absolute;bottom: 0px;float: right;font-size: 11px;"><i>Tanggal Cetak : <?php echo date('d-m-Y') ?></i></p>
</body>
</html>