<!DOCTYPE html>
<html>
	<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition skin-blue sidebar-collapse sidebar-mini">
	<div class="wrapper">
		<?php echo $__env->make('layouts.top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<aside class="main-sidebar">
			<?php echo $__env->make('layouts.left', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</aside>
		<div class="content-wrapper">
			<section class="content-header">
				<div>
     <!-- -->
      </div>
		      <?php echo $__env->yieldContent('bread'); ?>
   			</section>
   			<section class="content container-fluid">
  
		      <?php echo $__env->yieldContent('content'); ?>
           <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		    </section>
		</div>
		<footer class="main-footer">
        <?php if(Request::is('Dashboard')=='active'): ?>
    		<marquee>
          <strong> <!-- Copyright &copy; 2019 --> SIPETUS |</strong> Rumah Sakit Umum Bintang | Jl. Ngurah Rai No. 10 Klungkung - Bali <i class="fa fa-map-marker" aria-hidden="true"></i>
        </marquee>
        <?php else: ?>
          <strong> <!-- Copyright &copy; 2019 --> SIPETUS |</strong>  Rumah Sakit Umum Bintang <i class="fa fa-hospital-o" aria-hidden="true"></i> | Jl. Ngurah Rai No. 10 Klungkung - Bali <i class="fa fa-map-marker" aria-hidden="true"></i>
        <?php endif; ?>

  		</footer>
  		<?php echo $__env->make('layouts.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</div>
	<?php echo $__env->make('layouts.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?><?php echo $__env->yieldPushContent('scripts'); ?>

	<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>