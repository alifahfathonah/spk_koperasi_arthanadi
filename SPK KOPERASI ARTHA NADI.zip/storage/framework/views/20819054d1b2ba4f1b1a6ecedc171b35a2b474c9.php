<form action="<?php echo e(route ('kepala_sekolah.update',[$kepalaSekolah->id])); ?>" method="POST" id="formEditKepalaSekolah" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($kepalaSekolah->id); ?>">
   
<div class="form-group">
    <label for="name" class="col-sm-2 control-label tengah2">ID</label>
    <div class="col-md-10">
    <input type="text" class="form-control" name="txtIdKepalaSekolah" value="<?php echo e($kepalaSekolah->user_id); ?>" readonly="">
</div>
</div>
<div class="form-group">
    <label for="name" class="col-sm-2 control-label tengah2">Nama Pegawai</label>
    <div class="col-md-10">
    <input type="text" class="form-control" name="txtNamaPegawai" value="<?php echo e($kepalaSekolah->nama_pegawai); ?>" required="">
</div>
</div>
<div class="form-group">
    <label for="name" class="col-sm-2 control-label tengah2">Jabatan</label>
    <div class="col-md-10">
    <select name="txtJabatan" class="form-control" required="">
        <option value="<?php echo e($kepalaSekolah->jabatan); ?>"><?php echo e($kepalaSekolah->jabatan); ?></option>
    </select>
</div>
</div>
<div class="form-group">
        <label for="name" class="col-sm-2 control-label tengah2">Username</label>
        <div class="col-md-10">
        <input type="text" class="form-control" name="txtUsername" value="<?php echo e($kepalaSekolah->username); ?>" required="">
    </div>
</div>
<div class="form-group">
        <label for="name" class="col-sm-2 control-label tengah2">Password</label>
        <div class="col-md-10">
        <input type="password" class="form-control" name="txtPassword" value="<?php echo e($kepalaSekolah->password); ?>"  required="">
    </div>
</div>
<div class="form-group">
    <label for="name" class="col-sm-2 control-label tengah2">Status</label>
    <div class="col-md-10">
    <select name="txtStatus" class="form-control" required="">
        <option value="<?php echo e($kepalaSekolah->status); ?>"><?php echo e($kepalaSekolah->status); ?></option>
            <?php if($kepalaSekolah->status=='Aktif'): ?>
              <option value="Tidak Aktif">Tidak Aktif</option>
            <?php else: ?>
              <option value="Aktif">Aktif</option>
            <?php endif; ?>
    </select>
</div>
</div>
<div class="form-group">
        <label for="exampleInputFile" class="col-sm-2 control-label tengah2">Foto</label>
        <div class="col-md-10">
        <img src="<?php echo e(asset('public/image/foto_staff/'.$kepalaSekolah->foto)); ?>" id="profile-img-tag2" style="width: 100px;">
    </div>
</div>
<div class="form-group">
        <label for="exampleInputFile" class="col-sm-2 control-label tengah2">Ganti Foto</label><br>
        <div class="col-md-10">
        <input type="file" name="txtFoto" id="profile-img2" style="padding-top: 10px;padding-left: 3px;">
        </div>
</div>
<div class="modal-footer" style="border-top: 0px;">
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
</div>
</form>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag2').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img2").change(function(){
        readURL(this);
    });
</script>