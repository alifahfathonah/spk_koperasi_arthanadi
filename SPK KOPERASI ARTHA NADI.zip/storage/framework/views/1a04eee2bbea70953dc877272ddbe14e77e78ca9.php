 <?php 
$dasboard1="Client";
$small="Halaman Client";
 ?>

<?php $__env->startSection('content'); ?>
 <!-- Button trigger modal -->
       <div align="left">
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalTambahClient"><span class="fa fa-plus"></span>
  Tambah
</button>
</div><br>
<table border="1" width="100%" class="table table-bordered" id="tbclient">
	<thead>
		<tr>
			<th>No</th>
			<th>Nama Client</th>
			<th>Alamat</th>
			<th>Telp</th>
      <th>Keterangan</th>
			<th>Aksi</th>
		</tr>
	</thead>
	<tbody>
	
</tbody>

</table>



<!-- Modal Tambah Client-->
<div class="modal fade" id="modalTambahClient" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" align="center">Tambah Data Client</h4>
      </div>
      <div class="modal-body">
      	<form id="tambahclient" method="POST" action="<?php echo e(route('client.store')); ?>" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>

        <div class="form-group">
        	<label for="nama_client">Nama Client</label>
    		<input type="text" class="form-control" name="txtNama">
        </div>
       <div class="form-group">
          <label for="alamat">Alamat</label>
          <textarea name="txtAlamat" id="" cols="20" rows="3" class="form-control"></textarea>
        </div>
        <div class="form-group">
        	<label for="nama">Telepon</label>
    		<input type="text" class="form-control" name="txtTelp">
        </div>
        <div class="form-group">
        	<label for="image">Image</label>
          <input type="file" name="txtImage" id="profile-img" class="form-control">
          <img src="" id="profile-img-tag" width="200px" />

         
        </div>

        <div class="form-group">
          <label for="ket">Keterangan</label>
          <textarea name="txtKet" id="" cols="30" rows="10" class="form-control"></textarea>
        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-warning" data-dismiss="modal">Batal</button>
        </div>
         
      </form>
      </div>
       
     
    </div>
  </div>
</div>

<!-- modal detail client -->
<div class="modal fade" id="modalDetailClient" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" align="center"><strong>Detail Data Client</strong></h4>
      </div>
      <div class="modal-body" id="loadDetailClient">
        
      
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>

<!-- modal edit client -->
<div class="modal fade" id="modalEditClient" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" align="center"><strong>Edit Data Client</strong></h4>
      </div>
      <div class="modal-body" id="loadEditClient">
        
      
      </div>

    </div>
  </div>
</div>

<!-- modal hapus client -->
<div class="modal" tabindex="-1" role="dialog" id="modalHapusClient">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title">Warning !</h5>
      </div>

      <div class="modal-body" id="loadHapusClient">
        
      </div>
      
    </div>
  </div>
</div>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img").change(function(){
        readURL(this);
    });
</script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>