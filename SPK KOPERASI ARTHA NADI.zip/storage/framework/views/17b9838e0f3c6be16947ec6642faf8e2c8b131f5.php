<?php $__env->startSection('content'); ?>
<div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title"><?php echo e($header); ?></h3>
  </div>
    <div class="row kotak">
      <div class="box-body">
        <div align="left">
          <form  method="POST" action="<?php echo e(route('pemesanan_tour.store')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>

            <div class="col-md-6">
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">No Faktur</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" name="txtBuktiPemesanan" value="<?php echo e($noFaktur); ?>" placeholder="Bukti Pemesanan" autofocus autocomplete="off" required="" readonly>
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">Pelanggan</label>
                <div class="col-md-9">
                <div class="input-group mb-3">
                  <input type="hidden" id="ID_Pelanggan" name="txtIDPelanggan" class="form-control" placeholder="Nama Pelanggan" aria-describedby="basic-addon2" readonly>
                  <input type="text" id="Nama_Pelanggan" name="txtNamaPelanggan" class="form-control" placeholder="Nama Pelanggan" readonly style="background-color: #fff">
                  <div class="input-group-append">
                  <a data-toggle="modal" data-target="#ModalPelanggan" title="" class="btn btn-info tip" data-original-title=""><i class="fa fa-gear"></i></a>
                  </div>
                </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">Tanggal Transaksi</label>
                <div class="col-md-9">
                  <input type="date" class="form-control" name="txtTanggalPesan" value="<?php echo e(@$tgl_faktur_penjualan); ?>" placeholder="Tanggal Pesan" autofocus autocomplete="off" required="">
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">User</label>
                <div class="col-md-9">
                  <input type="user" class="form-control" name="txtTanggalPesan" value="<?php echo e(@$user); ?>" placeholder="Tanggal Pesan" autofocus autocomplete="off" required="">
                </div>
              </div>
            </div>
            
            <?php echo $__env->make('penjualan.detail.tables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('modal.footer.modal_footer_tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </form>
        </div>
      </div>
    </div>
</div>    
<?php echo $__env->make('penjualan.lookup.pelanggan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="modal fade" id="ModalBarang" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h5 class="modal-title" id="myModalLabel"><b>Lookup Data Barang</b></h5>
			</div>
			<div class="modal-body" id="loadBarang">

			</div>
		</div>
	</div>
</div>

<script>
  $(document).ready(function(){
     $(document).on('shown.bs.modal','#ModalBarang', function (e) {
        $('.overlay').css('display','block');
        $('#loadBarang').load('lookup_barang');
        setTimeout(function() {
                $('.overlay').css('display','none');
        }, 1500);
    });
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>