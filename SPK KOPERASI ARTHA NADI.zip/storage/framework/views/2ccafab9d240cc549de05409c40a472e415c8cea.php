 <?php 
 $title="Proses SPK | ";
 $header="PROSES SPK";
 ?>

<?php $__env->startSection('content'); ?>
<div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title"><?php echo e($header); ?></h3>
      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
      </div>
  </div>
<div class="row kotak">
<div class="box-body">
<div align="left">

<?php if($hitungAlternatifLokasi==0): ?>
  Tidak ada data alternatif lokasi, silahkan menghubungi admin!
<?php else: ?>
<form  method="POST" action="<?php echo e(url('/proses-spk/hasil-spk')); ?>" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

<table border="1" width="100%" class="table table-bordered table-hover" id="">
	<thead>
		<tr>
      <th><center>Pilih</center></th>
      <th>Nama Kecamatan</th>
      <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th><?php echo e($k->nama_kriteria); ?></th>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tr>
	</thead>
<tbody>
    <?php $__currentLoopData = $alternatifLokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td align="center">
        <input type="checkbox" name="txtAlternatifLokasi[]" value="<?php echo e($b->id); ?>">
      </td>
      <td><?php echo e($b->nama_kecamatan); ?></td>
        <?php $__currentLoopData = $detailAlternatifLokasi->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($b->kode_alternatif_lokasi==$c->kode_alternatif_lokasi): ?>
            <td><?php echo e($c->keterangan); ?></td>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>


</div>
<div align="right">
     <button type="submit" class="btn btn-success" data-toggle="modal" title="Proses SPK">Proses SPK  <i class="fa fa-chevron-right" aria-hidden="true"></i><i class="fa fa-chevron-right" aria-hidden="true"></i><i class="fa fa-chevron-right" aria-hidden="true"></i></button> 
</div>
</form>

<?php endif; ?>


<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>