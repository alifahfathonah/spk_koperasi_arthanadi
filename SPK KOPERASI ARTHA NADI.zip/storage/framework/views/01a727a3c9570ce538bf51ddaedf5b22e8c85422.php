 <?php 
 $title="Surat Masuk Belum Disposisi |";
 ?>
<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">DAFTAR SURAT MASUK BELUM DISPOSISI</h3>

              <div class="box-tools pull-right">
              </div>
            </div>   
<div class="row kotak">
<div align="left">
<?php if($count<=0): ?>
  <h4 align="center">Tidak ada surat masuk yang belum disposisi!</h4>
<?php else: ?>
<?php if((Session::get('user_tipe')=='Admin')): ?>
<!-- <a href="<?php echo e(route('surat_masuk.create')); ?>" class="btn btn-success">
  Tambah Data</a>
</div><br> -->
<?php else: ?>

<?php endif; ?>
<table border="1" width="100%" class="table table-bordered table-hover" id="dataSuratMasuk">
	<thead>
		<tr>
			<th width="3%">No</th>
            <th>Tanggal Terima</th>
            <th>Kode</th>
            <th>No Surat</th>
            <th>Asal Surat</th>
            <th>Perihal Surat</th>
            <th>Tanggal Surat</th>
            <th>Keterangan</th>
            <th>Disposisi</th>
            <th>File</th>       
            <th>Tindak Lanjut</th>
            <?php if((Session::get('user_tipe')=='Wakil Kepala')): ?>
            <th>Aksi</th>
            <?php else: ?>
            <th>Aksi</th>
            <?php endif; ?>
        </tr>
	</thead>
	<tbody>
	 <?php $no=1; ?>
    <?php $__currentLoopData = $suratMasuk->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?> </td>
      <td><?php echo e(Carbon\Carbon::parse($p->tanggal_terima)->formatLocalized('%d %b %Y')); ?></td>
      <td><?php echo e($p->kode_surat); ?></td>
      <td><?php echo e($p->no_surat_masuk); ?></td>
      <td><?php echo e($p->asal_surat_masuk); ?></td>
      <td><?php echo e($p->perihal_surat_masuk); ?></td>
      <td><?php echo e(Carbon\Carbon::parse($p->tanggal_surat_masuk)->formatLocalized('%d %b %Y')); ?></td>
      <td><?php echo e($p->keterangan_surat_masuk); ?></td>
      <td align="center">
        <?php if($p->disposisi=='1'): ?>
            <input type="checkbox" name="txtDisposisi" checked="" onclick="return false;">
        <?php else: ?>
            <input type="checkbox" name="txtDisposisi" readonly="" onclick="return false;">
        <?php endif; ?>
        </td>
      <td>
        <a href="<?php echo e(url('public/image/scan_surat/'.$p->file)); ?>" target="blank"><img src="<?php echo e(url('public/image/scan_surat/'.$p->file)); ?>" width="50px" height="auto" id="zoom1"></a>
    </td>
      <td><?php echo e($p->tindak_lanjut2); ?></td>
      <?php if((Session::get('user_tipe')=='Admin')): ?>
      <td>
           <a title="Ubah Surat Masuk" href="<?php echo e(url('surat_masuk/edit/'.$p->id)); ?>" data-toggle="modal"><span class="btn btn-warning  btn-sm" style="margin: 1px;"><span class="fa fa-edit"></span></span></a>
            <a><span class="btn btn-warning  btn-sm" style="margin: 1px;" 
              <?php if($p->status_dikirim=='0' AND $p->tindak_lanjut!='0' AND $p->disposisi!='0'): ?> data-target='#modalKirimSuratMasuk' data-toggle='modal'  data-id='<?php echo $p->id; ?>' title='Kirim Surat'
              <?php elseif($p->tindak_lanjut=='0' AND $p->disposisi=='0'): ?> data-target='#' disabled  title='Belum Disposisi Kepala Sekolah' data-toggle='modal' 
              <?php else: ?> data-target='#' disabled  title='Sudah Terkirim' data-toggle='modal'

              <?php endif; ?>><span class="fa fa-send"></span></span></a>
            <a title="Cetak Surat Masuk" data-toggle="modal" href="<?php echo e(url('surat_masuk/lembar_disposisi/'.$p->id)); ?>"><span class="btn btn-warning  btn-sm" style="margin: 1px;"><span class="glyphicon glyphicon-print"></span></span></a>
      </td>
      <?php elseif((Session::get('user_tipe')=='Kepala Sekolah')): ?>
      <td>
            <?php if($p->disposisi=='1'): ?>
              <a title="Batal Disposisi" data-toggle="modal" data-target="#modalBatalDisposisi" data-id="<?php echo $p->id; ?>" ><span class="btn btn-danger  btn-sm" style="margin: 1px;"><span class="glyphicon glyphicon-remove"></span></span></a>
            <?php else: ?>
              <a title="Persetujuan Disposisi" data-toggle="modal" data-target="#modalPersetujuanDisposisi" data-id="<?php echo $p->id; ?>"><span class="btn btn-primary  btn-sm" style="margin: 1px;"><span class="glyphicon glyphicon-ok"></span></span></a>
            <?php endif; ?> 
      </td>
      <?php else: ?>
      <td>
          <?php if($p->sudah_dibaca=='1'): ?>
            <a title="Sudah dibaca" data-toggle="modal" data-target="#" data-id=""><span class="btn btn-success  btn-sm" style="margin: 1px;"><span class="glyphicon glyphicon-ok"></span></span></a>
          <?php else: ?>
            <a title="Tandai sudah dibaca" data-toggle="modal" data-target="#modalSudahDibaca" data-id="<?php echo $p->id; ?>"><span class="btn btn-primary  btn-sm" style="margin: 1px;"><span class="glyphicon glyphicon-ok"></span></span></a>
          <?php endif; ?>
      </td>
      <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

</table>
<?php endif; ?>
</div>


<!-- MODAL KIRIM SURAT -->
<div class="modal fade" id="modalKirimSuratMasuk" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>WAKA</strong></h5>
      </div>
      <div class="modal-body" id="loadKirimSuratMasuk">

      </div>

    </div>
  </div>
</div>

<div class="modal fade" id="modalPersetujuanDisposisi" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>PERSETUJUAN DISPOSISI</strong></h5>
      </div>
      <div class="modal-body" id="loadPersetujuanDisposisi">
            
    </div>
  </div>
  </div>
</div>

<div class="modal fade" id="modalBatalDisposisi" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>PERHATIAN!</strong></h5>
      </div>
      <div class="modal-body" id="loadBatalDisposisi">
            
    </div>
  </div>
  </div>
</div>

<div class="modal fade" id="modalSudahDibaca" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>PERHATIAN!</strong></h5>
      </div>
      <div class="modal-body" id="loadSudahDibaca">
            
    </div>
  </div>
  </div>
</div>


<!-- DATATABLES -->
<script type="text/javascript">
$(document).ready(function() {
    var t = $('#dataSuratMasuk').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0,
        } ],
        "order": [[ 1, 'desc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );

</script>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>