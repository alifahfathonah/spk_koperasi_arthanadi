<form  method="POST" action="<?php echo e(url($submit_url)); ?>" class="form-horizontal" name="form_crud">
  <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label class="col-lg-3 control-label">ID Anggota *</label>
    <div class="col-lg-9">
      <input type="text" class="form-control" name="f[id_anggota]" id="id_anggota" value="<?php echo e(@$item->id_anggota); ?>" placeholder="ID Anggota" required="" readonly>
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Nama Anggota *</label>
    <div class="col-lg-9">
      <input type="text" class="form-control" name="f[nama_anggota]" id="nama_anggota" value="<?php echo e(@$item->nama_anggota); ?>" placeholder="Nama Anggota" required="">
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Tanggal Masuk *</label>
    <div class="col-lg-9">
      <input type="date" name="f[tanggal_masuk]" id="tanggal_masuk" class="form-control" placeholder="Tanggal Masuk" value="<?php echo e(@$item->tanggal_masuk); ?>">
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Tanggal Lahir *</label>
    <div class="col-lg-9">
      <input type="date" name="f[tanggal_lahir]" id="tanggal_lahir" class="form-control" placeholder="Tanggal Lahir" value="<?php echo e(@$item->tanggal_lahir); ?>">
    </div>
  </div>
  <div class="form-group">
      <label class="col-lg-3 control-label">Pekerjaan *</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="f[pekerjaan]" id="pekerjaan" value="<?php echo e(@$item->pekerjaan); ?>" placeholder="Pekerjaan" required="">
      </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Agama *</label>
    <div class="col-lg-9">
      <select name="f[agama]" class="form-control" required="" id="agama">
        <option value="" disabled="" selected="" hidden="">-- Pilih --</option>
        <?php foreach(@$option_agama as $dt): ?>
          <option value="<?php echo @$dt['id'] ?>" <?= @$dt['id'] == @$item->agama ? 'selected': null ?>><?php echo @$dt['desc'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Alamat *</label>
    <div class="col-lg-9">
      <textarea name="f[alamat]" id="alamat" cols="30" rows="2" class="form-control" required><?php echo e(@$item->alamat); ?></textarea>
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Telepon *</label>
    <div class="col-lg-9">
      <input type="text" name="f[telepon]" id="telepon" class="form-control" placeholder="Telepon" value="<?php echo e(@$item->telepon); ?>" required="">
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Username *</label>
    <div class="col-lg-9">
      <input type="text" name="u[username]" id="username" class="form-control" placeholder="Username" value="<?php echo e(@$item->username); ?>" required="">
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Password *</label>
    <div class="col-lg-9">
      <input type="password" name="u[password]" id="password" class="form-control" placeholder="Password" value="<?php echo e(@$item->password); ?>" required="">
    </div>
  </div>
  <div class="form-group">
      <div class="col-lg-offset-3 col-lg-9">
        <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo e(__('global.label_close')); ?></button>
        <button id="submit_form" type="submit" class="btn btn-success btn-save"><?php if($is_edit): ?> <?php echo e(__('global.label_update')); ?> <?php else: ?> <?php echo e(__('global.label_save')); ?> <?php endif; ?> <i class="fas fa-spinner fa-spin spinner" style="display: none"></i></button> 
      </div>
  </div>
</form>
      

<script type="text/javascript">
  $('form[name="form_crud"]').on('submit',function(e) {
    e.preventDefault();

    $('.btn-save').addClass('disabled', true);
    $(".spinner").css("display", "");

    var data_post = new FormData($(this)[0]);
    $.ajax({
        url: $(this).prop('action'),
        type: 'POST',              
        data: data_post,
        contentType : false,
        processData : false,
        success: function(response, status, xhr)
        {
          if( response.status == "error"){
              $.alert_warning(response.message);
              $('.btn-save').removeClass('disabled', true);
              $(".spinner").css("display", "none");
              return false
          }
            
          $.alert_success(response.message);
              setTimeout(function(){
                document.location.href = "<?php echo e(url("$nameroutes")); ?>";        
              }, 500);  
          },
        error: function(error)
        {
          $.alert_error(error);
          $('.btn-save').removeClass('disabled', true);
          $(".spinner").css("display", "none");
          return false
        }
    });
});
</script>