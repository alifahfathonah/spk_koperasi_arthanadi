 <?php 
   $title="Register Pasien |";
   $header="DATA REGISTER PASIEN";
   $headerModalTambah="TAMBAH DATA REGISTER PASIEN";
   $headerModalEdit="EDIT DATA REGISTER PASIEN";
   $idModalTambah="modalTambahRegisterPasien";
   $idModalEdit="modalEditRegisterPasien";
   $idLoadEdit="loadEditRegisterPasien";
   $idDataTable="dataRegisterPasien";
   $modalImport="importExcel";
 ?>

<?php $__env->startSection('content'); ?>  
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modal.modal_import', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
 
<!-- modal kosongkan data -->
<div class="modal fade" id="modalKosongkanData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>PERHATIAN!</strong></h5>
      </div>
      <div class="modal-body" id="loadKosongkanData">
        
      
      </div>
    </div>
  </div>
</div>


  <!-- modal detail regsiter pasien-->
<div class="modal fade" id="modalDetailRegisterPasien" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
  <div class="modal-dialog modal-lg" role="document" >
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>DETAIL DATA REGISTER PASIEN</strong></h5>
      </div>
      <div class="modal-body" id="loadDetailRegisterPasien">
      
      </div>
    </div>
  </div>
</div>

 
    <table border="1" width="100%" class="table table-bordered table-hover" id="dataRegisterPasien">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Pasien</th>
          <th>NRM</th>
          <th>Jenis Kelamin</th>
          <th>Tipe Pasien</th>
          <th>Nama Customer</th>
          <th>Kecamatan</th>
          <th>Usia</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>

      </tbody>
    </table>
  </div>
</div>
 
</div>

<!-- DataTable -->
<script type="text/javascript">
$(document).ready(function() {
    var id = $(this).attr("id"); 
    var table = $('#dataRegisterPasien').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(url('apiDataPasien')); ?>?id="+ id,
        language: {
        "loadingRecords": "Memuat...",
        "processing": "<div class='table-loader'>Memuat...<br><span class='loading'></span></div>",
        },
        columns: [
            {data: 'no', name: 'no'},
            {data: 'nama_pasien', name: 'nama_pasien'},
            {data: 'nrm', name: 'nrm'},
            {data: 'jenis_kelamin', name: 'jenis_kelamin'},
            {data: 'tipe_pasien', name: 'tipe_pasien'},
            {data: 'nama_customer', name: 'nama_customer'},
            {data: 'kecamatan', name: 'kecamatan'},
            {data: 'usia', name: 'usia'},
            {data: 'action', name: 'action', orderable: false, searchable: false},
        ]
    });

} );
</script>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>