<!-- kode otomastis -->
<?php
// koneksi ke mysql
include ('public/config/config.php');

// membaca kode barang terbesar
$query = "SELECT max(kd_rekam_medis) as maxKode FROM tb_rekam_medis";
$hasil = mysqli_query($conn,$query);
$data  = mysqli_fetch_array($hasil);
$KodeObatMasuk = $data['maxKode'];

$noUrut = (int) substr($KodeObatMasuk, 3, 3);

// bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
$noUrut++;

$char = "KRM";
$newID = $char . sprintf("%03s", $noUrut);
?>
<form action="<?php echo e(route ('kunjungan.update',[$kunjungan->id])); ?>" method="POST" id="formEditKunjungan" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($kunjungan->id); ?>">
          <table class="table">
            <tr>
              <td>
                <label for="name" class="cols-sm-2 control-label">Tanggal Kunjungan</label>
                <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-calendar" aria-hidden="true"></i></span>
                  <input type="text" class="form-control" name="txtTgl_periksa" readonly="" required="" value="<?php echo e(Carbon\Carbon::parse($kunjungan->tgl_periksa)->formatLocalized('%A, %d %B %Y')); ?>" style="background-color: #fff"> 
                  <input type="hidden" class="form-control" name="txtKd_rekammedis" required="" style="background-color: #fff"  value="<?php echo e($newID); ?>" readonly="">     
                </div>
              </div>
            </td>
              <td>
                 <label for="name" class="cols-sm-2 control-label">Dokter</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
                 <input type="text" class="form-control" name="txtNamaPegawai" value="<?php echo e(Session::get('nama')); ?>" required="" style="background-color: #fff" readonly="">
                 <input type="hidden" class="form-control" name="txtIdPegawai" value="<?php echo e(Session::get('id_pegawai')); ?>" required="" style="background-color: #fff" readonly="">

                      
                        
                </div>
              </div>

              </td>
              </tr>
              <tr>
                <td>
                  <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($p->id==$kunjungan->kd_pasien): ?>

                  <label for="name" class="cols-sm-2 control-label">Pasien</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
                     <input type="text" class="form-control" name="txtPasien" value="<?php echo e($p->nama_pasien); ?>" style="background-color: #fff" readonly="" required="">
                       
                </div>
              </div>
                </td>
                <td>
                   <label for="name" class="cols-sm-2 control-label">Alergi</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-medkit" aria-hidden="true"></i></span>
                     <input type="text" class="form-control" name="txtAlergi" value="<?php echo e($p->alergi); ?>" required="" style="background-color: #fff" readonly="">
                        
                </div>
              </div>
              <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
              </tr>
            <tr>
              <td>
                <label for="name" class="cols-sm-2 control-label">Keluhan</label>
              <div class="cols-sm-10">
                <div class="input-group">
                    <textarea class="form-control" name="txtKeluhan" required="" style="background-color: #fff" cols="40" rows="4" readonly=""><?php echo e($kunjungan->keluhan); ?></textarea> 
                       
                </div>
              </div>
              
              </td>
              <td>
                 <label for="name" class="cols-sm-2 control-label">Diagnosa</label>
              <div class="cols-sm-10">
                <div class="input-group">
                     <textarea class="form-control" name="txtDiagnosa" required="" cols="40" rows="4"><?php echo e($kunjungan->diagnosa); ?></textarea> 
                        
                </div>
              </div>
              </td>
            </tr>
             <tr>
              <td>
                <label for="name" class="cols-sm-2 control-label">Tindakan</label>
              <div class="cols-sm-10">
                <div class="input-group">
                    <textarea class="form-control" name="txtTindakan" required="" cols="40" rows="4"><?php echo e($kunjungan->tindakan); ?></textarea> 
                       
                </div>
              </div>
              
              </td>
              <td>
                 <label for="name" class="cols-sm-2 control-label">Penyakit</label>
              <div class="cols-sm-10">
                <div class="input-group">
                     <textarea class="form-control" name="txtPenyakit" required="" cols="40" rows="4"><?php echo e($kunjungan->penyakit); ?></textarea> 
                        
                </div>
              </div>
              </td>
            </tr>
          </table>
         
         
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Perbarui</button>
          <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
        </div>
      </form>