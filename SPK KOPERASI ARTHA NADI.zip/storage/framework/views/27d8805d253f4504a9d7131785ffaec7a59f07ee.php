<?php $__env->startSection('breadcrumb'); ?>  
  <h1>
    <?php echo e(@$title); ?>

  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Master</a></li>
    <li class="active"><?php echo e(@$title); ?></li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
    <div class="box">
      <div class="box-header">
        <h3 class="box-title"><?php echo e(@$title); ?></h3>
        <div class="box-tools pull-right">
          <div class="btn-group">
            <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
            Tindakan <i class="fa fa-wrench"></i></button>
            <ul class="dropdown-menu" role="menu">
              <li><a href="" id="modalCreate"><i class="fa fa-plus" aria-hidden="true"></i> Tambah Baru</a></li>
            </ul>
          </div>
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
          </button>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <table class="table table-striped table-bordered table-hover" id="<?php echo e($idDatatables); ?>" width="100%">   
            <thead>
              <tr>
                <th class="no-sort">No</th>
                <th>ID Pengeluaran</th>
                <th>Tanggal</th>
                <th>Akun</th>
                <th>Keterangan</th>
                <th>Nominal</th>
                <th>Status</th>
                <th class="no-sort"><i class="fa fa-cog" aria-hidden="true"></i></th>
              </tr>
            </thead>
            <tbody>
            
          </tbody>
          </table>
      </div>
    </div>

<!-- DataTable -->
<script type="text/javascript">
    let lookup = {
      lookup_modal_create: function() {
          $('#modalCreate').on( "click", function(e){
            e.preventDefault();
            var _prop= {
              _this : $( this ),
              remote : "<?php echo e(url("$nameroutes")); ?>/create",
              size : 'modal-lg',
              title : "<?= @$headerModalTambah ?>",
            }
            ajax_modal.show(_prop);											
          });  
        },
    };

    var id_datatables = "<?php echo e($idDatatables); ?>";

      _datatables_show = {
        dt_datatables:function(){
        var _this = $("#"+id_datatables);
            _datatable = _this.DataTable({									
							ajax: "<?php echo e(url("{$urlDatatables}")); ?>",
              columns: [
                          {
                              data: "id",
                              render: function (data, type, row, meta) {
                                  return meta.row + meta.settings._iDisplayStart + 1;
                              }
                          },
                          { 
                                data: "id_pengeluaran", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "tanggal", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "nama_akun", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "keterangan", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "nominal", 
                                render: function ( val, type, row ){
                                    return mask_number.currency_add(val)
                                  }
                          },
                          { 
                              data: "status_batal", 
                                render: function ( val, type, row ){
                                    var button_success = `<label class="label label-danger">Dibatalkan</label>`;
                                        button_danger  = `<label class="label label-success">Aktif</label>`;

                                        return (val == 1) ? button_success : button_danger
                                  }
                          },
                          { 
                                data: "id",
                                width: '15%',
                                className: "text-center",
                                render: function ( val, type, row ){
                                    var buttons = '<div class="btn-group" role="group">';
                                    if(row.status_batal == 1){
                                      buttons += '<a class=\"btn btn-danger btn-xs\" disabled><i class=\"fa fa-ban\"></i> Batal</a>';    
                                    }else{
                                      buttons += '<a class=\"btn btn-danger btn-xs modalCancel\"><i class=\"fa fa-ban\"></i> Batal</a>';  
                                    }
                                    buttons += "</div>";
                                    return buttons
                                  }
                              },
                      ],
                      createdRow: function ( row, data, index ){		
                        $( row ).on( "click", ".modalCancel",  function(e){
                            e.preventDefault();
                            var id = data.id;
                            var _prop= {
                                _this : $( this ),
                                remote : "<?php echo e(url("$nameroutes")); ?>/cancel/" + id,
                                size : 'modal-sm',
                                title : "Konfirmasi!",
                            }
                            ajax_modal.show(_prop);											
                        })

                      }
                                                  
                  });
							
                  return _this;
				}

			}
  
$(document).ready(function() {
  _datatables_show.dt_datatables();
  lookup.lookup_modal_create();
});
  </script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('themes.AdminLTE.layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>