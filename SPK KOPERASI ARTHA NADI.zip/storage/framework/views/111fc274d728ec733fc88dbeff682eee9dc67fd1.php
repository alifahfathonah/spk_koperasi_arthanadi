
<div class="modal fade" id="ModalUraian" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h5 class="modal-title" align="center" id="myModalLabel"><b>FORM DAFTAR URAIAN</b></h5>
			</div>
            <form  method="POST" action="" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

			<div class="modal-body box-body">
                <div class="col-md-12">
                    <div class="form-group">
                        <label class="col-lg-3 control-label">No Kode</label>
                        <div class="col-lg-9">
                            <input type="text" id="no_kode" class="form-control" name="f[no_kode]" value="" placeholder="No Kode" required="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-3 control-label">Uraian</label>
                        <div class="col-lg-9">
                            <textarea name="f[uraian]" id="uraian" cols="30" rows="3" class="form-control" required></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-3 control-label">Jumlah</label>
                        <div class="col-lg-9">
                        <input type="text" id="jumlah" class="form-control mask-number" name="f[jumlah]" value="" placeholder="Jumlah" required="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="pull-right">
                    <button id="btn_submit_detail" type="submit" class="btn btn-success"><i class="fa fa-floppy-o" aria-hidden="true"></i> <?php if($is_edit): ?> Perbarui <?php else: ?> Simpan <?php endif; ?></button> 
                </div>
            </div>
        </form>
	    </div>
    </div>
</div>
<script type="text/javascript">//<![CDATA[
    $("button#btn_submit_detail").on("click", function(e) {
        e.preventDefault();
        if( $("#no_kode").val().length === 0 ||  $("#uraian").val().length === 0 || $("#jumlah").val().length === 0) {
            message = "Silahkan lengkapi data terlebih dahulu";
            $.alert_warning( message );
            return;
        }
        let no_kode = $("#no_kode").val();
        check = $("#dt_detail_pengajuan_rkam").DataTable().rows( function ( idx, data, node ) {
                    return data.no_kode === no_kode ?	true : false;
                } ).data();

        if ( check.any() )
        {	
            message = "Nomor kode yang sama sudah ada pada tabel";
            $.alert_error( message.replace(/%s/g, no_kode) );
            return;
        }
        try {                                        
            var row_data = {
                    "no_kode": $("#no_kode").val(),
                    "uraian": $("#uraian").val(),
                    "jumlah": mask_number.currency_remove($("#jumlah").val()),
                };
   
            $("#dt_detail_pengajuan_rkam").DataTable().row.add( row_data ).draw();
            $('#ModalUraian').modal('hide');
            $('#ModalUraian').find('form').trigger('reset');
                
        } catch (e){console.log();}
    });

</script>
