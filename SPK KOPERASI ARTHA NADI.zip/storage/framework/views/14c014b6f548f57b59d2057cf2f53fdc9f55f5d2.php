<nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
  <div class="navbar-header">
      <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
  </div>
      <ul class="nav navbar-top-links navbar-right">
          



            <li>
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <!-- The user image in the navbar-->
                    <img src="<?php echo e(url('public/themes/default/images/profile_small.jpg')); ?>" class="user-image" alt="User Image">
                    <!-- hidden-xs hides the username on small devices so only the image appears. -->
                    <span class="hidden-xs"><?php echo e(Session::get('nama')); ?></span>
                </a>
            </li>
            <li>
                <a href="" title="Keluar" data-toggle="modal" data-target="#modalLogout" data-id="<?php echo Session::get('id'); ?>" ><i class="fa fa-power-off" aria-hidden="true"></i></a>
            </li>
            
      </ul>

  </nav>

<!-- MODAL LOGOUT -->
<?php echo $__env->make('modal.header.modal_logout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>