<form action="<?php echo e(route ('pegawai.update',[$pegawai->id])); ?>" method="POST" id="formEditPegawai" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

<input type="hidden" name="id" value="<?php echo e($pegawai->id); ?>">
  <div class="form-group">
      <label for="name" class="cols-sm-2 control-label">NIP</label>
      <input type="text" class="form-control" name="txtNip" value="<?php echo e($pegawai->nip); ?>" required="">
  </div>
  <div class="form-group">
      <label for="name" class="cols-sm-2 control-label">Nama Pegawai</label>
      <input type="text" class="form-control" name="txtNama_pegawai" value="<?php echo e($pegawai->nama_pegawai); ?>" required="">
  </div>
  <div class="form-group">
      <label for="name" class="cols-sm-2 control-label">Email</label>
      <input type="email" class="form-control" name="txtEmail" value="<?php echo e($pegawai->email); ?>" required="">
  </div>
  <div class="form-group">
      <label for="name" class="cols-sm-2 control-label">Telepon</label>
      <input type="text" class="form-control" name="txtTelepon" value="<?php echo e($pegawai->no_hp_pegawai); ?>" required="">
  </div>
  <div class="form-group">
      <label for="name" class="cols-sm-2 control-label">Tanggal Lahir</label>
      <input type="date" class="form-control" name="txtTgl_lahir" value="<?php echo e($pegawai->tanggal_lahir_pegawai); ?>" required="">
  </div>
  <div class="form-group">
      <label for="name" class="cols-sm-2 control-label">Jenis Kelamin</label>
      <select name="txtJenis_kelamin" class="form-control" required="">
          <option value="<?php echo e($pegawai->jenis_kelamin_pegawai); ?>"><?php echo e($pegawai->jenis_kelamin_pegawai); ?></option>
          <?php if($pegawai->jenis_kelamin_pegawai=='Laki-Laki'): ?>
              <option value="Perempuan">Perempuan</option>
          <?php else: ?>
              <option value="Laki-Laki">Laki-Laki</option>
          <?php endif; ?>
      </select>
  </div>
  <div class="form-group">
      <label for="name" class="cols-sm-2 control-label">Agama</label>
      <select name="txtAgama" class="form-control" required="">
          <option value="<?php echo e($pegawai->agama_pegawai); ?>"><?php echo e($pegawai->agama_pegawai); ?></option>
          <?php if($pegawai->agama_pegawai=='Hindu'): ?>
              <option value="Islam">Islam</option>
              <option value="Kristen">Kristen</option>
              <option value="Budha">Budha</option>
          <?php elseif($pegawai->agama_pegawai=='Islam'): ?>
              <option value="Hindu">Hindu</option>
              <option value="Kristen">Kristen</option>
              <option value="Budha">Budha</option>
          <?php elseif($pegawai->agama_pegawai=='Kristen'): ?>
              <option value="Hindu">Hindu</option>
              <option value="Islam">Islam</option>
              <option value="Budha">Budha</option>
          <?php else: ?>
              <option value="Hindu">Hindu</option>
              <option value="Islam">Islam</option>
              <option value="Kristen">Kristen</option>
          <?php endif; ?>
        </select>
  </div>
  <div class="form-group">
      <label for="name" class="cols-sm-2 control-label">Jabatan</label>
      <select name="txtJabatan" class="form-control" required="">
          <option value="<?php echo e($pegawai->jabatan); ?>"><?php echo e($pegawai->jabatan); ?></option>
          <?php if($pegawai->jabatan=='Dokter'): ?>
              <option value="Farmasi">Farmasi</option>
              <option value="Pengelola">Pengelola</option>
              <option value="Kepala Puskesmas">Kepala Puskesmas</option>
          <?php elseif($pegawai->jabatan=='Farmasi'): ?>
              <option value="Dokter">Dokter</option>
              <option value="Pengelola">Pengelola</option>
              <option value="Kepala Puskesmas">Kepala Puskesmas</option>
          <?php elseif($pegawai->jabatan=='Pengelola'): ?>
              <option value="Dokter">Dokter</option>
              <option value="Farmasi">Farmasi</option>
              <option value="Kepala Puskesmas">Kepala Puskesmas</option>
          <?php else: ?>
              <option value="Dokter">Dokter</option>
              <option value="Farmasi">Farmasi</option>
              <option value="Pengelola">Pengelola</option>
          <?php endif; ?>
        </select>
    </div>
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Alamat</label>
        <textarea name="txtAlamat" class="form-control" rows="2" placeholder="Masukkan Alamat Pasien" required=""><?php echo e($pegawai->alamat_pegawai); ?></textarea>
    </div>
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Username</label>
        <input type="text" class="form-control" name="txtUsername" value="<?php echo e($pegawai->username); ?>" required="">
    </div>
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Kata Sandi</label>
        <input type="password" class="form-control" name="txtPassword" value="<?php echo e($pegawai->kata_sandi); ?>"  required="">
    </div>
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Status</label>
        <select name="txtStatus" class="form-control" required="">
            <option value="<?php echo e($pegawai->status); ?>"><?php echo e($pegawai->status); ?></option>
              <?php if($pegawai->status=='Aktif'): ?>
                <option value="Tidak Aktif">Tidak Aktif</option>
              <?php else: ?>
                <option value="Aktif">Aktif</option>
              <?php endif; ?>
        </select>
    </div>
    
<div class="modal-footer">
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <button type="button" class="btn btn-warning" data-dismiss="modal">Batal</button>
</div>
</form>
