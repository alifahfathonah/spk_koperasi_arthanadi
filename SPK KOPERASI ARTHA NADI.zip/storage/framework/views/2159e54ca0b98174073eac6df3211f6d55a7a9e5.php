<form action="<?php echo e(url ('surat_masuk/aksi_kirim_waka/'.$suratMasuk->id)); ?>" method="POST" id="formKirimSuratMasuk" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($suratMasuk->id); ?>">
    <div class="form-group">
            <select class="form-control" name="txtTindakLanjut" required="">
                <option value="0"><?php echo e($suratMasuk->jabatan); ?></option>
            </select>
          </div>
<div class="modal-footer">
    <button type="submit" class="btn btn-success">Kirim</button>
</div>
</form>

