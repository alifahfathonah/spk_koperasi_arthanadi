<!DOCTYPE html>
<html>
	<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php echo $__env->make('layouts.top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<aside class="main-sidebar">
			<?php echo $__env->make('layouts.left', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</aside>
		<div class="content-wrapper">
			<section class="content-header">
				<div>
     <!-- -->
      </div>
		      <?php echo $__env->yieldContent('bread'); ?>
   			</section>
   			<section class="content container-fluid">
  
		      <?php echo $__env->yieldContent('content'); ?>
            <script type="text/javascript">
  	<?php if(Session::has('message')): ?>
    var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
    switch(type){
        case 'info':
            toastr.info("<?php echo e(Session::get('message')); ?>");
            break;

        case 'warning':
            toastr.warning("<?php echo e(Session::get('message')); ?>");
            break;

        case 'success':
            toastr.success("<?php echo e(Session::get('message')); ?>");
            break;

        case 'error':
            toastr.error("<?php echo e(Session::get('message')); ?>");
            break;
    }
  <?php endif; ?>
</script>

		    </section>
		</div>
		<footer class="main-footer">
    		<strong> Copyright &copy; 2019</strong> SASUKE
  		</footer>
  		<?php echo $__env->make('layouts.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</div>
	<?php echo $__env->make('layouts.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?><?php echo $__env->yieldPushContent('scripts'); ?>

	<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>