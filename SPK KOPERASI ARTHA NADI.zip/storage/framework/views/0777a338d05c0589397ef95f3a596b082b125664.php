<form action="<?php echo e(url('register-pasien/aksi_delete/'.$registerPasien->status)); ?>" id="formKosongkanData" method="POST" enctype="multipart/form-data">
	<?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

  <input type="hidden" name="status" value="<?php echo e($registerPasien->status); ?>">
<p>
	Apakah Anda yakin ingin mengosongkan data register pasien?
</p>
<?php echo $__env->make('layouts.modal_footer_hapus', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>