<form action="<?php echo e($route_edit); ?>" method="POST" id="formEditUser" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

<input type="hidden" name="id" value="<?php echo e($item->id); ?>">
<div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Nama Pelanggan</label>
    <div class="col-md-9">
        <input type="text" class="form-control" name="txtNama" value="<?php echo e($item->nama_pelanggan); ?>" required="">
    </div>
</div>
<div class="form-group">
  <label for="name" class="col-sm-3 control-label tengah2">Alamat</label>
  <div class="col-md-9">
    <input type="text" class="form-control" name="txtAlamat" value="<?php echo e($item->alamat); ?>" placeholder="Alamat" required="">
  </div>
</div>
<div class="form-group">
  <label for="name" class="col-sm-3 control-label tengah2">No Telepon</label>
  <div class="col-md-9">
    <input type="text" name="txtTelepon" class="form-control" placeholder="Telepon" value="<?php echo e($item->telepon); ?>" required="">
  </div>
</div>

<?php echo $__env->make('modal.footer.modal_footer_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>