<form action="<?php echo e(url ('surat_masuk/aksi_kirim_waka/'.$suratMasuk->id)); ?>" method="POST" id="formKirimSuratMasuk" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($suratMasuk->id); ?>">
    <div class="form-group">
            <select class="form-control" name="txtTindakLanjut" required="">
                <option value="">- Tindak Lanjut - </option>
                <?php $__currentLoopData = $waka; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($w->id); ?>"><?php echo e($w->jabatan); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
<div class="modal-footer">
    <button type="submit" class="btn btn-primary">Kirim</button>
</div>
</form>

