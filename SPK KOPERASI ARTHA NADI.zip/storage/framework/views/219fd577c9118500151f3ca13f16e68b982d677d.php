<form  method="POST" action="<?php echo e(route('guide.store')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>

  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Nama Guide</label>
    <div class="col-md-9">
      <input type="text" class="form-control" name="txtNama" value="<?php echo e(old('txtNama')); ?>" placeholder="Nama Guide" autofocus autocomplete="off" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">No Telepon</label>
    <div class="col-md-9">
      <input type="text" name="txtTelepon" class="form-control" placeholder="Telepon" value="<?php echo e(old('txtTelepon')); ?>" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Alamat</label>
    <div class="col-md-9">
      <input type="text" class="form-control" name="txtAlamat" value="<?php echo e(old('txtAlamat')); ?>" placeholder="Alamat" required="">
    </div>
  </div>
<?php echo $__env->make('layouts.modal_footer_tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
      
</div>
</div>
</div>
</div>