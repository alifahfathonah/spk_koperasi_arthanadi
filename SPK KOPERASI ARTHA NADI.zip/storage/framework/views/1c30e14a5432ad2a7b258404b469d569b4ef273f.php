<?php
$title="- Detail Murid";
?>
<table class="table">
	<tr>
	<td>ID Murid</td>
	<td>:</td>
	<td><?php echo e($murid->murid_id); ?></td>
</tr>
<tr>
	<td>Nama Murid</td>
	<td>:</td>
	<td><?php echo e($murid->nama_murid); ?></td>
</tr>
<tr>
	<td>Program Les</td>
	<td>:</td>
	<td><?php echo e($murid->program_les); ?></td>
</tr>
<tr>
	<td>Tanggal Pendaftaran</td>
	<td>:</td>
	<td><?php echo e(Carbon\Carbon::parse($murid->tanggal_pendaftaran)->formatLocalized('%d %B %Y')); ?></td>
</tr>
<tr>
	<td>Tanggal Lahir</td>
	<td>:</td>
	<td><?php echo e(Carbon\Carbon::parse($murid->tanggal_lahir)->formatLocalized('%d %B %Y')); ?></td>
</tr>
<tr>
	<td>Umur</td>
	<td>:</td>
	<td>

	<?php
		// tanggal lahir
		$tanggal = new DateTime($murid->tanggal_lahir);

		// tanggal hari ini
		$today = new DateTime('today');

		// tahun
		$y = $today->diff($tanggal)->y;

		// bulan
		$m = $today->diff($tanggal)->m;

		// hari
		$d = $today->diff($tanggal)->d;
	?>
		<?php echo e($y); ?> Tahun <?php echo e($m); ?> Bulan <?php echo e($d); ?> Hari
	</td>
</tr>
<tr>
	<td>Orang Tua</td>
	<td>:</td>
	<td><?php echo e($murid->nama_orangtua); ?></td>
</tr>
<tr>
	<td>Jenis Kelamin</td>
	<td>:</td>
	<td><?php echo e($murid->jenis_kelamin); ?></td>
</tr>
<tr>
	<td>Alamat</td>
	<td>:</td>
	<td><?php echo e($murid->alamat); ?></td>
</tr>
<tr>
	<td>Telepon</td>
	<td>:</td>
	<td><?php echo e($murid->no_telepon); ?></td>
</tr>
<tr>
	<td>Status</td>
	<td>:</td>
	<td><?php echo e($murid->program_les); ?></td>
</tr>
<tr>
	<td>Foto</td>
	<td>:</td>
	<td> <img src="<?php echo e(asset('public/image/foto_murid/'.$murid->foto)); ?>" style="width: 100px;"></td>
</tr>

</table>