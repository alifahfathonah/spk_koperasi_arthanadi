 <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($obat_masuk->kd_obat==$ob->id): ?>
<form action="<?php echo e(route ('obat_masuk.update',[$obat_masuk->id])); ?>" method="POST" id="formEditObatMasuk" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>


 

  <input type="hidden" name="id" value="<?php echo e($obat_masuk->id); ?>">   
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Nama Obat</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
                    <a href="" title="Browse" data-toggle="modal" data-target="#myModal2">

                    <input type="text" name="txtNamaObat" placeholder="Pilih Nama Obat" class="form-control" id="nama2" value="<?php echo e($ob->nama_obat); ?>"></a>
                   <input type="hidden" name="txtKodeObat" placeholder="ID Obat" class="form-control" id="id2" readonly="" required=""></a>
                        <?php if($errors->has('txtKodeObat')): ?>
                          <span class="label label-danger"><?php echo e($errors->first('txtKodeObat')); ?></span>
                        <?php endif; ?>
                </div>
              </div>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Tanggal Masuk</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
                     <input type="date" class="form-control" name="txtTanggalMasuk" value="<?php echo e($obat_masuk->tgl_obatmasuk); ?>" >
                        <?php if($errors->has('txtTanggalMasuk')): ?>
                          <span class="label label-danger"><?php echo e($errors->first('txtTanggalMasuk')); ?></span>
                        <?php endif; ?>
                </div>
              </div>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jumlah</label>
              <div class="cols-sm-10">
                <div class="input-group">
                  <span class="input-group-addon"><i class="fa fa-user" aria-hidden="true"></i></span>
                     <input type="number" class="form-control" name="txtJumlah" value="<?php echo e($obat_masuk->jml_obatmasuk); ?>">
                        <?php if($errors->has('txtJumlah')): ?>
                          <span class="label label-danger"><?php echo e($errors->first('txtJumlah')); ?></span>
                        <?php endif; ?>
                </div>
              </div>
          </div>
<div class="modal-footer">
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <button type="button" class="btn btn-warning" data-dismiss="modal">Batal</button>
</div>
</form>
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    