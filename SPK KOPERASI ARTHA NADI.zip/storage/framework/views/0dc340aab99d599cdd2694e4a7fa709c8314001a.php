<form  method="POST" action="<?php echo e(url($submit_url)); ?>"  class="form-horizontal">
  <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label class="col-lg-3 control-label">Nama Konselor *</label>
    <div class="col-lg-9">
      <input type="text"  class="form-control" name="f[nama_konselor]" value="<?php echo e(@$item->nama_konselor); ?>" placeholder="Nama Konselor" required="">
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Jenis Kelamin *</label>
      <div class="col-lg-9">
        <select name="f[jenis_kelamin]" class="form-control" required="">
          <option value="" disabled="" selected="" hidden="">-- Pilih --</option>
          <?php foreach(@$jenis_kelamin as $dt): ?>
            <option value="<?php echo @$dt['id'] ?>" <?= @$dt['id'] == @$item->jenis_kelamin ? 'selected': null ?>><?php echo @$dt['desc'] ?></option>
          <?php endforeach; ?>
        </select>
      </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Alamat *</label>
    <div class="col-lg-9">
      <textarea name="f[alamat]" id="" cols="30" rows="3" class="form-control" required><?php echo e(@$item->alamat); ?></textarea>
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Telepon *</label>
    <div class="col-lg-9">
      <input type="text" name="f[telepon]" class="form-control" placeholder="Telepon" value="<?php echo e(@$item->telepon); ?>" required="">
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Username *</label>
    <div class="col-lg-9">
      <input type="text" name="u[username]" class="form-control" placeholder="Username" value="<?php echo e(@$item->username); ?>" required="">
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Password *</label>
    <div class="col-lg-9">
      <input type="password" name="u[password]" class="form-control" placeholder="Password" value="<?php echo e(@$item->password); ?>" required="" minlength="6">
    </div>
  </div>
  <div class="form-group">
    <div class="col-lg-offset-3 col-lg-9">
      <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i> Batal</button>
      <button id="submit_form" type="submit" class="btn btn-primary"><i class="fa fa-check" aria-hidden="true"></i> <?php if($is_edit): ?> Perbarui <?php else: ?> Simpan <?php endif; ?></button> 
    </div>
  </div>
</form>
      
</div>
</div>
</div>
</div>