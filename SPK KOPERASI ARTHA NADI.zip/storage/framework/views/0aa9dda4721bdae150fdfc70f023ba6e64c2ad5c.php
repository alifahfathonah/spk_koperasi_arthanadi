<?php $__env->startSection('content'); ?>
<div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title"><?php echo e($header); ?></h3>
  </div>
    <div class="row kotak">
      <div class="box-body">
        <div align="left">
          <form  method="POST" action="<?php echo e(url($submit_url)); ?>" enctype="multipart/form-data" id="form_create_penjualan">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

            <div class="col-md-6">
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">No Faktur</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" id="NoFaktur" name="txtNoFaktur" value="<?php echo e(@$item->no_faktur); ?>" placeholder="No Faktur" autofocus autocomplete="off" required="" readonly>
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">Pelanggan</label>
                <div class="col-md-9">
                  <div class="input-group mb-3">
                  <input type="hidden" id="ID_Pelanggan" name="txtIDPelanggan" value="<?php echo e(@$item->id_pelanggan); ?>" class="form-control" placeholder="Nama Pelanggan" aria-describedby="basic-addon2" readonly>
                    <input type="text" id="Nama_Pelanggan" name="txtNamaPelanggan" value="<?php echo e(@$item->nama_pelanggan); ?>" class="form-control" placeholder="Nama Pelanggan" readonly style="background-color: #fff" required>
                    <div class="input-group-append">
                      <a data-toggle="modal" data-target="#ModalPelanggan" title="" class="btn btn-info tip" data-original-title=""><i class="fa fa-gear"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">Tanggal</label>
                <div class="col-md-9">
                  <input type="date" class="form-control" id="TanggalTransaksi" name="txtTanggalTransaksi" value="<?php echo e(@$item->tgl_faktur_penjualan); ?>" placeholder="Tanggal Transaksi" autofocus autocomplete="off" required="">
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">User</label>
                <div class="col-md-9">
                  <input type="text" id="User" class="form-control" name="txtUser" value="<?php echo e(@$item->user); ?>" placeholder="User" autofocus autocomplete="off" required="">
                </div>
              </div>
            </div>
            
            <?php echo $__env->make('penjualan.detail.tables', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="modal-footer" style="border-top: 0px;">
                <button type="button" onclick="window.history.go(-1); return false;" class="btn btn-warning tombolform" data-dismiss="modal"><i class="fa fa-arrow-circle-left" aria-hidden="true"></i> Kembali</button>
                <a type="button" id="btn_delete" class="btn btn-danger tombolform" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i> Batal</a>
                <button id="btn_print" type="button" class="btn btn-info tombolform"  <?php echo (@$is_edit) ? "disabled" : NULL ?>><i class="fa fa-print" aria-hidden="true"></i> Cetak</button>
                <a href="<?php echo e(route('penjualan.create')); ?>" class="btn btn-primary tombolform" ><i class="fa fa-file-o" aria-hidden="true"></i> Buat Baru</a> 
                <button id="submit_form" type="submit" class="btn btn-success tombolform" ><i class="fa fa-floppy-o" aria-hidden="true"></i> Simpan</button> 
           </div>
          </form>
        </div>
      </div>
    </div>
</div>    
<?php echo $__env->make('penjualan.lookup.pelanggan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('penjualan.lookup.barang', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
$(document).ready(function(){
  $('#ModalBarang').on('hidden.bs.modal', function (e) {
      $(this).find("input,textarea,select").val('').end().find("input[type=checkbox], input[type=radio]").prop("checked", "").end();	
      calculate_sum();
  });

var _datatable = $('#dt_barang_details').DataTable({
          processing: true,
          serverSide: false,								
          paginate: false,
          ordering: false,
          searching: false,
          info: false,
          destroy: true,
          responsive: false,
          language: {
            "zeroRecords": "Tidak ada data tersedia",
            },
          <?php if (!empty($collection)):?>
              data: <?php print_r(json_encode($collection, JSON_NUMERIC_CHECK));?>,
          <?php endif; ?>
          columns: [
              {
                  data: "kode_barang",
                  render: function (val, type, row) {
                    return '<a id=\"'+ row.kode_barang +'\" value=\"0\" kode_barang="'+ row.kode_barang +'" title=\"Hapus\" class=\"btn btn-danger btn-remove\"><i class=\"fa fa-times\"></i></a>';
                  }
              },
              { data: "kode_barang" },
              { data: "nama_barang" },
              { data: "satuan" },
              { data: "qty" },
              { 
                data: "harga",
                render: function ( val, type, row ){
                    return currency_add(val)
                  } 
							},
              { 
                data: "subtotal", 
                render: function ( val, type, row ){
                    return currency_add(val)
                  } 
							},
          ]
      });

$(document).on('click', '#pilih_barang', function (e) {
	var 
      nama_barang = $(this).attr('nama');
      kode_barang = $(this).attr('kode_barang');
      satuan 		  = $(this).attr('satuan');
      harga 		  = $(this).attr('harga');
      qty 		    = $('#qty'+kode_barang).val();
      subtotal 	  = parseFloat(harga) * parseFloat(qty);

      data_detail = {
          "kode_barang" : kode_barang,
          "nama_barang" : nama_barang,
          "satuan" : satuan,
          "qty" : qty,
          "harga" : harga,
          "subtotal" : subtotal
			};

	if(qty == '' || qty == 0){
		alert('Silahkan masukkan jumlah barang yang dijual')
	}
	//insert data ke tabel detail	
	else{
		//call function check barang in datatables detail
		cek_brg_already(kode_barang);
      if ( check.any() )
      {	
        alert("Barang yang dipilih sudah ada di list!");
			  $('#ModalBarang').find("input,textarea,select").val('').end().find("input[type=checkbox], input[type=radio]").prop("checked", "").end();
        return;
      }
      else
      {
        _datatable.row.add(data_detail).draw();
        $('#ModalBarang').modal('hide');
		  }
	} 
});
    //delete row datatable detail
    $('#dt_barang_details').on('click', '.btn-remove', function () {
        _datatable.row($(this).parents('tr')).remove().draw();
        calculate_sum()
    });

    //function get sum
    function calculate_sum(){
      var data = _datatable.rows().data();
          grandtotal = 0;
          data.each(function (value, index) {
            grandtotal += parseFloat(value.subtotal);
          });
          $('#grandtotal_form').text(currency_add(grandtotal));
          $('#grandtotal').val(currency_remove(grandtotal));
    }

    // function cek apakah barang sudah dipilih
    function cek_brg_already(kode_barang){
        // cek apakah faktur sudah dipilih
        check = _datatable.rows( function ( idx, data, node ) {
            return data.kode_barang === kode_barang ?	true : false;
          } ).data();
    }

    $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });

          var delete_url = "<?php echo e($delete_url); ?>";

          $('#btn_delete').on('click',function(){
            swal({
                title: 'Perhatian!',
                text: 'Apakah anda yakin menghapus data ini?',
                icon: 'warning',
                buttons: ["Tidak", "Ya!"],
            }).then(function(value) {
            if (value) {
                $.ajax({
                  method:'DELETE',
                  url: "<?php echo e(url("{$delete_url}")); ?>",
                  success:function(response, status, xhr)
                  {
                    if( response.status == "error"){
                      swal({
                        icon: 'error',
                        title: 'Oops...',
                        text: response.message,
                      });
                      return false
                    }
                    swal({
                        title: "Sukses!",
                        text: response.message,
                        icon: "success",
                      });
                      setTimeout(function(){
                          document.location.href = "<?php echo e(route("penjualan.index")); ?>";        
                      }, 500);
                    }
                });
              }
            });
          });

    //send data from form submit to controller
  		$('#form_create_penjualan').on('submit',function(e){
      e.preventDefault();
          var header_data = {
              'no_faktur_penjualan' : $("#NoFaktur").val(),
              'tgl_faktur_penjualan' : $("#TanggalTransaksi").val(),
              'id_pelanggan' : $("#ID_Pelanggan").val(),
              'id_user' : $("#User").val(),
              'total' : $("#grandtotal").val()
          }

					var data_post = {
							"header" : header_data,
							"detail" : {}
					};
					
					var table_data = _datatable.rows().data();
					table_data.each(function (value, index){
              var detail = {
                'kode_barang' : value.kode_barang,
                'harga'       : currency_remove(value.harga),
                'qty'         : value.qty,
                'subtotal'	  : currency_remove(value.subtotal)
              }
              data_post.detail[index] = detail;
					});

          $.ajaxSetup({
            headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
          });

          var delete_url = "<?php echo e($delete_url); ?>";

          $('#btn_delete').on('click',function(){
            $.ajax({
              method:'POST',
              url: '<?php echo e(url("'+delete_url+'")); ?>'
            });
          });
          

          $.post($(this).attr("action"), data_post, function( response, status, xhr ){
            if( response.status == "error"){
							swal({
                icon: 'error',
                title: 'Oops...',
                text: response.message,
              });
							return false
						}
						
            swal({
                title: "Sukses!",
                text: response.message,
                icon: "success",
              });
              setTimeout(function(){
                  document.location.href = "<?php echo e(route("penjualan.index")); ?>";        
              }, 500);
            })
        });		
});		
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>