 <?php 
 $title="Obat - ";
 ?>

<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">TABEL DATA OBAT</h3>

              <div class="box-tools pull-right">
              </div>
            </div>   
<div class="row kotak">
 
<?php if(Session::get('jabatan')=='Pengelola'): ?>


<?php else: ?>
<div align="left">
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalTambahObat"><span class="fa fa-plus"></span>
  Tambah Obat
</button>
</div><br>
<?php endif; ?>

<table border="1" width="100%" class="table table-bordered" id="tbobat">
	<thead>
		<tr>
			<th width="5%">No</th>
      <th>Kode Obat</th>
      <th>Nama Obat</th>
      <th>Jenis Obat</th>
      <th>Kategori Obat</th>
      <th>Stok</th>
      <th>Satuan</th>
			<?php if(Session::get('jabatan')=='Pengelola'): ?>
      <th width="1%"></th>
      <?php else: ?>
      <th>Aksi</th>
      <?php endif; ?>
		</tr>
	</thead>
	<tbody>
	
</tbody>

</table>
</div>
<!-- kode otomastis -->
<?php

// koneksi ke mysql
include ('public/config/config.php');

// membaca kode barang terbesar
$query = "SELECT max(kd_obat) as maxKode FROM tb_obat";
$hasil = mysqli_query($conn,$query);
$data  = mysqli_fetch_array($hasil);
$KodeObatMasuk = $data['maxKode'];

$noUrut = (int) substr($KodeObatMasuk, 3, 3);
$noUrut++;

$char = "OB";
$newID = $char . sprintf("%03s", $noUrut);
?>


<!-- Modal Tambah obat-->
<div class="modal fade" id="modalTambahObat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FORM TAMBAH DATA OBAT</strong></h5>
      </div>
      <div class="modal-body">
      	<form id="tambahobat" method="POST" action="<?php echo e(route('obat.store')); ?>" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>

          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Kode Obat</label>
            <input type="text" class="form-control" name="txtKd_obat" value="<?php echo e($newID); ?>" readonly="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Nama Obat</label>
            <input type="text" class="form-control" name="txtNama_obat" value="<?php echo e(old('txtNama_obat')); ?>" placeholder="Masukkan Nama Obat" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jenis Obat</label>
            <select name="txtJenis_obat" class="form-control" required="">
                <option value="">- Jenis Obat -</option>
                <option value="Serbuk">Serbuk</option>
                <option value="Tablet">Tablet</option>
                <option value="Pil">Pil</option>
                <option value="Kapsul">Kapsul</option>
                <option value="Kablet">Kablet</option>
                <option value="Larutan">Larutan</option>
                <option value="Suspensi">Suspensi</option>
                <option value="Emulsi">Emulsi</option>
                <option value="Galenik">Galenik</option>
                <option value="Ektrak">Ektrak</option>
                <option value="Infusa">Infusa</option>
                <option value="Imunoserum">Imunoserum</option>
                <option value="Obat Tetes">Obat Tetes</option>
                <option value="Suppositoria">Suppositoria</option>
                <option value="Injeksi">Injeksi</option>
                <option value="Cairan">Cairan</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Kategori Obat</label>
            <select name="txtKategori_obat" class="form-control" required="">
                <option value="">- Kategori Obat -</option>
                <option value="Obat Bebas">Obat Bebas</option>
                <option value="Obat Bebas Terbatas">Obat Bebas Terbatas</option>
                <option value="Obat Keras">Obat Keras</option>
                <option value="Jamu">Jamu</option>
                <option value="Obat Herbal">Obat Herbal</option>
                <option value="Fitofarmaka">Fitofarmaka</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Stok Awal</label>
            <input type="number" class="form-control" name="txtStok_obat" value="0" placeholder="Masukkan Stok Awal" readonly="" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Satuan</label>
            <select name="txtSatuan_obat" class="form-control" required="">
                <option value="">- Satuan -</option>
                <option value="PCS">Botol</option>
                <option value="PCS">PCS</option>
                <option value="Buah">Buah</option>
            </select>                  
          </div>
          
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
        </div>
      </form>
      
      </div>
       
     
    </div>
  </div>
</div>

<!-- modal detail obat-->
<div class="modal fade" id="modalDetailObat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>DETAIL OBAT</strong></h5>
      </div>
      <div class="modal-body" id="loadDetailObat">
        
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<!-- edit obat -->
<div class="modal fade" id="modalEditObat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FORM UBAH DATA OBAT</strong></h5>
      </div>
      <div class="modal-body" id="loadEditObat">
        
      
      </div>

    </div>
  </div>
</div>
<!-- modal hapus produk -->
<div class="modal" tabindex="-1" role="dialog" id="modalHapusProduk">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title">Warning !</h5>
      </div>

      <div class="modal-body" id="loadHapusProduk">
        
      </div>
      
    </div>
  </div>
</div>


<script type="text/javascript">
$(document).ready(function() {
    var t = $('#dataobat').DataTable( {

        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0,
        } ],
        "order": [[ 1, 'desc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );


</script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>