<?php $__env->startSection('content'); ?>
<div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title"><?php echo e($header); ?></h3>
      <div class="box-tools pull-right">
          <div class="btn-group">
                    <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown" title="Aksi">
                      <i class="fa fa-bars fa-lg tip" style="color: #3c8dbc"></i></button>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="" data-toggle="modal" data-target="#<?php echo e($idModalTambah); ?>" title="<?php echo e($headerModalTambah); ?>"><i class="fa fa-plus" aria-hidden="true"></i>Tambah</a></li>
                    </ul>
          </div>
      </div>
  </div>
<div class="row kotak">
<div class="box-body">
<div align="left">          

<table border="1" width="100%" class="table table-bordered" id="<?php echo e($idDataTable); ?>">
	<thead>
		<tr>
			<th width="5%">No</th>
      <th>Nama User</th>
      <th>Jenis Kelamin</th>
      <th>Jabatan</th>
      <th>Username</th>
      <th>Password</th>
			<th>Aksi</th>
		</tr>
	</thead>
	<tbody>
    <?php $no=1; ?>
    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?> </td>
      <td><?php echo e($p->nama_user); ?></td>
      <td><?php echo e($p->jenis_kelamin); ?></td>
      <td><?php echo e($p->jabatan); ?></td>
      <td><?php echo e($p->username); ?></td>
      <td>********</td>
      <td>
        <a title="<?php echo e($headerModalEdit); ?>" data-toggle="modal" data-target="#<?php echo e($idModalEdit); ?>" data-id="<?php echo $p->id; ?>" ><i class="btn fa fa-edit fa-lg" style="color: coral"></i></a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
</tbody>
</table>
</div>

<!-- MODAL HAPUS -->
<div class="modal fade" id="<?php echo e($idModalHapus); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>PERHATIAN!</strong></h5>
      </div>
      <div class="modal-body" id="loadDeleteUser">
            
    </div>
  </div>
  </div>
</div>
<!-- MODAL TAMBAH & EDIT--> 
<?php echo $__env->make('modal.header.modal_tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('user.tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modal.header.modal_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- DataTable -->
<?php echo $__env->make('datatables.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
  $(document).ready(function(){
    // EDIT USER
    $(document).on('shown.bs.modal','#modalEditUser', function (e) {
        $('.overlay').css('display','block');
        var id = $(e.relatedTarget).data('id');
        $('#loadEditUser').load('user/'+id+'/edit');
        setTimeout(function() {
                $('.overlay').css('display','none');
        }, 1500);
    });
  });
</script>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>