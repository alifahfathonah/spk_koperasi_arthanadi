<form action="<?php echo e(url('data-aturan/aksi_delete_all/'.$aturan->status)); ?>" id="formDeleteAturan" method="POST" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

<?php echo e(method_field('PUT')); ?>

	Apakah Anda yakin mengosongkan data aturan?
<div class="form-group">

</div>
<?php echo $__env->make('layouts.modal_footer_hapus', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>