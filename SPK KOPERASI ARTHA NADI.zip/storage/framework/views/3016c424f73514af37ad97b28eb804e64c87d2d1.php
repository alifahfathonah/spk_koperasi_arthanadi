<?php $__env->startSection('breadcrumb'); ?>  
  <h1>
    <?php echo e(@$title); ?>

  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Master</a></li>
    <li class="active"><?php echo e(@$title); ?></li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
    <div class="box">
      <div class="box-header">
        <h3 class="box-title"><?php echo e(@$title); ?></h3>
        <div class="box-tools pull-right">

          <div class="btn-group">
            <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
            Tindakan <i class="fa fa-wrench"></i></button>
            <ul class="dropdown-menu" role="menu">
              <li><a href="" data-toggle="modal" data-target="#<?php echo e($idModalTambah); ?>" title="<?php echo e($headerModalTambah); ?>"><i class="fa fa-plus" aria-hidden="true"></i> Tambah Baru</a></li>
            </ul>
          </div>
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
          </button>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <table class="table table-striped table-bordered table-hover" id="<?php echo e($idDataTable); ?>" width="100%">   
            <thead>
              <tr>
                <th class="no-sort">No</th>
                <th>Kode Transaksi</th>
                <th>Tanggal Transaksi</th>
                <th>Jenis Transaksi</th>
                <th>Status</th>
                <th class="no-sort">Aksi</th>
              </tr>
            </thead>
            <tbody>
            
          </tbody>
          </table>
      </div>
    </div>

<!-- MODAL TAMBAH & EDIT--> 
<?php echo $__env->make('modal.header.modal_create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('pengelolaan_bos.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modal.header.modal_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modal.header.modal_delete', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- DataTable -->
<script type="text/javascript">
    var id_modal_edit =  "<?php echo e($idModalEdit); ?>";
        id_load_edit = "<?php echo e($idLoadEdit); ?>";
        id_datatables = "<?php echo e($idDataTable); ?>";

      _datatables_show = {
        dt_datatables:function(){
        var _this = $("#"+id_datatables);
            _datatable = _this.DataTable({									
							ajax: "<?php echo e(url("{$url_datatables}")); ?>",
              columns: [
                          {
                              data: "id",
                              render: function (data, type, row, meta) {
                                  return meta.row + meta.settings._iDisplayStart + 1;
                              }
                          },
                          { 
                                data: "kode_transaksi", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "tanggal_transaksi", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "jenis_pembayaran", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "status_transaksi", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "id",
                                className: "text-center",
                                render: function ( val, type, row ){
                                    var buttons = '<div class="btn-group" role="group">';
                                      buttons += '<a title=\"Ubah Data\" data-toggle=\"modal\" data-target=\"#'+id_modal_edit+'\" data-id=\"'+val+'\" class=\"btn btn-info btn-xs\"><i class=\"fa fa-pencil\"></i> Ubah</a>';
                                      buttons += "</div>";
                                    return buttons
                                  }
                              },
                      ],
                                                  
                  });
							
                  return _this;
				}

			}
  
$(document).ready(function() {
  _datatables_show.dt_datatables();
   // SHOW MODAL EDIT
   $('#'+id_modal_edit).on('shown.bs.modal', function (e) {
        $('.overlay').css('display','block');
        var id = $(e.relatedTarget).data('id');
        $('#'+id_load_edit).load('pengelolaan_bos/'+id+'/edit');
        setTimeout(function() {
                $('.overlay').css('display','none');
        }, 1500);
    });
  } );
  </script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('themes.AdminLTE.layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>