<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box box-solid">
                <div class="box-header with-border">
                    <div class="row" >
                      <!-- <strong >DATA BARANG</strong> -->
                      <a class="btn btn-default pull-right" href="#modalTambahBarang" data-toggle="modal" style="margin-right:10px">Tambah</a>
                    </div>
                </div>
                <div class="box-body">
                   <table class="table table-bordered" id="tbbarang">
                       <thead>
                           <tr>
                               <!-- <th>No</th> -->
                               <th>Id Barang</th>
                               <th>Nama Barang</th>
                               <th>Harga</th>
                               <th>Jenis Barang</th>
                               <th>Aksi</th>
                           </tr>
                       </thead>
                       <tbody>
                        
                       </tbody>
                        

                   </table>
                </div>
            </div>
        </div>
    </div>

<div class="modal fade bs-modal-lg" id="modalTambahBarang">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form action="<?php echo e(route('barang.store')); ?>" method="POST" id="formTambahBarang">
      <?php echo e(csrf_field()); ?>

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" align="center"><strong>TAMBAH DATA BARANG</strong></h4>
      </div>
      <div class="modal-body">
         <div class="form-group">
            <label class="label-control">Id Barang</label>
            <input type="text" name="id_barang"  class="form-control" >
          </div>

          <div class="form-group">
            <label class="label-control">Nama Barang</label>
            <input type="text" name="nama_barang"  class="form-control">
          </div>

          <div class="form-group">
            <label class="label-control" >Jenis barang</label>
              <select class="form-control" name="jenis_barang">
                <option>Pilih Kategori</option>
                <option value="Bibit">Bibit</option>
              </select>
          </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success">Simpan</button>
      </div>
      </form>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div>

<div class="modal fade bs-modal-lg" id="modalEditBarang">
  <div class="modal-dialog" role="document">
    <div class="modal-content"  id="loadEditBarang">

    
  </div><!-- /.modal-dialog -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>