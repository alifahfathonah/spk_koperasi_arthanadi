<form action="<?php echo e(url($submit_url)); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<input type="hidden" name="f[id]" value="<?php echo e($item->id); ?>">
<p>
    Apakah anda yakin membatalkan data ini?
</p>
<div class="modal-footer">
    <button type="button" class="btn btn-danger" data-dismiss="modal">Tidak</button>
    <button type="submit" class="btn btn-success">Ya</button>
</div>
</form>