<form action="<?php echo e(route ('wakil_kepala.update',[$wakilKepala->id])); ?>" method="POST" id="formEditWakilKepala" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($wakilKepala->id); ?>">
   
<div class="form-group">
    <label for="name" class="col-sm-2 control-label tengah2">ID</label>
    <div class="col-md-10">
    <input type="text" class="form-control" name="txtIdWakilKepala" value="<?php echo e($wakilKepala->user_id); ?>" readonly="">
</div>
</div>
<div class="form-group">
    <label for="name" class="col-sm-2 control-label tengah2">Nama Pegawai</label>
    <div class="col-md-10">
    <input type="text" class="form-control" name="txtNamaPegawai" value="<?php echo e($wakilKepala->nama_pegawai); ?>" required="">
</div>
</div>
<div class="form-group">
    <label for="name" class="col-sm-2 control-label tengah2">Jabatan</label>
    <div class="col-md-10">
    <select name="txtJabatan" class="form-control" required="">
        <option value="<?php echo e($wakilKepala->jabatan); ?>"><?php echo e($wakilKepala->jabatan); ?></option>
        <?php if($wakilKepala->jabatan=='Waka Humas'): ?>
            <option value="Waka Kurikulum">Waka Kurikulum</option>
            <option value="Waka Keuangan">Waka Keuangan</option>
        <?php elseif($wakilKepala->jabatan=='Waka Kurikulum'): ?>
            <option value="Waka Humas">Waka Humas</option>
            <option value="Waka Keuangan">Waka Keuangan</option>
        <?php else: ?>
            <option value="Waka Humas">Waka Humas</option>
            <option value="Waka Kurikulum">Waka Kurikulum</option>
        <?php endif; ?>
    </select>
</div>
</div>
<div class="form-group">
        <label for="name" class="col-sm-2 control-label tengah2">Username</label>
        <div class="col-md-10">
        <input type="text" class="form-control" name="txtUsername" value="<?php echo e($wakilKepala->username); ?>" required="">
    </div>
</div>
<div class="form-group">
        <label for="name" class="col-sm-2 control-label tengah2">Password</label>
        <div class="col-md-10">
        <input type="password" class="form-control" name="txtPassword" value="<?php echo e($wakilKepala->password); ?>"  required="">
    </div>
</div>
<div class="form-group">
    <label for="name" class="col-sm-2 control-label tengah2">Status</label>
    <div class="col-md-10">
    <select name="txtStatus" class="form-control" required="">
        <option value="<?php echo e($wakilKepala->status); ?>"><?php echo e($wakilKepala->status); ?></option>
            <?php if($wakilKepala->status=='Aktif'): ?>
              <option value="Tidak Aktif">Tidak Aktif</option>
            <?php else: ?>
              <option value="Aktif">Aktif</option>
            <?php endif; ?>
    </select>
</div>
</div>
<div class="form-group">
        <label for="exampleInputFile" class="col-sm-2 control-label tengah2">Foto</label>
        <div class="col-md-10">
        <img src="<?php echo e(asset('public/image/foto_staff/'.$wakilKepala->foto)); ?>" style="width: 100px;" id="profile-img-tag2">
        </div>
</div>
<div class="form-group">
        <label for="exampleInputFile" class="col-sm-2 control-label tengah2">Ganti Foto</label>
        <div class="col-md-10">
        <input type="file" name="txtFoto" id="profile-img2" style="padding-top: 10px;padding-left: 3px;">
        </div>
</div>
<div class="modal-footer" style="border-top: 0px;">
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
</div>
</form>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag2').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img2").change(function(){
        readURL(this);
    });
</script>