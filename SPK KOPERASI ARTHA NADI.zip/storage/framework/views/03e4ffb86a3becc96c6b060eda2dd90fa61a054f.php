<!DOCTYPE html>
<html>
<?php echo $__env->make('themes.AdminLTE.partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<style>
  .skin-blue .wrapper, .skin-blue .main-sidebar, .skin-blue .left-side {
    background-color: #073c54!important;
}

.skin-blue .sidebar-menu>li:hover>a, .skin-blue .sidebar-menu>li.active>a, .skin-blue .sidebar-menu>li.menu-open>a {
    color: #fff;
    background: #063144!important;
}
.skin-blue .sidebar-menu>li.header {
    color: #4b646f;
    background: #073c54!important;
}
.skin-blue .sidebar-menu>li>.treeview-menu {
    background: #063144!important;
}
</style>
<body class="hold-transition sidebar-mini wysihtml5-supported skin-red-light">
  <div class="wrapper">
    <!-- HEADER -->
    <?php echo $__env->make('themes.AdminLTE.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Left side column. contains the logo and sidebar -->
    <?php echo $__env->make('themes.AdminLTE.partials.sidebar.'.Helpers::getJabatan(), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <?php echo $__env->make('themes.AdminLTE.partials.modal_data_collect', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('breadcrumb'); ?>
      </section>
      
      <!-- Main content -->
      <?php echo $__env->yieldContent('bread'); ?>
      <section class="content">

        <?php echo $__env->make('sweet::alert', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php echo $__env->make('themes.AdminLTE.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Control Sidebar -->
    <?php echo $__env->make('themes.AdminLTE.partials.control_sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
        immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
  </div>
<!-- ./wrapper -->

<?php echo $__env->make('themes.AdminLTE.partials.bottom', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
