<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(url('themes/AdminLTE-2.4.3/dist/img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(get_user()->nama_user); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
          <li class="<?php echo e(Request::is('dashboard') ? 'active':null); ?>"><a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
          <li class="treeview <?php echo e(Request::is('petugas') ? 'active':null); ?> <?php echo e(Request::is('akun') ? 'active':null); ?> <?php echo e(Request::is('siswa') ? 'active':null); ?>">
            <a href="#">
              <i class="fa fa-database" aria-hidden="true"></i>
              <span>Data Master</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li class="<?php echo e(Request::is('petugas') ? 'active':null); ?>"><a href="<?php echo e(url('petugas')); ?>"><i class="fa fa-circle-o"></i> <span> Petugas</span></a></li>
              <li class="<?php echo e(Request::is('akun') ? 'active':null); ?>"><a href="<?php echo e(url('akun')); ?>"><i class="fa fa-circle-o"></i> <span> Akun</span></a></li>
              <li class="<?php echo e(Request::is('siswa') ? 'active':null); ?>"><a href="<?php echo e(url('siswa')); ?>"><i class="fa fa-circle-o"></i> <span> Siswa</span></a></li>
            </ul>
          </li>
          <li class="<?php echo e(Request::is('pembayaran-spp') ? 'active':null); ?>"><a href="<?php echo e(url('pembayaran-spp')); ?>"><i class="fa fa-credit-card-alt" aria-hidden="true"></i> <span>Pembayaran SPP</span></a></li>
          
          <li class="<?php echo e(Request::is('transaksi') ? 'active':null); ?>"><a href="<?php echo e(url('transaksi')); ?>"><i class="fa fa-book" aria-hidden="true"></i> <span>Transaksi</span></a></li>
          
          <li class="treeview <?php echo e(Request::is('laporan/pembayaran') ? 'active':null); ?> <?php echo e(Request::is('laporan/rekapitulasi') ? 'active':null); ?> 
          <?php echo e(Request::is('laporan/rkas') ? 'active':null); ?> <?php echo e(Request::is('laporan/tunggakan') ? 'active':null); ?> 
          <?php echo e(Request::is('laporan/pengeluaran') ? 'active':null); ?> <?php echo e(Request::is('laporan/lpj') ? 'active':null); ?> 
          <?php echo e(Request::is('laporan/perubahan-modal') ? 'active':null); ?>

          <?php echo e(Request::is('laporan/neraca') ? 'active':null); ?>">
          <a href="#">
            <i class="fa fa-clipboard" aria-hidden="true"></i>
            <span>Laporan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('laporan/pembayaran') ? 'active':null); ?>"><a href="<?php echo e(url('laporan/pembayaran')); ?>"><i class="fa fa-file-text-o"></i> Pembayaran</a></li>
            <li class="<?php echo e(Request::is('laporan/rekapitulasi') ? 'active':null); ?>"><a href="<?php echo e(url('laporan/rekapitulasi')); ?>"><i class="fa fa-file-text-o"></i> Rekapitulasi</a></li>
            <li class="<?php echo e(Request::is('laporan/tunggakan') ? 'active':null); ?>"><a href="<?php echo e(url('laporan/tunggakan')); ?>"><i class="fa fa-file-text-o"></i> Tunggakan</a></li>
            
            <li class="<?php echo e(Request::is('laporan/pengeluaran') ? 'active':null); ?>"><a href="<?php echo e(url('laporan/pengeluaran')); ?>"><i class="fa fa-file-text-o"></i> Pengeluaran Kas</a></li>
            <li class="<?php echo e(Request::is('laporan/lpj') ? 'active':null); ?>"><a href="<?php echo e(url('laporan/lpj')); ?>"><i class="fa fa-file-text-o"></i> Pertanggung Jawaban</a></li>
            <li class="<?php echo e(Request::is('laporan/arus-kas') ? 'active':null); ?>"><a href="<?php echo e(url('laporan/arus-kas')); ?>"><i class="fa fa-file-text-o"></i> Arus Kas</a></li>
            <li class="<?php echo e(Request::is('laporan/perubahan-modal') ? 'active':null); ?>"><a href="<?php echo e(url('laporan/perubahan-modal')); ?>"><i class="fa fa-file-text-o"></i> Perubahan Anggaran</a></li>
            <li class="<?php echo e(Request::is('laporan/neraca') ? 'active':null); ?>"><a href="<?php echo e(url('laporan/neraca')); ?>"><i class="fa fa-file-text-o"></i> Neraca</a></li>
          </ul>
        </li>
        <li class="header">SETTING</li>
        <li class="<?php echo e(Request::is('siswa/naik_kelas') ? 'active':null); ?>"><a href="<?php echo e(url('siswa/naik_kelas')); ?>"><i class="fa fa-sliders" aria-hidden="true"></i> <span>Kenaikan Kelas</span></a></li>
       
        </ul>
    </section>
    <!-- /.sidebar -->
  </aside>