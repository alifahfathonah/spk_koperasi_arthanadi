<form  method="POST" action="<?php echo e(route('pemesanan_tour.store')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>

  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Bukti Pemesanan</label>
    <div class="col-md-9">
      <input type="text" class="form-control" name="txtBuktiPemesanan" value="<?php echo e($noBukti); ?>" placeholder="Bukti Pemesanan" autofocus autocomplete="off" required="" readonly>
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Tanggal Pesan</label>
    <div class="col-md-9">
      <input type="date" class="form-control" name="txtTanggalPesan" value="<?php echo e(@$tanggalPesan); ?>" placeholder="Tanggal Pesan" autofocus autocomplete="off" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Nama Customer</label>
    <div class="col-md-9">
      <input type="text" class="form-control" name="txtNamaCustomer" value="<?php echo e(old('txtNamaCustomer')); ?>" placeholder="Nama Customer" autofocus autocomplete="off" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">No Telepon</label>
    <div class="col-md-9">
      <input type="text" name="txtTelepon" class="form-control" placeholder="Telepon" value="<?php echo e(old('txtTelepon')); ?>" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Aktivitas Wisata</label>
    <div class="col-md-9">
      <select name="txtAktivitasWisata" id="" class="form-control" required>
        <option value="" disabled selected hidden>- Pilih Aktivitas Wisata - </option>
        <?php $__currentLoopData = $aktivitasWisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
          <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama_aktivitas); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
      </select>
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Nama Paket</label>
    <div class="col-md-9">
      <select name="txtNamaPaket" id="" class="form-control" required>
        <option value="" disabled selected hidden>- Pilih Paket - </option>
        <?php $__currentLoopData = $paketTour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
          <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama_paket_tour); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
      </select>
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Tiket</label>
    <div class="col-md-9">
      <select name="txtTiket" id="" class="form-control" required>
        <option value="" disabled selected hidden>- Pilih Tiket - </option>
        <?php $__currentLoopData = $tiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
          <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama_tiket); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
      </select>
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Driver</label>
    <div class="col-md-9">
      <select name="txtDriver" id="" class="form-control" required>
        <option value="" disabled selected hidden>- Pilih Driver - </option>
        <?php $__currentLoopData = $driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
          <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama_driver); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
      </select>
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Guide</label>
    <div class="col-md-9">
      <select name="txtGuide" id="" class="form-control" required>
        <option value="" disabled selected hidden>- Pilih Guide - </option>
        <?php $__currentLoopData = $guide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
          <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama_guide); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
      </select>
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Itinerary</label>
    <div class="col-md-9">
      <textarea name="txtItinerary" id="" cols="30" rows="4" class="form-control" placeholder="Itinerary"></textarea>
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Tanggal Tour</label>
    <div class="col-md-9">
      <input type="date" class="form-control" name="txtTanggalTour" value="" placeholder="Tanggal Tour" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Total Pembayaran</label>
    <div class="col-md-9">
      <input type="text" id="TotalPembayaran" class="form-control" name="txtTotalPembayaran" value="" placeholder="Total Pembayaran" required="">
    </div>
  </div>
  <?php echo $__env->make('modal.footer.modal_footer_tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
      
</div>
</div>
</div>
</div>

<script type="text/javascript">
  $("#TotalPembayaran").on('keyup', function(){
      var n = parseInt($(this).val().replace(/\D/g,''),10);
      $(this).val(n.toLocaleString());
      //do something else as per updated question
      myFunc(); //call another function too
  });
</script>