<h4 align="center">LAPORAN DETAIL REKAM MEDIS PASIEN <br>
UPT. PUSKESMAS SUSUT I BANGLI<hr>
</h4>
<table width="100%" border="0" cellpadding="3" cellspacing="3">
 <tr >
	<td width="15%">Nama Pasien</td>
	<td width="2%">:</td>
	<td width="33%"><?php echo e($pasien->nama_pasien); ?></td>

	<td width="15%">Jenis Kelamin</td>
	<td width="2%">:</td>
	<td width="33%"><?php echo e($pasien->jenis_kelamin_pasien); ?></td>
</tr>


<tr>
	<td>Pekerjaan</td>
	<td>:</td>
	<td><?php echo e($pasien->pekerjaan); ?></td>

	<td>Agama</td>
	<td>:</td>
	<td><?php echo e($pasien->agama_pasien); ?></td>
</tr>
<tr>
	<td>No Hp</td>
	<td>:</td>
	<td><?php echo e($pasien->no_hp_pasien); ?></td>

	<td>Alamat</td>
	<td>:</td>
	<td><?php echo e($pasien->alamat_pasien); ?></td>
</tr>

</table><br>


<table border="1" cellpadding="4" cellspacing="0">
	  <thead style="background-color: #ddd">
	<tr>
		<th>No</th>
		<th>Tanggal</th>
		<th>Dokter</th>
		<th>Keluhan</th>
		<th>Diagnosa</th>
		<th>Penyakit</th>
		<th>Tindakan</th>
	</tr>
	  </thead>
            <tbody>
<?php $no=1; ?>
<?php $__currentLoopData = $rekammedis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rm2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($pasien->id==$rm2->kd_pasien): ?>
	<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php if($rm2->kd_pegawai==$pg->id): ?>
	<tr>
		<td><?php echo e($no++); ?></td>
		<td><?php echo e($rm2->tgl_periksa); ?></td>
		<td><?php echo e($pg->nama_pegawai); ?></td>
		<td><?php echo e($rm2->keluhan); ?></td>
		<td><?php echo e($rm2->diagnosa); ?></td>
		<td><?php echo e($rm2->penyakit); ?></td>
		<td><?php echo e($rm2->tindakan); ?></td>
	</tr>
	<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
