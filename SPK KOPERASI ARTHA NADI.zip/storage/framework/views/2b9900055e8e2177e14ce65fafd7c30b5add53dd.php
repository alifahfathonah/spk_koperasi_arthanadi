<form action="<?php echo e(route ('absensi_admin.update',[$absen_siswa->id])); ?>" method="POST" id="formAbsenSiswa" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($absen_siswa->id); ?>">
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">ID Absensi</label>
              <div class="cols-sm-10">
                  <input type="text" class="form-control" name="txtIdAbsensi" readonly="" value="<?php echo e($absen_siswa->absensi_id); ?>">
              </div>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Tanggal</label>
              <div class="cols-sm-10">
                  <input type="text" class="form-control" name="txtTanggal" readonly="" value="<?php echo e($absen_siswa->tanggal); ?>">
              </div>
          </div>
          <div class="form-group">
          <label for="name" class="cols-sm-2 control-label">Guru</label>
                <div class="cols-sm-10">
                  <input type="text" name="txtNamaStaff" placeholder="Nama Guru" class="form-control" id="NamaStaff" required="" readonly="" style="background-color: transparent;" value="<?php echo e($absen_siswa->nama_guru); ?>"></a>
                  <input type="hidden" name="txtIdGuru" placeholder="ID Staff" class="form-control" id="IdStaff" readonly="" required="">
              </div>
          </div>
          <div class="form-group">
          <label for="name" class="cols-sm-2 control-label">Jadwal Kelas</label>
                  <input type="text" name="txtNamaKelas" placeholder="Jadwal Kelas" class="form-control" id="NamaJadwal" required="" readonly="" style="background-color: transparent;" value="<?php echo e($absen_siswa->nama_kelas); ?>">
                  <input type="hidden" name="txtIdJadwalMurid" placeholder="ID Jadwal" class="form-control" id="IdJadwal" readonly="" required="">
              </div>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Murid</label>
              <div class="cols-sm-10">
                  <input type="text" name="txtNamaMurid" class="form-control" id="NamaMurid" readonly="" required="" readonly="" style="background-color: transparent;" placeholder="Nama Murid" value="<?php echo e($absen_siswa->nama_murid); ?>">
                  <input type="hidden" name="txtIdMurid" class="form-control" id="NamaMurid" readonly="" required="" readonly="" style="background-color: transparent;" placeholder="Nama Murid" value="<?php echo e($absen_siswa->murid_id); ?>">
              </div>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Keterangan</label>
              <div class="cols-sm-10">
                   <select name="txtKeterangan" class="form-control" required="">
                    <?php if($absen_siswa->keterangan=='Hadir'): ?>
                    <option value="<?php echo e($absen_siswa->keterangan); ?>"><?php echo e($absen_siswa->keterangan); ?></option>
                    <option value="Tidak Hadir">Tidak Hadir</option>
                    <?php elseif($absen_siswa->keterangan=='Tidak Hadir'): ?>
                    <option value="<?php echo e($absen_siswa->keterangan); ?>"><?php echo e($absen_siswa->keterangan); ?></option>
                    <option value="Hadir">Hadir</option>
                    <?php else: ?>
                    <option value="">- Keterangan -</option>
                    <option value="Hadir">Hadir</option>
                    <option value="Tidak Hadir">Tidak Hadir</option>
                    <?php endif; ?>
                  </select>
              </div>
          </div>
      
         <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
        </div>
</form>
