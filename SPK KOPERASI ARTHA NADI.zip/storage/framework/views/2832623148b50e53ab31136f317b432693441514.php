 <?php 
 $title="Staff -";
 ?>

<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">DATA STAFF</h3>

              <div class="box-tools pull-right">
              </div>
            </div>    
<div class="row kotak">
<div align="left">
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#modalTambahStaff" title="Tambah Data Staff"><span class="fa fa-plus"></span> Tambah Staff
</button>
</div><br>
<table border="1" width="100%" class="table table-bordered" id="dataStaff">
	<thead>
		<tr>
			<th width="5%">No</th>
      <th>ID Staff</th>
      <th>Nama</th>
      <th>Tanggal Lahir</th>
      <th>Alamat</th>
      <th>Telepon</th>
      <th>Jabatan</th>
      <th>Jenis Kelamin</th>
      <th>Status</th>
			<th>Aksi</th>

		</tr>
	</thead>
	<tbody>
    <?php $no=1; ?>
    <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?> </td>
      <td><?php echo e($p->staff_id); ?></td>
      <td><?php echo e($p->nama); ?></td>
      <td><?php echo e(Carbon\Carbon::parse($p->tanggal_lahir)->formatLocalized('%d %B %Y')); ?></td>
      <td><?php echo e($p->alamat); ?></td>
      <td><?php echo e($p->no_telepon); ?></td>
      <td><?php echo e($p->jabatan); ?></td>
      <td>
        <?php if($p->jenis_kelamin=='L'): ?>
          <?php echo e("Laki-Laki"); ?>

        <?php else: ?>
          <?php echo e("Perempuan"); ?>

        <?php endif; ?>
      </td>
      <td><?php echo e($p->status); ?></td>
      <td>
        
            <a title="Edit Data Staff" data-toggle="modal" data-target="#modalEditStaff" data-id="<?php echo $p->id; ?>" ><span class="btn btn-warning  btn-sm"><span class="fa fa-edit"></span></span></a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
</tbody>

</table>
</div>


<!-- kode otomastis -->
<?php

// koneksi ke mysql
include ('public/config/config.php');

// membaca kode barang terbesar
$query = "SELECT max(staff_id) as maxKode FROM tb_staff";
$hasil = mysqli_query($conn,$query);
$data  = mysqli_fetch_array($hasil);
$KodeStaff = $data['maxKode'];

$noUrut = (int) substr($KodeStaff, 3, 3);

$noUrut++;

$char = "ID";
$newID = $char . sprintf("%03s", $noUrut);
?>
<!-- Modal Tambah Pasien-->
<div class="modal fade" id="modalTambahStaff" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header"> 
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FORM TAMBAH STAFF</strong></h5>
      </div>
      <div class="modal-body">
        <form id="tambahstaff" method="POST" action="<?php echo e(route('staff.store')); ?>" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>

          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">ID Staff</label>
            <input type="text" class="form-control" name="txtIdStaff" value="<?php echo e($newID); ?>" readonly="" required="">
          </div>
         <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Nama Staff</label>
            <input type="text" class="form-control" name="txtNamaStaff" value="<?php echo e(old('txtNamaStaff')); ?>" placeholder="Nama Staff" autofocus required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Tanggal Lahir</label>
            <input type="date" class="form-control" name="txtTanggalLahir" placeholder="Tanggal Lahir Staff" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Alamat</label>
            <textarea name="txtAlamat" class="form-control" rows="2" placeholder="Alamat Staff" required=""><?php echo e(old('txtAlamat')); ?></textarea>           
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Telepon</label>
            <input type="text" class="form-control" name="txtTelepon" value="<?php echo e(old('txtTelepon')); ?>" placeholder="Telepon Staff" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jabatan</label>
            <select name="txtJabatan" class="form-control" required="">
              <option value="">- Pilih Jabatan -</option>
              <option value="Admin">Admin</option>
              <option value="Guru">Guru</option>
              <option value="Pemilik">Pemilik</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jenis Kelamin</label>
            <select name="txtJenisKelamin" class="form-control" required="">
                <option value="">- Jenis Kelamin -</option>
                <option value="L">Laki-Laki</option>
                <option value="P">Perempuan</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Status</label>
            <select name="txtStatus" class="form-control" required="">
                <option value="">- Status -</option>
                <option value="Aktif">Aktif</option>
                <option value="Tidak Aktif">Tidak Aktif</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Username</label>
            <input type="text" name="txtUsername" class="form-control" placeholder="Username Staff" value="<?php echo e(old('txtUsername')); ?>" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Password</label>
            <input type="password" class="form-control" name="txtPassword" value="<?php echo e(old('txtPassword')); ?>" placeholder="Password Staff" required="">
          </div>
          <div class="form-group">
          <label for="exampleInputFile">Foto</label>
          <input type="file" name="txtFoto" id="profile-img" class="form-control"><br>
          <img src="" id="profile-img-tag" style="width: 100px;" />
        </div>
           
          
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
        </div>
      </form>
      
      </div>
       
     
    </div>
  </div>
</div>

<!-- modal detail pasien-->
<div class="modal fade" id="modalDetailPasien" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>DETAIL PASIEN</strong></h5>
      </div>
      <div class="modal-body" id="loadDetailPasien">
        
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>


<!-- modal edit staff -->
<div class="modal fade" id="modalEditStaff" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FORM UBAH DATA STAFF</strong></h5>
      </div>
      <div class="modal-body" id="loadEditStaff">
        
      
      </div>

    </div>
  </div>
</div>


<script type="text/javascript">
$(document).ready(function() {
    var t = $('#dataStaff').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0,
        } ],
        "order": [[ 1, 'desc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );


</script> 
<script>
$(document).ready(function(){
  $('[data-toggle="modal"]').tooltip();   
});
</script>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img").change(function(){
        readURL(this);
    });
</script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>