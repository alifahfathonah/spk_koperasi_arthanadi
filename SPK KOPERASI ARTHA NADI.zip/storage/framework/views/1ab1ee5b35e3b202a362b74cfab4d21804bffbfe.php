<form  method="POST" action="<?php echo e(url($submit_url)); ?>" class="form-horizontal" name="form_crud">
  <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label class="col-lg-3 control-label">NIP</label>
    <div class="col-lg-9">
      : <label class="control-label"><?php echo e(@$item->id_user); ?></label>
    </div>
  </div>
  <div class="form-group">
      <label class="col-lg-3 control-label">Nama</label>
      <div class="col-lg-9">
        : <label class="control-label"><?php echo e(@$item->nama_user); ?></label>
      </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Alamat</label>
    <div class="col-lg-9">
      : <label class="control-label"><?php echo e(@$item->alamat); ?></label>
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Telepon</label>
    <div class="col-lg-9">
      : <label class="control-label"><?php echo e(@$item->no_telp); ?></label>
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Jenis Kelamin</label>
    <div class="col-lg-9">
      : <label class="control-label"><?php echo e(@$item->jenis_kelamin); ?></label>
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Tanggal Lahir</label>
    <div class="col-lg-9">
      : <label class="control-label"><?php echo e(format_date(@$item->tanggal_lahir)); ?></label>
    </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Jabatan</label>
    <div class="col-lg-9">
      : <label class="control-label"><?php echo e(@$item->jabatan); ?></label>
    </div>
  </div>
</form>
      
