<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(@$title); ?> <?php echo e(config('app.app_name')); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="shortcut icon" href="<?php echo e(url('themes/default/images/favicon.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('themes/default/css/style_report.css')); ?>">
</head>
<body>
    <h5 align="center">
      <?php echo e(config('app.app_name')); ?> <?php echo e(config('app.area')); ?> <br>
      Alamat : <?php echo e(config('app.address')); ?> <br>Telepon : <?php echo e(config('app.phone')); ?><hr>
    </h5>
    <h5 align="center">
      <?php echo e(@$title); ?> <br>
      Semester <?php echo e(($params->semester == 1) ? 'Ganjil' : 'Genap'); ?> <br>
      Kelas <?php echo e($params->kelas); ?>

    </h5>
    <div class="container">
      <?php  $no = 1; ?>
        <table width="100%">
          <thead>
            <tr>
              <td style="text-align: center!important"  rowspan="2"><b>No</b></td>
              <td rowspan="2"><b>NIS</b></td>
              <td rowspan="2"><b>Nama</b></td>
              <td colspan="6" align="center"><b>Bulan</b></td>
              <td rowspan="2" align="center"><b>Jumlah</b></td>
            </tr>
            <tr>
              <td><b>Januari</b></td>
              <td><b>Pebruari</b></td>
              <td><b>Maret</b></td>
              <td><b>April</b></td>
              <td><b>Mei</b></td>
              <td><b>Juni</b></td>
            </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php /*
                <?php $subtotal = $row['januari'] + $row['pebruari'] + $row['maret'] + $row['april'] + $row['mei'] + $row['juni'] ?>
                <tr>
                  <td align="center">{{ $no++ }}</td>
                  <td>{{ $row['nis'] }}</td>
                  <td>{{ $row['nama'] }}</td>
                  <td>{{ ($row['januari'] > 0) ? 'Lunas' : 'Belum Bayar' }}</td>
                  <td>{{ ($row['pebruari'] > 0) ? 'Lunas' : 'Belum Bayar' }}</td>
                  <td>{{ ($row['maret'] > 0) ? 'Lunas' : 'Belum Bayar' }}</td>
                  <td>{{ ($row['april'] > 0) ? 'Lunas' : 'Belum Bayar' }}</td>
                  <td>{{ ($row['mei'] > 0) ? 'Lunas' : 'Belum Bayar' }}</td>
                  <td>{{ ($row['juni'] > 0) ? 'Lunas' : 'Belum Bayar' }}</td>
                  <td>Rp. {{ number_format($subtotal, 2) }}</td>
                </tr>
                */ ?>
                 <?php if($row['januari'] > 0 && $row['pebruari'] > 0 && $row['maret'] > 0 && $row['april'] > 0 && $row['mei'] > 0 && $row['juni'] > 0): ?>
                 <?php else: ?>
                   <?php $subtotal = $row['januari'] + $row['pebruari'] + $row['maret'] + $row['april'] + $row['mei'] + $row['juni'] ?>
                   <tr>
                     <td align="center"><?php echo e($no++); ?></td>
                     <td><?php echo e($row['nis']); ?></td>
                     <td><?php echo e($row['nama']); ?></td>
                     <td><?php echo e(($row['januari'] > 0) ? 'Lunas' : 'Belum Bayar'); ?></td>
                     <td><?php echo e(($row['pebruari'] > 0) ? 'Lunas' : 'Belum Bayar'); ?></td>
                     <td><?php echo e(($row['maret'] > 0) ? 'Lunas' : 'Belum Bayar'); ?></td>
                     <td><?php echo e(($row['april'] > 0) ? 'Lunas' : 'Belum Bayar'); ?></td>
                     <td><?php echo e(($row['mei'] > 0) ? 'Lunas' : 'Belum Bayar'); ?></td>
                     <td><?php echo e(($row['juni'] > 0) ? 'Lunas' : 'Belum Bayar'); ?></td>
                     <td>Rp. <?php echo e(number_format($subtotal, 2)); ?></td>
                   </tr>
                 <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>

        </table>

      </div>
    <p style="z-index: 100;position: absolute;bottom: 0px;float: right;font-size: 11px;"><i>Tanggal Cetak : <?php echo date('d-m-Y') ?></i></p>
</body>
</html>