      	<form  method="POST" action="<?php echo e(route('kriteria.store')); ?>" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>

          <div class="form-group">
            <label for="name" class="col-sm-3 control-label tengah2">Nama Kriteria</label>
            <div class="col-md-9">
            <input type="text" class="form-control" name="txtNamaKriteria" required="" placeholder="Nama Kriteria" autofocus autocomplete="off">
            </div>
          </div>
          <div class="form-group">
            <label for="name" class="col-sm-3 control-label tengah2">Keterangan</label>
            <div class="col-md-9">
              <textarea class="form-control" name="txtKeterangan" required="" placeholder="Masukkan Keterangan"></textarea>
            </div>
          </div>
<!--           <div class="form-group">
            <label for="name" class="col-sm-3 control-label tengah2">Status</label>
            <div class="col-md-9">
            <select name="txtStatus" class="form-control" required="">
              <option value="Aktif">Aktif</option>
              <option value="Tidak Aktif">Tidak Aktif</option>
            </select>
            </div>
          </div> -->
        <?php echo $__env->make('layouts.modal_footer_tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </form>
      
      </div>
       
     
    </div>
  </div>
</div>