<form  method="POST" action="<?php echo e(route('barang.store')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>

  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Kode Barang</label>
    <div class="col-md-9">
      <input type="hidden" class="form-control" name="txtID" value="<?php echo e($idBarang); ?>" placeholder="" autofocus autocomplete="off" required="" readonly>
      <input type="text" class="form-control" name="txtKodeBarang" value="<?php echo e($kodeBarang); ?>" placeholder="" autofocus autocomplete="off" required="" readonly>
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Nama Barang</label>
    <div class="col-md-9">
      <input type="text" class="form-control" name="txtNama" value="<?php echo e(old('txtNama')); ?>" placeholder="Nama Barang" autofocus autocomplete="off" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Jenis Barang</label>
    <div class="col-md-9">
      <input type="text" name="txtJenisBarang" class="form-control" placeholder="Jenis Barang" value="<?php echo e(old('txtJenisBarang')); ?>" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Harga Beli</label>
    <div class="col-md-9">
      <input type="number" name="txtHargaBeli" class="form-control" placeholder="Harga Beli" value="<?php echo e(old('txtHargaBeli')); ?>" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Harga Jual</label>
    <div class="col-md-9">
      <input type="number" name="txtHargaJual" class="form-control" placeholder="Harga Jual" value="<?php echo e(old('txtHargaJual')); ?>" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Satuan</label>
    <div class="col-md-9">
      <input type="text" class="form-control" name="txtSatuan" value="<?php echo e(old('txtSatuan')); ?>" placeholder="Satuan" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Stok Barang</label>
    <div class="col-md-9">
      <input type="number" name="txtStokBarang" class="form-control" placeholder="Stok Barang" value="<?php echo e(old('txtStokBarang')); ?>" required="">
    </div>
  </div>
<?php echo $__env->make('modal.footer.modal_footer_create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
      
</div>
</div>
</div>
</div>