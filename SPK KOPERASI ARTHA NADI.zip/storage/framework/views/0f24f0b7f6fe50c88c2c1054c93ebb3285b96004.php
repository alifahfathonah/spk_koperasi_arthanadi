 <?php 
 $title="Kriteria | ";
 $header="DATA KRITERIA";
 $headerModalTambah="TAMBAH DATA KRITERIA";
 $headerModalEdit="EDIT DATA KRITERIA";
 $idModalTambah="modalTambahKriteria";
 $idModalEdit="modalEditKriteria";
 $idLoadEdit="loadEditKriteria";
 $idDataTable="dataKriteria";
 $headerModalHapus="HAPUS DATA KRITERIA";
 $idModalHapus="modalHapusKriteria";
 ?>

<?php $__env->startSection('content'); ?>
<!-- <div class="page-title">
    <ul class="breadcrumb">
      <li><a href="<?php echo e(url('/Dashboard')); ?>">Dashboard</a></li>
      <li class="active">Register Pasien</li>
    </ul>
</div>  --> 
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#<?php echo e($idModalTambah); ?>" title="<?php echo e($headerModalTambah); ?>">
  <span class="fa fa-plus" style="color: white"></span> Tambah
</button>
</div><br>
<table border="1" width="100%" class="table table-bordered table-hover" id="<?php echo e($idDataTable); ?>">
	<thead>
		<tr>
			<th width="5%">No</th>
      <th>Nama Kriteria</th>
      <th>Keterangan</th>
      <th>Status</th>
      <th>Aksi</th>
		</tr>
	</thead>
<tbody>
    <?php $no=1; ?>
    <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?> </td>
      <td><?php echo e($p->nama_kriteria); ?></td>
      <td><?php echo e($p->keterangan); ?></td>
      <td><?php echo e($p->status); ?></td>
      <td>
        
            <a title="<?php echo e($headerModalEdit); ?>" data-toggle="modal" data-target="#<?php echo e($idModalEdit); ?>" data-id="<?php echo $p->id; ?>" ><i class="btn fa fa-edit fa-lg" style="color: coral"></i></a> |
            <a title="<?php echo e($headerModalHapus); ?>" data-toggle="modal" data-target="#<?php echo e($idModalHapus); ?>" data-id="<?php echo $p->id; ?>" ><i class="btn fa fa-trash fa-lg" style="color: red"></i></a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
</tbody>

</table>
</div>
</div>
</div>


<!-- MODAL HAPUS KRITERIA -->
<div class="modal fade" id="<?php echo e($idModalHapus); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>PERHATIAN!</strong></h5>
      </div>
      <div class="modal-body" id="loadDeleteKriteria">
            
    </div>
  </div>
  </div>
</div>
<!-- MODAL TAMBAH & EDIT--> 
<?php echo $__env->make('layouts.header_modal_tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('kriteria.tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.modal_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<!-- DataTable -->
<?php echo $__env->make('layouts.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>