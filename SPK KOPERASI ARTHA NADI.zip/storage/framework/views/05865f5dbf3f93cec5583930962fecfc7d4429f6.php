 <?php 
 $title="Murid -";
 ?>

<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">DATA MURID</h3>

              <div class="box-tools pull-right">
              </div>
            </div>    
<div class="row kotak">
<div align="left">
<button type="button" class="btn btn-success" data-toggle="modal" data-target="#modalTambahMurid" title="Tambah Data Murid"><span class="fa fa-plus"></span> Tambah Murid
</button>
</div><br>
<table border="1" width="100%" class="table table-bordered" id="dataMurid">
	<thead>
		<tr>
			<th width="5%">No</th>
      <th>ID Murid</th>
      <th>Nama Murid</th>
      <th>Program Les</th>
      <th>Tanggal Pendaftaran</th>
      <th>Tanggal Lahir</th>
      <!-- <th>Orang Tua</th> -->
      <th>Jenis Kelamin</th>
      <th>Alamat</th>
      <!-- <th>Telepon</th> -->
      <!-- <th>Status</th> -->
			<th>Aksi</th>

		</tr>
	</thead>
	<tbody>
    <?php $no=1; ?>
    <?php $__currentLoopData = $murid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?> </td>
      <td><?php echo e($p->murid_id); ?></td>
      <td><?php echo e($p->nama_murid); ?></td>
      <td><?php echo e($p->program_les); ?></td>
      <td><?php echo e(Carbon\Carbon::parse($p->tanggal_pendaftaran)->formatLocalized('%d %B %Y')); ?></td>
       <td><?php echo e(Carbon\Carbon::parse($p->tanggal_lahir)->formatLocalized('%d %B %Y')); ?></td>
      <!-- <td><?php echo e($p->nama_orangtua); ?></td> -->
      <td>
        <?php if($p->jenis_kelamin=='L'): ?>
          <?php echo e("Laki-Laki"); ?>

        <?php else: ?>
          <?php echo e("Perempuan"); ?>

        <?php endif; ?>
      </td>
      <td><?php echo e($p->alamat); ?></td>
      <!-- <td><?php echo e($p->no_telepon); ?></td> -->
     <!--  <td><?php echo e($p->status); ?></td> -->
      <td>
            <a title="Lihat Data Murid" data-toggle="modal" data-target="#modalDetailMurid" data-id="<?php echo $p->id; ?>" ><span class="btn btn-primary  btn-sm"><span class="fa fa-eye"></span></span></a>
            <a title="Edit Data Murid" data-toggle="modal" data-target="#modalEditMurid" data-id="<?php echo $p->id; ?>" ><span class="btn btn-warning  btn-sm"><span class="fa fa-edit"></span></span></a>

      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
</tbody>

</table>
</div>


<!-- kode otomastis -->
<?php

// koneksi ke mysql
include ('public/config/config.php');

// membaca kode barang terbesar
$query = "SELECT max(murid_id) as maxKode FROM tb_murid";
$hasil = mysqli_query($conn,$query);
$data  = mysqli_fetch_array($hasil);
$KodeMurid = $data['maxKode'];

$noUrut = (int) substr($KodeMurid, 3, 3);

$noUrut++;

$char = "MR";
$newID = $char . sprintf("%03s", $noUrut);
?>
<!-- Modal Tambah Pasien-->
<div class="modal fade" id="modalTambahMurid" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header"> 
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FORM TAMBAH MURID</strong></h5>
      </div>
      <div class="modal-body">
        <form id="tambahmurid" method="POST" action="<?php echo e(route('murid.store')); ?>" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>

          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">ID Murid</label>
            <input type="text" class="form-control" name="txtIdMurid" value="<?php echo e($newID); ?>" readonly="" required="">
          </div>
         <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Nama Murid</label>
            <input type="text" class="form-control" name="txtNamaMurid" value="<?php echo e(old('txtNamaMurid')); ?>" placeholder="Nama Murid" autofocus required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Program Les</label>
            <input type="text" class="form-control" name="txtProgramLes" value="<?php echo e(old('txtProgramLes')); ?>" placeholder="Program Les" autofocus required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Tanggal Pendaftaran</label>
            <input type="date" class="form-control" name="txtTanggalPendaftaran" placeholder="Tanggal Pendaftaran" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Tanggal Lahir</label>
            <input type="date" class="form-control" name="txtTanggalLahir" placeholder="Tanggal Lahir Murid" required="">
          </div>
           <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Nama Orang Tua</label>
            <input type="text" class="form-control" name="txtNamaOrangTua" placeholder="Nama Orang Tua" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jenis Kelamin</label>
            <select name="txtJenisKelamin" class="form-control" required="">
                <option value="">- Jenis Kelamin -</option>
                <option value="L">Laki-Laki</option>
                <option value="P">Perempuan</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Alamat</label>
            <textarea name="txtAlamat" class="form-control" rows="2" placeholder="Alamat Murid" required=""><?php echo e(old('txtAlamat')); ?></textarea>           
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Telepon</label>
            <input type="text" class="form-control" name="txtTelepon" value="<?php echo e(old('txtTelepon')); ?>" placeholder="Telepon Staff" required="">
          </div>         
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Status</label>
            <select name="txtStatus" class="form-control" required="">
                <option value="">- Status -</option>
                <option value="Aktif">Aktif</option>
                <option value="Tidak Aktif">Tidak Aktif</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Username</label>
            <input type="text" name="txtUsername" class="form-control" placeholder="Username Murid" value="<?php echo e(old('txtUsername')); ?>" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Password</label>
            <input type="password" class="form-control" name="txtPassword" value="<?php echo e(old('txtPassword')); ?>" placeholder="Password Murid" required="">
          </div>
          <div class="form-group">
          <label for="exampleInputFile">Foto</label>
          <input type="file" name="txtFoto" id="profile-img_murid" class="form-control"><br>
          <img src="" id="profile-img-tag_murid" style="width: 100px;" />
        </div>
           
          
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
        </div>
      </form>
      
      </div>
       
     
    </div>
  </div>
</div>

<!-- modal detail murid-->
<div class="modal fade" id="modalDetailMurid" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
  <div class="modal-dialog" role="document" >
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>DETAIL MURID</strong></h5>
      </div>
      <div class="modal-body" id="loadDetailMurid" >
        
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>


<!-- modal edit murid -->
<div class="modal fade" id="modalEditMurid" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FORM UBAH DATA MURID</strong></h5>
      </div>
      <div class="modal-body" id="loadEditMurid">
        
      
      </div>

    </div>
  </div>
</div>


<script type="text/javascript">
$(document).ready(function() {
    var t = $('#dataMurid').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0,
        } ],
        "order": [[ 1, 'desc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );


</script> 
<script>
$(document).ready(function(){
  $('[data-toggle="modal"]').tooltip();   
});
</script>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag_murid').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img_murid").change(function(){
        readURL(this);
    });
</script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>