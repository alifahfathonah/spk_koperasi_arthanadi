<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(@$title); ?> <?php echo e(config('app.app_name')); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="shortcut icon" href="<?php echo e(url('themes/default/images/favicon.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('themes/default/css/style_report.css')); ?>">
</head>
<body>
    <h5 align="center">
      <?php echo e(config('app.app_name')); ?> <?php echo e(config('app.area')); ?> <br>
      Alamat : <?php echo e(config('app.address')); ?> <br>Telepon : <?php echo e(config('app.phone')); ?><hr>
    </h5>
    <h5 align="center">
      <?php echo e(@$title); ?> <br>
      <?php echo e($params->nama_siswa ." Tahun Ajaran ". $params->tahun_ajaran); ?>

    </h5>
    <div class="container">
        <table width="100%">
          <thead>
            <tr>
              <th style="text-align: center!important">No</th>
              <th>Nama Bulan</th>
              <th>Tagihan</th>
              <th>Bayar</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <?php  $no = 1; ?>
            <?php if(!$pembayaran_siswa->isEmpty()): ?> 
            <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td align="center"><?php echo e($no++); ?></td>
                  <td><?php echo e($bln['desc']); ?></td>
                  <td>
                    <?php $__currentLoopData = $pembayaran_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $tagihan = $row->tagihan ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    Rp. <?php echo e(number_format($tagihan, 0)); ?>

                  </td>
                  <td>
                    <?php $__currentLoopData = $pembayaran_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($bln['desc'] == $row->bulan): ?>
                        Rp. <?php echo e((!empty($row->nominal_bayar)) ? number_format($row->nominal_bayar, 0) : 0); ?>

                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                  <td>
                    <?php $__currentLoopData = $pembayaran_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($bln['desc'] == $row->bulan): ?>
                        <?php if($row->nominal_bayar < $row->tagihan ): ?>
                        <?php $status =  'BELUM LUNAS' ?>
                        <?php elseif($row->nominal_bayar - $row->tagihan == 0): ?>
                          <?php $status =  'LUNAS' ?>
                        <?php endif; ?>
                      <?php elseif($row->nominal_bayar - $row->tagihan != 0): ?>
                        <?php $status =  'BELUM LUNAS' ?>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($status); ?>

                  </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="5" align="center">Tidak terdapat data</td>
              </tr>
            <?php endif; ?>
          </tbody>

        </table>
      </div>
    <p style="z-index: 100;position: absolute;bottom: 0px;float: right;font-size: 11px;"><i>Tanggal Cetak : <?php echo date('d-m-Y') ?></i></p>
</body>
</html>