<h4 align="center">LAPORAN DATA RESEP OBAT PASIEN <br>
UPT. PUSKESMAS SUSUT I BANGLI<hr>
</h4>
<?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($rekammedis->kd_pasien==$ps->id): ?>
<?php if($rekammedis->kd_pegawai==$pg->id): ?>


<table cellpadding="4" cellspacing="0" width="100%">
  <tr>
    <td width="16%">KRM
    </td>
    <td width="4%">:</td>
    <td width="30%"><?php echo e($rekammedis->kd_rekam_medis); ?></td>
    <td width="16%">
       Tanggal Periksa
    </td>
    <td width="4%">:</td>
    <td width="30%"><?php echo e(Carbon\Carbon::parse($rekammedis->tgl_periksa)->formatLocalized('%d %B %Y')); ?></td>
  </tr>
  <tr>
    <td>Pasien
    </td>
    <td>:</td>
    <td><?php echo e($ps->nama_pasien); ?></td>
    <td>
      Alergi
    </td>
    <td>:</td>
    <td><?php echo e($ps->alergi); ?></td>
  </tr>
  <tr>
    <td>
      Keluhan
    </td>
    <td>:</td>
    <td><?php echo e($rekammedis->keluhan); ?></td>
    <td>
     Diagnosa
    </td>
    <td>:</td>
    <td><?php echo e($rekammedis->diagnosa); ?></td>
  </tr>
  <tr>
    <td>
      Penyakit
    </td>
    <td>:</td>
    <td><?php echo e($rekammedis->penyakit); ?></td>
    <td>
      Tindakan
    </td>
    <td>:</td>
    <td><?php echo e($rekammedis->tindakan); ?></td>
    
  </tr>
  <tr>
    <td>
      Dokter
    </td>
    <td>:</td>
    <td><?php echo e($pg->nama_pegawai); ?></td>
    <td>
      Unit Tujuan
    </td>
    <td>:</td>
    <td><?php echo e($rekammedis->unit_tujuan); ?></td>
  </tr>
</table>

<?php endif; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<br>
<!-- tampil resep -->
<table border="1" cellpadding="6" cellspacing="0" width="100%">
    <thead style="background-color: #ddd">
  <tr>
    <th width="7%">No</th>
    <th>Nama Obat</th>
    <th>Jumlah</th>
    <th>Cara Pakai</th>
    <th>Keterangan</th>
  </tr>
    </thead>
            <tbody>
<?php $no=1; ?>
<?php $__currentLoopData = $resep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($rs->kd_rekam_medis==$rekammedis->id): ?>
<?php if($rs->kd_obat==$ob->id): ?>

  <tr>
    <td><?php echo e($no++); ?></td>
    <td><?php echo e($ob->nama_obat); ?></td>
    <td><?php echo e($rs->jml_obatkeluar); ?></td>
    <td><?php echo e($rs->cara_pakai); ?></td>
    <td><?php echo e($rs->keterangan); ?></td>
  </tr>
<?php endif; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

  
</table>
