<section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(url('public/assets/dist/img/user.png')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <br>
          <p><!-- <?php echo e(Session::get('username')); ?> --></p>
          <!-- Status -->
          <!-- <a href="#"><i class="fa fa-circle text-success"></i> Online</a> -->
        </div>
      </div>

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
         
       <!--  <li class="header">MASTER DATA</li> -->
         <li class=""><a href=""><i class="fa fa-university"></i><span> Dashboard</span></a></li>
          <li class="treeview <?php echo e(Request::is('admin')?'active':null); ?> <?php echo e(Request::is('kepala_sekolah')?'active':null); ?> <?php echo e(Request::is('wakil_kepala')?'active':null); ?>">
          <a href="#">
            <i class="fa fa-users"></i>
            <span>User</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('admin')?'active':null); ?>"><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-user"></i> <span>Admin</span></a></li>
            <li class="<?php echo e(Request::is('kepala_sekolah')?'active':null); ?>"><a href="<?php echo e(url('/kepala_sekolah')); ?>"><i class="fa fa-user"></i> <span>Kepala Sekolah</span></a></li>
            <li class="<?php echo e(Request::is('wakil_kepala')?'active':null); ?>"><a href="<?php echo e(url('/wakil_kepala')); ?>"><i class="fa fa-user"></i> <span>Wakil Kepala</span></a></li>
          </ul>
        </li>
        <li class="<?php echo e(Request::is('surat_masuk')?'active':null); ?> <?php echo e(Request::is('surat_masuk/create')?'active':null); ?>"><a href="<?php echo e(url('/surat_masuk')); ?>"><i class="fa fa-envelope"></i> <span>Surat Masuk</span></a></li>
        <li class="<?php echo e(Request::is('surat_keluar')?'active':null); ?> <?php echo e(Request::is('surat_keluar/create')?'active':null); ?>"><a href="<?php echo e(url('/surat_keluar')); ?>"><i class="fa fa-paper-plane-o"></i> <span>Surat Keluar</span></a></li>
        <li class="<?php echo e(Request::is('kode_surat')?'active':null); ?>"><a href="<?php echo e(url('kode_surat')); ?>"><i class="fa fa-list-alt"></i> <span>Kode Surat</span></a></li>
        <li class="treeview <?php echo e(Request::is('laporan_surat_masuk')?'active':null); ?>">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Laporan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::is('laporan_surat_masuk')?'active':null); ?>"><a href="<?php echo e(url('/laporan_surat_masuk')); ?>"><i class="fa fa-file-text-o"></i> <span>Surat Masuk</span></a></li>
            <li class=""><a href=""><i class="fa fa-file-text-o"></i> <span>Surat Keluar</span></a></li>
          </ul>
        </li>
            
        
      </ul>
      <!-- /.sidebar-menu -->
</section>