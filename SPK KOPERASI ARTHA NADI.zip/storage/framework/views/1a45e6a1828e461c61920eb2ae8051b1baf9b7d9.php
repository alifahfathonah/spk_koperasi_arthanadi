<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
</head>
<body>
<div align="center" style="top: 200px;">
<a href="">Siswa</a> / <a href="">Penyewa</a> / <a href="">Guru</a> / <a href="">Admin</a> / <a href="">Pemilik</a>
</div>
</body>
</html>