<form action="<?php echo e(route ('staff.update',[$staff->id])); ?>" method="POST" id="formEditStaff" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($staff->id); ?>">
   
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">ID Staff</label>
    <input type="text" class="form-control" name="txtIdStaff" value="<?php echo e($staff->staff_id); ?>" readonly="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Nama Staff</label>
    <input type="text" class="form-control" name="txtNamaStaff" value="<?php echo e($staff->nama); ?>" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Tanggal Lahir</label>
    <input type="date" class="form-control" name="txtTanggalLahir" value="<?php echo e($staff->tanggal_lahir); ?>" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Alamat</label>
    <textarea name="txtAlamat" class="form-control" rows="2" required=""><?php echo e($staff->alamat); ?></textarea>           
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Telepon</label>
    <input type="text" class="form-control" name="txtTelepon" value="<?php echo e($staff->no_telepon); ?>" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Jabatan</label>
    <select name="txtJabatan" class="form-control" required="">
        <option value="<?php echo e($staff->jabatan); ?>"><?php echo e($staff->jabatan); ?></option>
        <?php if($staff->jabatan=='Admin'): ?>
            <option value="Guru">Guru</option>
            <option value="Pemilik">Pemilik</option>
        <?php elseif($staff->jabatan=='Guru'): ?>
            <option value="Admin">Admin</option>
            <option value="Pemilik">Pemilik</option>
        <?php else: ?>
            <option value="Admin">Admin</option>
            <option value="Guru">Guru</option>
        <?php endif; ?>
    </select>
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Jenis Kelamin</label>
    <select name="txtJenisKelamin" class="form-control" required="">
            <option value="<?php echo e($staff->jenis_kelamin); ?>">
                <?php if($staff->jenis_kelamin=='L'): ?>
                    <?php echo e("Laki-Laki"); ?>

                <?php else: ?>
                    <?php echo e("Perempuan"); ?>

                <?php endif; ?>
            </option>
            <?php if($staff->jenis_kelamin=='L'): ?>
              <option value="P">Perempuan</option>
            <?php else: ?>
              <option value="L">Laki-Laki</option>
            <?php endif; ?>
    </select>
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Status</label>
    <select name="txtStatus" class="form-control" required="">
        <option value="<?php echo e($staff->status); ?>"><?php echo e($staff->status); ?></option>
            <?php if($staff->status=='Aktif'): ?>
              <option value="Tidak Aktif">Tidak Aktif</option>
            <?php else: ?>
              <option value="Aktif">Aktif</option>
            <?php endif; ?>
    </select>
</div>
<div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Username</label>
        <input type="text" class="form-control" name="txtUsername" value="<?php echo e($staff->username); ?>" required="">
</div>
<div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Password</label>
        <input type="password" class="form-control" name="txtPassword" value="<?php echo e($staff->password); ?>"  required="">
</div>

 <div class="form-group">
        <label for="exampleInputFile">Foto</label><br>
        <img src="<?php echo e(asset('public/image/foto_staff/'.$staff->foto)); ?>" style="width: 100px;" id="profile-img-tag2"><br>
</div>
<div class="form-group">
        <label for="exampleInputFile">Ganti Foto</label><br>
        <input type="file" name="txtFoto" id="profile-img2" class="form-control"><br>
</div>
<div class="modal-footer">
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
</div>
</form>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag2').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img2").change(function(){
        readURL(this);
    });
</script>