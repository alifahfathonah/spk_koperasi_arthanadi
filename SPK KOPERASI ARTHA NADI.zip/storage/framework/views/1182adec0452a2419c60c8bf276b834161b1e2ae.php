<section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(url('public/assets/dist/img/user.png')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <br>
          <p><?php echo e(Session::get('username')); ?></p>
          <!-- Status -->
          <!-- <a href="#"><i class="fa fa-circle text-success"></i> Online</a> -->
        </div>
      </div>

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
         
        <li class="header">MASTER DATA</li>
         <li class="<?php echo e(Request::is('dashboard')?'active':null); ?>">
          <a href="<?php echo e(url ('/dashboard')); ?>">
            <i class="fa fa-hospital-o"></i><span> Dashboard</span>
          </a>
         
        </li>
        <!-- Optionally, you can add icons to the links -->
        
       

        <?php if(Session::get('jabatan')=='Dokter'): ?>
          <li class="<?php echo e(Request::is('pasien')?'active':null); ?>"><a href="<?php echo e(url('/pasien')); ?>"><i class="fa fa-users" aria-hidden="true"></i> <span>Data Pasien</span></a></li>
          <li class="<?php echo e(Request::is('kunjungan')?'active':null); ?>"><a href="<?php echo e(url('/kunjungan')); ?>"><i class="fa fa-stethoscope"></i> <span>Periksa</span></a></li>
          <li class="<?php echo e(Request::is('rekam_medis')?'active':null); ?>"><a href="<?php echo e(url('/rekam_medis')); ?>"><i class="fa fa-medkit"></i> <span>Rekam Medis</span></a></li>
        <?php elseif(Session::get('jabatan')=='Farmasi'): ?>
          <li class="<?php echo e(Request::is('jenis_obat')?'active':null); ?>"><a href="<?php echo e(url('/jenis_obat')); ?>"><i class="fa fa-thermometer-empty"></i> <span>Data Jenis Obat</span></a></li>
          <li class=""><a href=""><i class="fa fa-thermometer-empty"></i> <span>Data Kategori Obat</span></a></li>
          <li class="<?php echo e(Request::is('obat')?'active':null); ?>"><a href="<?php echo e(url('/obat')); ?>"><i class="fa fa-thermometer-empty"></i> <span>Data Obat</span></a></li>
          <li class="header">TRANSAKSI</li>
          <li class="<?php echo e(Request::is('obat_masuk')?'active':null); ?>"><a href="<?php echo e(url('obat_masuk')); ?>"><i class="fa fa-pie-chart"></i> <span>Obat Masuk</span></a></li>
          
          <li class="<?php echo e(Request::is('resep_obat')?'active':null); ?>"><a href="<?php echo e(url('resep_obat')); ?>"><i class="fa fa-pie-chart"></i> <span>Resep</span></a></li>
        <?php elseif(Session::get('jabatan')=='Kepala Puskesmas'): ?>
          <li class="header">LAPORAN</li>

  
            <li class="<?php echo e(Request::is('laporan_kunjungan')?'active':null); ?>"><a href="<?php echo e(url('/laporan_kunjungan')); ?>"><i class="fa fa-file-text-o text-yellow"></i> <span> Data Kunjungan</span></a></li>
            <li class="<?php echo e(Request::is('laporan_rekam_medis')?'active':null); ?>"><a href="<?php echo e(url('/laporan_rekam_medis')); ?>"><i class="fa fa-file-text-o text-yellow"></i> <span> Data Rekam Medis</span></a></li>
            <li class="<?php echo e(Request::is('laporan_obat')?'active':null); ?>"><a href="<?php echo e(url('/laporan_obat')); ?>"><i class="fa fa-file-text-o text-yellow"></i> <span> Data Obat</span></a></li>


        <?php else: ?>
          <li class="<?php echo e(Request::is('pasien')?'active':null); ?>"><a href="<?php echo e(url('/pasien')); ?>"><i class="fa fa-users" aria-hidden="true"></i> <span> Data Pasien</span></a></li>
          <li class="<?php echo e(Request::is('pegawai')?'active':null); ?>"><a href="<?php echo e(url('/pegawai')); ?>"><i class="fa fa-user-md"></i> <span> Data Pegawai</span></a></li>
          <li class="<?php echo e(Request::is('kunjungan')?'active':null); ?>"><a href="<?php echo e(url('/kunjungan')); ?>"><i class="fa fa-map-marker"></i> <span> Data Kunjungan</span></a></li>
          <li class="<?php echo e(Request::is('rekam_medis')?'active':null); ?>"><a href="<?php echo e(url('/rekam_medis')); ?>"><i class="fa fa-medkit"></i> <span> Rekam Medis</span></a></li>
          <li class="<?php echo e(Request::is('obat')?'active':null); ?>"><a href="<?php echo e(url('/obat')); ?>"><i class="fa fa-thermometer-empty"></i> <span> Data Obat</span></a></li>
          <li class="<?php echo e(Request::is('obat_masuk')?'active':null); ?>"><a href="<?php echo e(url('obat_masuk')); ?>"><i class="fa fa-pie-chart"></i> <span> Obat Masuk</span></a></li>
         
        


       <li class="header">LAPORAN</li>

  
            <li class="<?php echo e(Request::is('laporan_kunjungan')?'active':null); ?>"><a href="<?php echo e(url('/laporan_kunjungan')); ?>"><i class="fa fa-file-text-o text-yellow"></i> <span> Data Kunjungan </span></a></li>
            <li class="<?php echo e(Request::is('laporan_rekam_medis')?'active':null); ?>"><a href="<?php echo e(url('/laporan_rekam_medis')); ?>"><i class="fa fa-file-text-o text-yellow"></i> <span> Data Rekam Medis</span></a></li>
            <li class="<?php echo e(Request::is('laporan_obat')?'active':null); ?>"><a href="<?php echo e(url('/laporan_obat')); ?>"><i class="fa fa-file-text-o text-yellow"></i> <span> Data Obat</span></a></li>

        <?php endif; ?>
       
        
      </ul>

            
      </ul>
      <!-- /.sidebar-menu -->
</section>