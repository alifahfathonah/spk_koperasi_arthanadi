<form action="<?php echo e(route ('jadwal_kelas.update',[$jadwal_kelas->id])); ?>" method="POST" id="formEditJadwalKelas" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($jadwal_kelas->id); ?>">
    <div class="form-group">
        <label for="name" class="cols-sm-2 control-label">ID Jadwal Kelas</label>
        <input type="text" class="form-control" name="txtIdJadwalKelas" value="<?php echo e($jadwal_kelas->jadwal_kelas_id); ?>" readonly="">
    </div>
    <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Kelas</label>
            <select class="selectpicker form-control" data-show-subtext="true" data-live-search="true" name="txtKelas">
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($o->id); ?>" <?php if($jadwal_kelas->kelas_id==$o->id): ?> selected <?php endif; ?>><?php echo e($o->nama_kelas); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
    </div>
    <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Hari</label>
            <select class="selectpicker form-control" data-show-subtext="true" data-live-search="true" name="txtHari">
              <option value="<?php echo e($jadwal_kelas->hari); ?>"><?php echo e($jadwal_kelas->hari); ?></option>
              <option value="Senin">Senin</option>
              <option value="Selasa">Selasa</option>
              <option value="Rabu">Rabu</option>
              <option value="Kamis">Kamis</option>
              <option value="Jumat">Jumat</option>
              <option value="Sabtu">Sabtu</option>
              <option value="Minggu">Minggu</option>
            </select>
    </div>
    <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jam Mulai</label>
            <input type="text" class="form-control" name="txtJamMulai" value="<?php echo e($jadwal_kelas->jam_mulai); ?>" required="">
    </div>
    <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jam Selesai</label>
            <input type="text" class="form-control" name="txtJamSelesai" value="<?php echo e($jadwal_kelas->jam_selesai); ?>" required="">
    </div>
<div class="modal-footer">
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
</div>
</form>
