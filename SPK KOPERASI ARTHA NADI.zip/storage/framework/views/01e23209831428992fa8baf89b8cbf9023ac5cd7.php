 <?php 
 $title="Laporan Surat Masuk |";
 ?>
<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">LAPORAN SURAT MASUK</h3>

              <div class="box-tools pull-right">
              </div>
            </div>   
<div class="row kotak">

<!-- FILTER DATA -->
<form action="<?php echo e(url('/laporan_surat_masuk/filter_periode')); ?>" method="GET">
<div class="modal fade" id="modalFilterSuratMasuk" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FILTER</strong></h5>
      </div>
      <div class="modal-body">
        

     <div class="form-group">
            <label for="name" class="col-sm-2 control-label tengah2">Tanggal</label>
            <div class="col-md-10">
            <input type="date" name="txtAwal" class="form-control" required="">
        	</div>
        </div>
        <div class="form-group">
            <label for="name" class="col-sm-2 control-label tengah2">Sampai</label>
            <div class="col-md-10">
            <input type="date" name="txtAkhir" class="form-control" required="">
        	</div>
        </div>

      </div>
      <div class="modal-footer" style="border-top: 0px;">
        <input type="submit" name="btnCari" value="Tampilkan" class="btn btn-primary tombolform">
        <button type="button" class="btn btn-warning tombolform" data-dismiss="modal">Tutup</button>
      </div>
    
    </div>
  </div>
</div>
</form>


<table width="100%">
  <tr>
    <td width="20%">
       <button type="button" title="Filter"  class="btn btn-primary" data-toggle="modal" data-target="#modalFilterSuratMasuk"><span class="fa fa-search"></span>
                    Filter Periode
        </button>
        <?php
      if(isset($_GET['btnCari'])){
    ?>
    <input type="hidden" name="txtAwal2" value="<?php echo e($awal); ?>">
	<input type="hidden" name="txtAkhir2" value="<?php echo e($akhir); ?>">
	<a href="<?php echo e(url('/laporan_surat_masuk/filter_periode/cetak/'.$awal.'/'.$akhir)); ?>" class="btn btn-success" target="blank" data-toggle="modal" title="Cetak">Cetak PDF</a>
	<br><br>
      Periode <b><?php echo e(Carbon\Carbon::parse($awal)->formatLocalized('%d %B %Y')); ?></b> Sampai dengan <b><?php echo e(Carbon\Carbon::parse($akhir)->formatLocalized('%d %B %Y')); ?></b>
    <?php
    $periode=" Periode ".Carbon\Carbon::parse($awal)->formatLocalized('%d %B %Y'). " Sampai ".Carbon\Carbon::parse($akhir)->formatLocalized('%d %B %Y');
      }else{
      ?>
      	<a href="<?php echo e(url('/laporan_surat_masuk/filter_periode/cetak')); ?>" class="btn btn-success" target="blank" data-toggle="modal" title="Cetak">Cetak PDF</a>
      <?php
      }
    ?>
</p>
        
    </td>
    
  </tr>
</table>
<p>



<!-- END -->
<table border="1" width="100%" class="table table-bordered table-hover" id="dataLaporanSuratMasuk">
	<thead>
		<tr>
			<th width="3%">No</th>
            <th>Tanggal Terima</th>
            <th>Kode</th>
            <th>No Surat</th>
            <th>Asal Surat</th>
            <th>Perihal Surat</th>
            <th>Tanggal Surat</th>      
            <th>Tindak Lanjut</th>
        </tr>
	</thead>
	<tbody>
	 <?php $no=1; ?>
    <?php $__currentLoopData = $laporanSuratMasuk->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?> </td>
      <td><?php echo e(Carbon\Carbon::parse($p->tanggal_terima)->formatLocalized('%d %b %Y')); ?></td>
      <td><?php echo e($p->kode_surat); ?></td>
      <td><?php echo e($p->no_surat_masuk); ?></td>
      <td><?php echo e($p->asal_surat_masuk); ?></td>
      <td><?php echo e($p->perihal_surat_masuk); ?></td>
      <td><?php echo e(Carbon\Carbon::parse($p->tanggal_surat_masuk)->formatLocalized('%d %b %Y')); ?></td>
      <td><?php echo e($p->tindak_lanjut2); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

</table>
</div>


<!-- DATATABLES -->
<script type="text/javascript">
$(document).ready(function() {
    var t = $('#dataLaporanSuratMasuk').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0,
        } ],
        "order": [[ 1, 'desc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );

</script>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>