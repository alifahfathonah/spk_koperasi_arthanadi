<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(@$title); ?> <?php echo e(config('app.app_name')); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="shortcut icon" href="<?php echo e(url('themes/default/images/favicon.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('themes/default/css/style_report.css')); ?>">
</head>
<body>
    <h5 align="center">
      <?php echo e(config('app.app_name')); ?> <?php echo e(config('app.area')); ?> <br>
      Alamat : <?php echo e(config('app.address')); ?> <br>Telepon : <?php echo e(config('app.phone')); ?><hr>
    </h5>
    <h5 align="center">
      <?php echo e(@$title); ?> 
      Hingga <?php echo e(@$params->bulan); ?>

    </h5>
    <div class="container">
        <table width="100%">
          <thead>
            <tr>
              <th style="text-align: center!important">No</th>
              <th>Nama Siswa</th>
              <th>Kelas</th>
              <th>Bulan yang belum dibayar</th>
              <th>Biaya Gedung</th>
            </tr>
          </thead>
          <tbody>
            <?php  $no = 1; ?>
              <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td align="center"><?php echo e($no++); ?></td>
                <td><?php echo e($row->nama_siswa); ?></td>
                <td><?php echo e($row->tingkat_kelas); ?></td>
                <td><?php echo e(@$params->bulan); ?></td>
                <td><?php echo e(number_format($row->nominal, 0)); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>

        </table>
      </div>
    <p style="z-index: 100;position: absolute;bottom: 0px;float: right;font-size: 11px;"><i>Tanggal Cetak : <?php echo date('d-m-Y') ?></i></p>
</body>
</html>