<section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(url('public/assets/dist/img/user.png')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <br>
          <p><!-- <?php echo e(Session::get('username')); ?> --></p>
          <!-- Status -->
          <!-- <a href="#"><i class="fa fa-circle text-success"></i> Online</a> -->
        </div>
      </div>

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
         
       <!--  <li class="header">MASTER DATA</li> -->
         <li class=""><a href=""><i class="fa fa-hospital-o"></i><span> Dashboard</span></a></li>
         <?php if(Session::get('jabatan')=='Guru'): ?>
          <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Absensi</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href="<?php echo e(url('absensi_admin')); ?>"><i class="fa fa-stethoscope"></i> <span>Kelas dan Jadwal</span></a></li>
          </ul>
        </li>
        <?php elseif(Session::get('jabatan')=='Murid'): ?>
            <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Absensi</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href="<?php echo e(url('absensi_murid')); ?>"><i class="fa fa-stethoscope"></i> <span>Kelas dan Jadwal</span></a></li>
          </ul>
        </li>
        <?php elseif(Session::get('jabatan')=='Pemilik'): ?>
         <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Laporan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
           <li class=""><a href=""><i class="fa fa-file-text-o text-yellow"></i> <span> Laporan Pendapatan</span></a></li>
           <li class=""><a href=""><i class="fa fa-file-text-o text-yellow"></i> <span> Laporan Gaji Guru</span></a></li>
           <li class=""><a href=""><i class="fa fa-file-text-o text-yellow"></i> <span> Laporan Jumlah Murid</span></a></li>
          <li class=""><a href=""><i class="fa fa-file-text-o text-yellow"></i> <span> Laporan Booking Studio</span></a></li>
          <li class=""><a href=""><i class="fa fa-file-text-o text-yellow"></i> <span> Laporan Pendapatan</span></a></li>
          </ul>
        </li>
        <?php else: ?>
          <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Murid</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
           <li class=""><a href="<?php echo e(url('murid')); ?>"><i class="fa fa-users" aria-hidden="true"></i> <span>Data Murid</span></a></li>
          </ul>
        </li>
          
          <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Absensi</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href="<?php echo e(url('absensi_admin')); ?>"><i class="fa fa-stethoscope"></i> <span>Absensi Admin</span></a></li>
            <li class=""><a href=""><i class="fa fa-stethoscope"></i> <span>Absensi Guru</span></a></li>
            <li class=""><a href="<?php echo e(url('absensi')); ?>"><i class="fa fa-stethoscope"></i> <span>Absensi Murid</span></a></li>
          </ul>
        </li>
         <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Data Kelas dan Jadwal</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href="<?php echo e(url('jadwal_murid')); ?>"><i class="fa fa-stethoscope"></i> <span>Data Kelas Murid</span></a></li>
            <li class=""><a href="<?php echo e(url('jadwal_kelas')); ?>"><i class="fa fa-stethoscope"></i> <span>Jadwal Kelas</span></a></li>
          </ul>
        </li>
          
          
          
          <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Studio</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href="<?php echo e(url('penyewa')); ?>"><i class="fa fa-thermometer-empty"></i> <span>Data Penyewa</span></a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Jadwal Booking Studio</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
           <li class=""><a href="<?php echo e(url('jadwal_studio')); ?>"><i class="fa fa-thermometer-empty"></i> <span>Data Jadwal Studio</span>
           </a></li>
           <li class=""><a href="<?php echo e(url('jadwal_booking_studio')); ?>"><i class="fa fa-thermometer-empty"></i> <span>Data Booking Jadwal Studio</span>
           </a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Gaji Guru</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href="<?php echo e(url('gaji_guru')); ?>"><i class="fa fa-stethoscope"></i> <span>Data Gaji Guru</span></a></li>
          </ul>
        </li>
          

        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Data Pengguna</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
           <li class=""><a href="<?php echo e(url('staff')); ?>"><i class="fa fa-pie-chart"></i> <span>Data Staff</span></a></li>
          </ul>
        </li>
         <li class=""><a href="<?php echo e(url('kelas')); ?>"><i class="fa fa-pie-chart"></i> <span>Data Kelas</span></a></li> 
          
        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>Laporan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
           <li class=""><a href=""><i class="fa fa-file-text-o text-yellow"></i> <span> Laporan Pendapatan</span></a></li>
           <li class=""><a href=""><i class="fa fa-file-text-o text-yellow"></i> <span> Laporan Gaji Guru</span></a></li>
           <li class=""><a href=""><i class="fa fa-file-text-o text-yellow"></i> <span> Laporan Jumlah Murid</span></a></li>
          <li class=""><a href=""><i class="fa fa-file-text-o text-yellow"></i> <span> Laporan Booking Studio</span></a></li>
          <li class=""><a href=""><i class="fa fa-file-text-o text-yellow"></i> <span> Laporan Pendapatan</span></a></li>
          </ul>
        </li>

      <?php endif; ?>
            
        
      </ul>
      <!-- /.sidebar-menu -->
</section>