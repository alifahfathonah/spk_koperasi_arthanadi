<nav class="navbar-default navbar-static-side" role="navigation">
  <div class="sidebar-collapse">
      <ul class="nav metismenu" id="side-menu">
        <div class="logo-element">
            <?php echo e(config('app.app_name')); ?>

        </div>
        <div class="mini-navbar logo-element-mini">
            <?php echo e(config('app.app_name_alias')); ?>

        </div>
            <li class="nav-header">
                <div class="dropdown profile-element"> 
                        <div class="pull-left" style="margin-right: 10px">
                            <img src="<?php echo e(url('public/themes/default/images/profile_small.jpg')); ?>" class="img-circle" alt="User Image" >
                        </div>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo e(Session::get('nama')); ?></strong>
                                </span> <span class="text-muted text-xs block"><?php echo e(Session::get('jabatan')); ?> <b class="caret"></b></span> </span> </a>
                                <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                    <li><a href="profile.html">Profile</a></li>
                                    <li><a href="contacts.html">Contacts</a></li>
                                    <li><a href="mailbox.html">Mailbox</a></li>
                                    <li class="divider"></li>
                                    <li><a href="login.html">Logout</a></li>
                                </ul>
                </div>
            </li>
            <li class="<?php echo e(Request::is('dashboard')?'active':null); ?>">
                <a href="<?php echo e(url('dashboard')); ?> "><i class="fa fa-dashboard"></i> <span class="nav-label">Dashboards</span></a>
                </li>
            <li class="<?php echo e(Request::is('mahasiswa')?'active':null); ?>">
                <a href="<?php echo e(url('mahasiswa')); ?> "><i class="fa fa-users"></i><span class="nav-label">Mahasiswa</span></a>
            </li>
            <li class="<?php echo e(Request::is('konselor')?'active':null); ?>">
                <a href="<?php echo e(url('konselor')); ?> "><i class="fa fa-user"></i> <span class="nav-label">Konselor</span></a>
            </li>
            <li class="<?php echo e(Request::is('kategori_konseling')?'active':null); ?>">
                <a href="<?php echo e(url('kategori_konseling')); ?> "><i class="fa fa-book"></i> <span class="nav-label">Kategori Konseling</span></a>
            </li>


          <li>
              <a href="mailbox.html"><i class="fa fa-envelope"></i> <span class="nav-label">Laporan </span><span class="label label-warning pull-right">16/24</span></a>
              <ul class="nav nav-second-level collapse">
                  <li><a href="mailbox.html">Inbox</a></li>
                  <li><a href="mail_detail.html">Email view</a></li>
                  <li><a href="mail_compose.html">Compose email</a></li>
                  <li><a href="email_template.html">Email templates</a></li>
              </ul>
          </li>
      </ul>

  </div>
</nav>