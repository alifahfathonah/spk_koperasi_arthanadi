<form action="<?php echo e(route('layanan.destroy',[$layanan->id])); ?>" id="formHapusLayanan">
	 <?php echo e(csrf_field()); ?>

 	 <?php echo e(method_field('DELETE')); ?>


<input type="hidden" name="id" value="<?php echo e($layanan->id); ?>" id="id">
	Apakah Anda yakin menghapus layanan <b><?php echo e($layanan->nama_layanan); ?></b> ini?
<div class="form-group">

</div>
<div class="modal-footer">
	<button type="submit" class="btn btn-warning">Ya</button>
	<button type="button" class="btn btn-warning" data-dismiss="modal">Tidak</button>
</div>
</form>