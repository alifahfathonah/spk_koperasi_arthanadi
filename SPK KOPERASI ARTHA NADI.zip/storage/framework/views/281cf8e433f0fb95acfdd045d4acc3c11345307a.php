<?php echo Html::script('public/assets/plugin/jquery/dist/jquery.min.js'); ?>

<?php echo Html::script('public/assets/plugin/bootstrap/dist/js/bootstrap.min.js'); ?>

<?php echo Html::script('public/assets/dist/js/adminlte.min.js'); ?>

<?php echo Html::script('public/assets/dist/js/demo.js'); ?>

<?php echo Html::script('public/assets/plugin/datatables/jquery.dataTables.min.js'); ?>

<?php echo Html::script('public/assets/plugin/datatables/dataTables.bootstrap.min.js'); ?>

<?php echo Html::script('public/assets/plugin/datatables/dataTables.responsive.min.js'); ?>

<?php echo Html::script('public/assets/plugin/datatables/responsive.bootstrap.min.js'); ?>

<?php echo Html::script('public/assets/select2/select2.min.js'); ?>

<?php echo Html::script('public/assets/main.js'); ?>

<?php echo Html::script('public/assets/penjualan.js'); ?>

<?php echo Html::script('public/assets/dist/js/bootstrap-datepicker.min.js'); ?>

<?php echo Html::script('public/js/dataTables.buttons.min.js'); ?>

<?php echo Html::script('public/js/buttons.flash.min.js'); ?>

<?php echo Html::script('public/js/jszip.min.js'); ?>

<?php echo Html::script('public/js/pdfmake.min.js'); ?>

<?php echo Html::script('public/js/vfs_fonts.js'); ?>

<?php echo Html::script('public/js/buttons.html5.min.js'); ?>

<?php echo Html::script('public/js/buttons.print.min.js'); ?>

<?php echo Html::script('public/js/fileinput.js'); ?>

<?php echo Html::script('public/js/theme.js'); ?>

<?php echo Html::script('public/js/popper.min.js'); ?>




<script type="text/javascript">
 $(function(){
  $(".datepicker").datepicker({
      format: 'yyyy-mm-dd',
      autoclose: true,
      todayHighlight: true,
  });
 });
</script>
