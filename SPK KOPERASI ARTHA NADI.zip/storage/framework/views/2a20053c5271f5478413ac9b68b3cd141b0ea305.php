<?php $__env->startSection('bread'); ?>
    <h1>
        Data Pelanggan
      </h1>
      <ol class="breadcrumb">
        <li><a href=""><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Data Pelanggan</li>   
      </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 ">
            <div class="box box-solid">
                <div class="box-header with-border">
                    <div class="row" >
                      <!-- <strong >DATA BARANG</strong> -->
                      <a class="btn btn-default pull-right" href="#modalTambahPelanggan" data-toggle="modal" style="margin-right:10px">Tambah</a>
                    </div>
                </div>
                <div class="box-body">
                   <table class="table table-bordered table" id="tbpelanggan">
                       <thead>
                           <tr>
                               <th>No</th>
                               <th>Id Pelanggan</th>
                               <th>Nama Pelangan</th>
                               <th>No Telepon</th>
                               <th>Alamat</th>
                               <th>Aksi</th>
                           </tr>
                       </thead>
                       <tbody>
                        
                       </tbody>
                   </table>
                </div>
            </div>
        </div>
    </div>


<div class="modal fade bs-modal-lg" id="modalTambahPelanggan">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form action="<?php echo e(route('pelanggan.store')); ?>" method="POST" id="formTambahPelanggan">
      <?php echo e(csrf_field()); ?>

      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" align="center"><strong>TAMBAH DATA PELANGGAN</strong></h4>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label class="label-control">Id Pelanggan</label>
            <input type="text" name="id_pelanggan"  class="form-control" >
          </div>

          <div class="form-group">
            <label class="label-control">Nama Pelanggan</label>
          <input type="text" name="nama_pelanggan"  class="form-control" placeholder="masukan nama">
                    </div>

          <div class="form-group">
            <label class="label-control" >No Telepon</label>
            <input type="text" name="no_telepon"  class="form-control" placeholder="masukan no telepon">
          </div>

          <div class="form-group">
            <label class="label-control" >Alamat</label>
            <textarea class="form-control"  name="alamat_pelanggan" placeholder="masukan alamat"></textarea>
          </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success">Simpan</button>
      </div>
      </form>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div>

<div class="modal fade bs-modal-lg" id="modalEditPelanggan">
  <div class="modal-dialog" role="document">
    <div class="modal-content"  id="loadEditPelanggan">

    
  </div><!-- /.modal-dialog -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>