
<div class="modal fade" style="z-index: 1100 !important" id="ModalAkun" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h5 class="modal-title" id="myModalLabel"><b>Lookup Data Akun</b></h5>
			</div>
			<div class="modal-body">
				<table id="<?php echo e($url_datatables_akun); ?>" class="table table-hover table-striped">
					<thead>
						<tr>
							<th></th>
							<th>No Akun</th>
							<th>Nama Akun</th>
							<th>Kategori</th>
					</thead>
					<tbody>

					</tbody>
				</table>  
			</div>
		</div>
	</div>
</div>
<script type="text/javascript">//<![CDATA[
    function lookupbox_row_selected( response ){
        var _response = JSON.parse(response)
        if( _response ){
            //console.log(_response);
            try {

				<?php if(@$is_edit): ?>
					$("#nama_akun_edit").val(_response.nama_akun);
					$("#akun_id_edit").val(_response.id);
					$("#no_akun_edit").val(_response.no_akun);
				<?php else: ?>
					$("#no_akun").val(_response.no_akun);
					$("#nama_akun").val(_response.nama_akun);
					$("#akun_id").val(_response.id);
				<?php endif; ?>

                
            } catch (e){console.log();}

			$('#ModalAkun').modal('hide');
            
        }
    }

	
$(document).ready(function(){
    $('#ModalAkun').on('shown.bs.modal', function (e) {
    	_datatables_akun.DT_Akun();
    });

});

var _datatables_akun = {
	DT_Akun:function(){
		var   id_datatables = "<?php echo e($url_datatables_akun); ?>";
          table = $('#'+id_datatables).DataTable({
          processing: true,
		  serverSide: false,	
		  destroy: true,					
          info: true,
          responsive: true,
		  retreive:true,
			ajax: "<?php echo e(url("{$url_datatables_akun}")); ?>",
            language: {
				"loadingRecords": "Memuat...",
				"processing": "<div class='table-loader'>Memuat...<br><span class='loading'></span></div>",
				"lengthMenu": "Tampilkan _MENU_ Per Halaman",
				"zeroRecords": "Tidak ada data ditemukan",
				"info": "Menampilkan halaman _PAGE_ dari _PAGES_ total halaman",
				"infoEmpty": "Tidak ada data yang tersedia",
				"infoFiltered": "(Pencarian dari _MAX_ total data)",
				"search": "Pencarian",
				"paginate": {
					"previous": "Sebelumnya",
					"next": "Berikutnya"
				}
            },
          columns: [
				{ 
					data: "id",
					className: "actions",
					orderable: false,
					searchable: false,
					render: function ( val, type, row ){
							var data = row;
							var json = JSON.stringify( data ).replace( /"/g, '\\"' );
							return "<a href='javascript:try{lookupbox_row_selected(\"" + json + "\")}catch(e){}' title=\"Pilih\" class=\"label label-primary btn btn-lg\"><i class=\"fa fa-check\"></i> <span>Pilih</span></a>";
						}
				},
				{ 
					data: "no_akun", 
					render: function ( val, type, row ){
							return val
						}
				},
            	{ 
					data: "nama_akun", 
					render: function ( val, type, row ){
							return val
						}
				},
				{ 
					data: "kategori", 
					render: function ( val, type, row ){
							return val
						}
				},
          ]
		  
      });
	}
}

	//]]>
	</script>