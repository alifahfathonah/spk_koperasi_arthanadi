 <!-- MODAL TAMPIL KODE SURAT -->
        <div class="modal fade" id="ModalKecamatan" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width:800px">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">PILIH KECAMATAN</h4>
                    </div>
                    <div class="modal-body">
                        <table id="lookupKecamatan" class="table table-bordered table-hover table-striped">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Nama Kecamatan</th>
                                    <th>Jumlah Pasien</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no=1;
                                ?>
                                <?php $__currentLoopData = $namaKecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="pilihKecamatan" data-id="<?php echo e($nk->kecamatan); ?>" data-jumlah="<?php echo e($nk->jumlah_pasien); ?>">
                                        <td><?php echo e($no++); ?></td>
                                        <td><?php echo e(ucfirst($nk->kecamatan)); ?></td>
                                        <td><?php echo e($nk->jumlah_pasien); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>  
                    </div>
                </div>
            </div>
        </div>

