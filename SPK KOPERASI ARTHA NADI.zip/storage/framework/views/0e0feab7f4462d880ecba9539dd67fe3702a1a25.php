 <?php 
$title="- Edit Produk";
$dasboard1="Produk";
$small="Edit Produk";
 ?>

<?php $__env->startSection('content'); ?>
<div class="box box-primary">
    <!-- /.box-header -->
    <!-- form start -->
    <form role="form" method="POST" action="<?php echo e(url('produk/update/'.$produk->id)); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

      <div class="box-body">
        <input type="hidden" name="id" value="<?php echo e($produk->id); ?>">
        <div class="form-group">
          <label for="exampleInputEmail1">Nama Produk</label>
          <input type="text" name="nama_produk" class="form-control" id="exampleInputEmail1" value="<?php echo e($produk->nama_produk); ?>">
          <?php if($errors->has('nama_produk')): ?>
                        <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('nama_produk')); ?></strong>
                        </span>
                    <?php endif; ?>
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Deskripsi</label>
          <textarea name="txtDesk" class="form-control" id="konten3" rows="10"><?php echo e($produk->deskripsi); ?></textarea>
          <?php if($errors->has('txtDesk')): ?>
                        <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('txtDesk')); ?></strong>
                        </span>
                    <?php endif; ?>
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Fitur</label>
          <textarea name="txtFitur" class="form-control" id="konten" rows="10"><?php echo e($produk->fitur); ?></textarea>
          <?php if($errors->has('txtFitur')): ?>
                        <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('txtFitur')); ?></strong>
                        </span>
                    <?php endif; ?>
        </div>
         <div class="form-group">
          <label for="exampleInputPassword1">Studi Kasus</label>
          <textarea name="txtStudi_kasus" class="form-control" id="konten2" rows="10"><?php echo e($produk->studi_kasus); ?></textarea>
          <?php if($errors->has('txtStudi_kasus')): ?>
                        <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('txtStudi_kasus')); ?></strong>
                        </span>
                    <?php endif; ?>
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Link Video</label>
          <textarea name="txtLink_video" class="form-control" id="" rows="10"><?php echo e($produk->link_video); ?></textarea>
          <?php if($errors->has('txtLink_video')): ?>
                        <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('txtLink_video')); ?></strong>
                        </span>
                    <?php endif; ?>
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1">Kategori</label>
          <select class="form-control select2" name="txtKategori">
            <?php $__currentLoopData = $category_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($kategori->id); ?>" <?php echo e(($produk->category == $kategori->id) ? 'selected' : ''); ?>><?php echo e($kategori->nama_category); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <?php if($errors->has('txtKategori')): ?>
                        <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('txtKategori')); ?></strong>
                        </span>
                    <?php endif; ?>
        </div>
        <div class="form-group">
           <label>Status</label>
              <select class="form-control" name="txtStatus">
                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k->id); ?>" <?php if($produk->status==$k->id): ?> selected <?php endif; ?>><?php echo e($k->nama_status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
                <?php if($errors->has('txtStatus')): ?>
                        <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('txtStatus')); ?></strong>
                        </span>
                    <?php endif; ?>
        </div>
        <div class="form-group">
          <label for="exampleInputFile">Gambar Produk</label><br>
          <?php $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($produk->id==$m->produk_id): ?>
              <img src="<?php echo e(asset('public/image/produk/'.$m->image)); ?>" width="100px" height="100px">
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <br>
          

          <p class="help-block">Tambah Gambar</p>
          <input type="file" name="txtImage" id="exampleInputFile">
          <?php if($errors->has('txtImage')): ?>
                <span class="help-block">
                    <strong style="color: red;"><?php echo e($errors->first('txtImage')); ?></strong>
                </span>
            <?php endif; ?>
        </div>

      </div>
      <!-- /.box-body -->

      <div class="box-footer">
        <button type="submit" class="btn btn-primary">Edit</button>
        <span class="submitLoading" style="display: none;"><img src="<?php echo e(asset('public/loading.gif')); ?>"></span>
      </div>
    </form>
  </div>

  <script type="text/javascript">
  $(document).ready(function(){
    $("button[type='submit']").click(function(){
      $('.submitLoading').show();
    });
  });
</script>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>