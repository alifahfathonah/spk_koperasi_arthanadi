 
 <?php 
 $title="Grafik Hasil SPK | ";

 ?>

<?php $__env->startSection('content'); ?>
    <section class="content">

          <!-- BAR CHART -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Grafik Hasil SPK Naive Bayes 
              </h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body chart-responsive">
              <div class="chart" id="bar-chart" style="height: 475px;"></div>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

      <!-- /.row -->

    </section>
    <!-- /.content -->


<script>
  $(function () {
    "use strict";
    //BAR CHART
    var bar = new Morris.Bar({
      element: 'bar-chart',
      resize: true,
      data: <?php echo json_encode($datashow); ?>,
      barColors: ['#00a65a', '#f56954'],
      xkey: 'nama_kecamatan',
      ykeys: ['nilai_strategis', 'nilai_tidak_strategis'],
      labels: ['STRATEGIS', 'TIDAK STRATEGIS'],
      hideHover: 'auto'
    });
  });
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>