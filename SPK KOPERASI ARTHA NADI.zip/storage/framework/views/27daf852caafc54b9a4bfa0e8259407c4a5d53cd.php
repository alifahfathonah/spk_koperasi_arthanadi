<section class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel" style="border: 0px solid #ddd;background-color: #0e1315">
        <div class="pull-left image">
          <img src="<?php echo e(url('public/image/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image" >
        </div>

        <div class="pull-left info">
          <p><?php echo e(Session::get('jabatan')); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> <?php echo e(Session::get('nama_user')); ?></a>
        </div>

      </div>


      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
          <li class="<?php echo e(Request::is('dashboard')?'active':null); ?>">
              <a href="<?php echo e(url('/dashboard')); ?>"><i class="fa fa-university"></i><span> Dashboard</span></a>
          </li>
          <!-- <li class="header">MASTER DATA</li> -->
        <?php if(Session::get('jabatan')=='Direktur'): ?>
          <li class="<?php echo e(Request::is('user')?'active':null); ?>">
              <a href="<?php echo e(url('/user')); ?>"><i class="fa fa-user"></i> <span>Data User</span></a>
          </li>
          <li class="<?php echo e(Request::is('proses-spk')?'active':null); ?><?php echo e(Request::is('perhitungan-spk')?'active':null); ?>">
              <a href="<?php echo e(url('/proses-spk')); ?>"><i class="fa fa-balance-scale"></i> <span>Proses SPK</span></a>
          </li>
          <li class="treeview <?php echo e(Request::is('laporan/register-pasien')?'active':null); ?><?php echo e(Request::is('laporan/hasil-spk')?'active':null); ?> <?php echo e(Request::is('laporan/hasil-spk/detail/*/*')?'active':null); ?>">
              <a href="#">
                <i class="fa fa-file-text-o"></i>
                <span>Laporan</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li class="<?php echo e(Request::is('laporan/hasil-spk')?'active':null); ?> <?php echo e(Request::is('laporan/hasil-spk/detail/*/*')?'active':null); ?>"><a href="<?php echo e(url('/laporan/hasil-spk')); ?>"><i class="fa fa-book"></i> <span>Hasil SPK</span></a></li>
                <li class="<?php echo e(Request::is('laporan/register-pasien')?'active':null); ?>"><a href="<?php echo e(url('/laporan/register-pasien')); ?>"><i class="fa fa-book"></i> <span>Register Pasien</span></a></li>
              </ul>
          </li>
          <li class="<?php echo e(Request::is('grafik-hasil-spk')?'active':null); ?>">
              <a href="<?php echo e(url('/grafik-hasil-spk')); ?>"><i class="fa fa-bar-chart"></i> <span>Grafik Hasil SPK</span></a>
          </li>

          <li class="header">PENGATURAN</li>
          <li class="<?php echo e(Request::is('setup-awal')?'active':null); ?>">
              <a href="<?php echo e(url('/setup-awal')); ?>"><i class="fa fa-sliders" aria-hidden="true"></i> <span>Setup Awal</span></a>
          </li>
          <li class="<?php echo e(Request::is('reset-data')?'active':null); ?>">
              <a href="<?php echo e(url('/reset-data')); ?>"><i class="fa fa-cogs" aria-hidden="true"></i> <span>Reset Data</span></a>
          </li>

        <?php elseif(Session::get('jabatan')=='Admin'): ?>
        <li class="<?php echo e(Request::is('register-pasien')?'active':null); ?>"><a href="<?php echo e(url('/register-pasien')); ?>"><i class="fa fa-address-book-o"></i> <span>Data Register Pasien</span></a></li>
        <li class="treeview <?php echo e(Request::is('kriteria')?'active':null); ?> <?php echo e(Request::is('sub-kriteria')?'active':null); ?>">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Data Kriteria</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
             <li class="<?php echo e(Request::is('kriteria')?'active':null); ?>"><a href="<?php echo e(url('/kriteria')); ?>"><i class="fa fa-bars"></i> <span>Data Kriteria</span></a></li>
              <li class="<?php echo e(Request::is('sub-kriteria')?'active':null); ?>"><a href="<?php echo e(url('/sub-kriteria')); ?>"><i class="fa fa-bars"></i> <span>Data Sub Kriteria</span></a></li>
          </ul>
        </li>
       
        <li class="<?php echo e(Request::is('data-aturan')?'active':null); ?>"><a href="<?php echo e(url('/data-aturan')); ?>"><i class="fa fa-key"></i> <span>Data Aturan</span></a></li>
        <li class="<?php echo e(Request::is('alternatif-lokasi')?'active':null); ?>"><a href="<?php echo e(url('/alternatif-lokasi')); ?>"><i class="fa fa-map-marker"></i> <span>Data Alternatif Lokasi</span></a></li>

        
        <?php endif; ?>
      </ul>
      <!-- /.sidebar-menu -->
</section>