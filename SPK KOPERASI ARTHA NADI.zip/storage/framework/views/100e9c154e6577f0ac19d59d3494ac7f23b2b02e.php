 <?php 
 $title="";
 ?>
<?php $__env->startSection('content'); ?> <!-- Content Wrapper. Contains page content -->
        <div class="preloader">
      <div class="loading">
        <img src="<?php echo e(url('public/image/loading.gif')); ?>" width="80">
        <p>Harap Tunggu</p>
      </div>
    </div>
    <!-- Main content -->
      <!-- Small boxes (Stat box) -->
      <div class="row kotak">
        <h4 align="center" style="color: green;font-size: 21px;padding: 20px;margin-bottom: 0px"><b>SELAMAT DATANG <br><br>
          DI SIGASOM GARASI SHCOOL</b><hr>
        </h4>
      
                <div class="col-3">

        <div class="col-lg-4 col-xs-3">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3></h3>

              <p>Data Kunjungan Hari ini</p>
            </div>
            <div class="icon">
              <i class="fa fa-map-marker"></i>
            </div>
            <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

       
       
        <!-- col -->
         <div class="col-lg-4 col-xs-3">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3></h3>

              <p>Data Pasien</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        
        <div class="col-3">

        <div class="col-lg-4 col-xs-3">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3></h3>

              <p>Data Kunjungan</p>
            </div>
            <div class="icon">
              <i class="fa fa-map-marker"></i>
            </div>
            <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

       
        <!-- ./col -->
          <div class="col-lg-4 col-xs-3">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3></h3>

              <p>Rekam Medis</p>
            </div>
            <div class="icon">
              <i class="fa fa-medkit"></i>
            </div>
            <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- col -->
         <div class="col-lg-4 col-xs-3">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3></h3>

              <p>Data Pasien</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <a href="" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <!-- cols -->
<!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <!-- AREA CHART -->
          <div class="box box-primary">
            <div class="box-header with-border" style="background-color: transparent;">


            </div>
          


    </section>
    <!-- /.content -->




       </div>
<!-- // koneksi ke mysql -->
<!--  -->
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>