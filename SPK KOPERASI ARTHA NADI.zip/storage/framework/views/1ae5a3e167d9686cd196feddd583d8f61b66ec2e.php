 <?php 
 $title="Pegawai -";
 ?>

<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">DATA PEGAWAI</h3>

              <div class="box-tools pull-right">
              </div>
            </div>  
<div class="row kotak">
<div align="left">
<!-- <a href="<?php echo e(route('pegawai.create')); ?>" class="btn btn-primary"><span class="fa fa-plus"></span>
  Tambah Pegawai</a> -->
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalTambahPegawai"><span class="fa fa-plus"></span>
  Tambah Pegawai
</button>
</div><br>

<!-- tampil pegawai -->
<table border="1" width="100%" class="table table-bordered" id="tbpegawai">
	<thead>
		<tr>
			<th width="5%">No</th>
      <th>NIP</th>
      <th>Nama Pegawai</th>
      <th>Telepon</th>
      <th>Jabatan</th>
      <th>Alamat</th>
			<th>Aksi</th>
		</tr>
	</thead>
	<tbody>
	
</tbody>

</table>
</div>


<!-- kode otomastis -->
<?php

// koneksi ke mysql
include ('public/config/config.php');

// membaca kode barang terbesar
$query = "SELECT max(kd_pegawai) as maxKode FROM tb_pegawai";
$hasil = mysqli_query($conn,$query);
$data  = mysqli_fetch_array($hasil);
$KodePasien = $data['maxKode'];

$noUrut = (int) substr($KodePasien, 3, 3);

$noUrut++;

$char = "PG";
$newID = $char . sprintf("%03s", $noUrut);
?>
<!-- Modal Tambah pegawai-->
<div class="modal fade" id="modalTambahPegawai" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header"> 
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FORM TAMBAH PEGAWAI</strong></h5>
      </div>
      <div class="modal-body">
        <form id="tambahpegawai" method="POST" action="<?php echo e(route('pegawai.store')); ?>" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>

         <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Kode Pegawai</label>
                     <input type="text" class="form-control" name="txtKd_pegawai" value="<?php echo e($newID); ?>" readonly="" required="">
            </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">NIP</label>
            
                     <input type="text" class="form-control" name="txtNip" placeholder="NIP Pegawai" required="">

          </div>
         
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Nama Pegawai</label>
             
                     <input type="text" class="form-control" name="txtNama_pegawai" value="<?php echo e(old('txtNama_pegawai')); ?>" placeholder="Nama Pegawai" required="">
  
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Email</label>
              
                     <input type="email" class="form-control" name="txtEmail" value="<?php echo e(old('txtEmail')); ?>" placeholder="Email Pegawai" required="">

          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Telepon</label>
          
                     <input type="text" class="form-control" name="txtTelepon" value="<?php echo e(old('txtTelepon')); ?>" placeholder="Telepon Pegawai" required="">

          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Tanggal Lahir</label>
            
                     <input type="date" class="form-control" name="txtTgl_lahir" value="<?php echo e(old('txtTgl_lahir')); ?>" placeholder="Tanggal Lahir Pegawai" required="">
              
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jenis Kelamin</label>
             
                     <select name="txtJenis_kelamin" class="form-control" required="">
                        <option value="0">- Jenis Kelamin -</option>
                        <option value="Laki-Laki">Laki-Laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Agama</label>
             
                     <select name="txtAgama" class="form-control" required="">
                        <option value="0">- Pilih Agama -</option>
                        <option value="Hindu">Hindu</option>
                        <option value="Islam">Islam</option>
                        <option value="Kristen">Kristen</option>
                        <option value="Budha">Budha</option>
                      </select>
              
          </div>
          
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jabatan</label>
            
                  <select name="txtJabatan" class="form-control" required="">
                        <option value="0">- Pilih Jabatan -</option>
                        <option value="Dokter">Dokter</option>
                        <option value="Farmasi">Farmasi</option>
                        <option value="Pengelola">Pengelola</option>
                        <option value="Kepala Puskesmas">Kepala Puskesmas</option>
                      </select>
               
          </div>
            
           <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Alamat</label>
           
                     <textarea name="txtAlamat" class="form-control" rows="3" placeholder="Alamat Pegawai" required=""><?php echo e(old('txtAlamat')); ?></textarea>
               
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Username</label>
             
                      <input type="text" class="form-control" name="txtUsername" value="<?php echo e(old('txtUsername')); ?>" placeholder="Username Pegawai" required="">
               
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Kata Sandi</label>
             
                      <input type="password" class="form-control" name="txtPassword" value="<?php echo e(old('txtPassword')); ?>" placeholder="Kata Sandi Pegawai" required="">
               
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Status</label>
             
                     <select name="txtStatus" class="form-control" required="">
                        <option value="0">- Status -</option>
                        <option value="Aktif">Aktif</option>
                        <option value="Tidak Aktif">Tidak Aktif</option>
                    </select>
              
          </div>
          
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
        </div>
      </form>
      
      </div>
       
     
    </div>
  </div>
</div>

<!-- modal detail pegawai-->
<div class="modal fade" id="modalDetailPegawai" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>DETAIL PEGAWAI</strong></h5>
      </div>
      <div class="modal-body" id="loadDetailPegawai">
        
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<!-- modal edit pegawai -->
<div class="modal fade" id="modalEditPegawai" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FORM UBAH DATA PEGAWAI</strong></h5>
      </div>
      <div class="modal-body" id="loadEditPegawai">
        
      
      </div>

    </div>
  </div>
</div>




<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>