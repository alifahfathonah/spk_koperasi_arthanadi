<form  method="POST" action="<?php echo e(url($submit_url)); ?>" class="form-horizontal">
  <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label class="col-lg-3 control-label">Nama Kategori *</label>
    <div class="col-lg-9">
      <input type="text"  class="form-control" name="f[nama_kategori]" value="<?php echo e(@$item->nama_kategori); ?>" placeholder="Nama Kategori" required="">
    </div>
  </div>
  <div class="form-group">
    <div class="col-lg-offset-3 col-lg-9">
      <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i> Batal</button>
      <button id="submit_form" type="submit" class="btn btn-primary"><i class="fa fa-check" aria-hidden="true"></i> <?php if($is_edit): ?> Perbarui <?php else: ?> Simpan <?php endif; ?></button> 
    </div>
  </div>
</form>
      
</div>
</div>
</div>
</div>