<?php
$title="- Detail Pegawai";
?>
<table class="table">
<tr>
	<td>NIP</td>
	<td>:</td>
	<td><?php echo e($pegawai->nip); ?></td>
</tr>
<tr>
	<td>Nama Pegawai</td>
	<td>:</td>
	<td><?php echo e($pegawai->nama_pegawai); ?></td>
</tr>
<tr>
	<td>Tanggal Lahir</td>
	<td>:</td>
	<td><?php echo e(Carbon\Carbon::parse($pegawai->tanggal_lahir_pegawai)->formatLocalized('%d %B %Y')); ?></td>
</tr>
<tr>
	<td>Email</td>
	<td>:</td>
	<td><?php echo e($pegawai->email); ?></td>
</tr>
<tr>
	<td>Jenis Kelamin</td>
	<td>:</td>
	<td><?php echo e($pegawai->jenis_kelamin_pegawai); ?></td>
</tr>

<tr>
	<td>Jabatan</td>
	<td>:</td>
	<td><?php echo e($pegawai->jabatan); ?>

	</td>
</tr>
<tr>
	<td>Status</td>
	<td>:</td>
	<td><?php echo e($pegawai->status); ?>

	</td>
</tr>
<tr>
	<td>Agama</td>
	<td>:</td>
	<td><?php echo e($pegawai->agama_pegawai); ?></td>
</tr>
<tr>
	<td>Telepon</td>
	<td>:</td>
	<td><?php echo e($pegawai->no_hp_pegawai); ?></td>
</tr>
<tr>
	<td>Alamat</td>
	<td>:</td>
	<td><?php echo e($pegawai->alamat_pegawai); ?></td>
</tr>
<tr>
	<td>Username</td>
	<td>:</td>
	<td><input type="text" class="form-control" name="" value="<?php echo e($pegawai->username); ?>" disabled></td>
</tr>
<tr>
	<td>Kata Sandi</td>
	<td>:</td>
	<td><input type="password" class="form-control" name="" value="<?php echo e($pegawai->kata_sandi); ?>" disabled></td>
</tr>
</table>