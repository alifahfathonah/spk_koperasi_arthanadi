<?php $__env->startSection('content'); ?>
<div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title"><?php echo e($header); ?></h3>
      <div class="box-tools pull-right">
          <div class="btn-group">
                    <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown" title="Aksi">
                      <i class="fa fa-bars fa-lg tip" style="color: #3c8dbc"></i></button>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="" data-toggle="modal" data-target="#<?php echo e($idModalTambah); ?>" title="<?php echo e($headerModalTambah); ?>"><i class="fa fa-plus" aria-hidden="true"></i>Tambah</a></li>
                    </ul>
          </div>
      </div>
  </div>
<div class="row kotak">
<div class="box-body">
<div align="left">          

<table border="1" width="100%" class="table table-bordered" id="<?php echo e($idDataTable); ?>">
	<thead>
		<tr>
			<th width="5%">No</th>
      <th>Nama Driver</th>
      <th>No Telepon</th>
      <th>Alamat</th>
			<th>Aksi</th>
		</tr>
	</thead>
	<tbody>
    <?php $no=1; ?>
    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?> </td>
      <td><?php echo e($p->nama_driver); ?></td>
      <td><?php echo e($p->no_telepon_driver); ?></td>
      <td><?php echo e($p->alamat_driver); ?></td>
      <td>
        <a title="<?php echo e($headerModalEdit); ?>" data-toggle="modal" data-target="#<?php echo e($idModalEdit); ?>" data-id="<?php echo $p->id; ?>" ><i class="btn fa fa-edit fa-lg" style="color: coral"></i></a>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
</tbody>
</table>
</div>

<!-- MODAL TAMBAH & EDIT--> 
<?php echo $__env->make('modal.header.modal_tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('driver.tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('modal.header.modal_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- DataTable -->
<?php echo $__env->make('datatables.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>
  $(document).ready(function(){
     // EDIT GUIDE
     $(document).on('shown.bs.modal','#modalEdit', function (e) {
        $('.overlay').css('display','block');
        var id = $(e.relatedTarget).data('id');
        $('#loadEdit').load('driver/'+id+'/edit');
        setTimeout(function() {
                $('.overlay').css('display','none');
        }, 1500);
    });
  });
</script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>