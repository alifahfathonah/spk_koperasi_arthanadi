<?php $__env->startSection('breadcrumb'); ?>  
  <h1>
    <?php echo e(@$title); ?>

  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Master</a></li>
    <li class="active"><?php echo e(@$title); ?></li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
    <div class="box">
      <div class="box-header">
        <h3 class="box-title"><?php echo e(@$title); ?></h3>
        <div class="box-tools pull-right">

          <div class="btn-group">
            <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
            Tindakan <i class="fa fa-wrench"></i></button>
            <ul class="dropdown-menu" role="menu">
              <li><a href="<?php echo e(url('pengajuan_bos/create' )); ?>" title="Tambah data"><i class="fa fa-plus" aria-hidden="true"></i> Tambah Baru</a></li>
            </ul>
          </div>
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
          </button>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <table class="table table-striped table-bordered table-hover" id="<?php echo e($idDataTable); ?>" width="100%">   
            <thead>
              <tr>
                <th class="no-sort">No</th>
                <th>Kode Pengajuan</th>
                <th>Tahun Ajaran</th>
                <th>Periode</th>
                <th>Jumlah Siswa</th>
                <th>Status</th>
                <th class="no-sort">Aksi</th>
              </tr>
            </thead>
            <tbody>
            
          </tbody>
          </table>
      </div>
    </div>

<!-- DataTable -->
<script type="text/javascript">
    var id_modal_edit =  "<?php echo e($idModalEdit); ?>";
        id_load_edit = "<?php echo e($idLoadEdit); ?>";
        id_datatables = "<?php echo e($idDataTable); ?>";

      _datatables_show = {
        dt_datatables:function(){
        var _this = $("#"+id_datatables);
            _datatable = _this.DataTable({									
							ajax: "<?php echo e(url("{$url_datatables}")); ?>",
              columns: [
                          {
                              data: "id",
                              render: function (data, type, row, meta) {
                                  return meta.row + meta.settings._iDisplayStart + 1;
                              }
                          },
                          { 
                                data: "kode_pengajuan", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "tahun_ajaran", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "periode", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "jumlah_siswa", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "status_batal", 
                                render: function ( val, type, row ){
                                    if(val == 1)
                                    {
                                        _html = "<label class=\"label label-danger\">Batal</label>"
                                    }
                                    else
                                    {
                                      _html = "<label class=\"label label-success\">Aktif</label>"
                                    }
                                    return _html
                                  }
                          },
                          { 
                                data: "id",
                                className: "text-center",
                                render: function ( val, type, row ){
                                    var buttons = '<div class="btn-group" role="group">';
                                      buttons += '<a href=\"<?php echo e(url('pengajuan_bos/view')); ?>/'+ val +'\" title=\"Ubah Data\" class=\"btn btn-info btn-xs\"><i class=\"fa fa-eye\"></i> Lihat</a>';
                                      buttons += "</div>";
                                    return buttons
                                  }
                              },
                      ],
                                                  
                  });
							
                  return _this;
				}

			}
  
$(document).ready(function() {
  _datatables_show.dt_datatables();
});
  </script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('themes.AdminLTE.layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>