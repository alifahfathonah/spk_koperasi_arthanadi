<form  method="POST" action="<?php echo e(url($submit_url)); ?>" class="form-horizontal" name="form_crud">
  <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label class="col-lg-3 control-label">Kode Akun *</label>
    <div class="col-lg-9">
      <input type="text" class="form-control" name="f[kode_akun]" id="kode_akun" value="<?php echo e(@$item->kode_akun); ?>" placeholder="Kode Akun" required="">
    </div>
  </div>
  <div class="form-group">
      <label class="col-lg-3 control-label">Nama *</label>
      <div class="col-lg-9">
        <input type="text" class="form-control" name="f[nama_akun]" id="nama_akun" value="<?php echo e(@$item->nama_akun); ?>" placeholder="Nama Akun" required="">
      </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Golongan *</label>
    <div class="col-lg-9">
      <select name="f[golongan]" class="form-control" required="" id="golongan">
        <option value="" disabled="" selected="" hidden="">-- Pilih --</option>
        <?php foreach(@$option_golongan as $dt): ?>
          <option value="<?php echo @$dt['id'] ?>" <?= @$dt['id'] == @$item->golongan ? 'selected': null ?>><?php echo @$dt['desc'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>
  </div>
  <div class="form-group">
      <div class="col-lg-offset-3 col-lg-9">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Tutup</button>
        <button id="submit_form" type="submit" class="btn btn-success btn-save"><?php if($is_edit): ?> Perbarui <?php else: ?> Simpan <?php endif; ?> <i class="fas fa-spinner fa-spin spinner" style="display: none"></i></button> 
      </div>
  </div>
</form>
      

<script type="text/javascript">
  $('form[name="form_crud"]').on('submit',function(e) {
    e.preventDefault();
    $('.btn-save').addClass('disabled', true);
    $(".spinner").css("display", "");

    var data = {
          'golongan' : $("#golongan").val(),
          'kode_akun' : $("#kode_akun").val(),
          'nama_akun' : $("#nama_akun").val(),
        }
     data_post = {
          "f" : data,
        }

  $.post($(this).attr("action"), data_post, function(response, status, xhr) {
      if( response.status == "error"){
          $.alert_warning(response.message);
              $('.btn-save').removeClass('disabled', true);
              $(".spinner").css("display", "none");
              return false
          }
          $.alert_success(response.message);
              ajax_modal.hide();
              setTimeout(function(){
                document.location.href = "<?php echo e(url("$nameroutes")); ?>";        
              }, 500);  
      }).catch(error => {
            $.alert_error(error);
            $('.btn-save').removeClass('disabled', true);
            $(".spinner").css("display", "none");
            return false
      });
});
</script>