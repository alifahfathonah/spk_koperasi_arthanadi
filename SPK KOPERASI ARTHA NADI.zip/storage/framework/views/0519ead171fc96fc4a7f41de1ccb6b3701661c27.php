 <?php 
 $title="Pasien -";
 ?>

<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">DATA PASIEN</h3>

              <div class="box-tools pull-right">
              </div>
            </div>    
<div class="row kotak">
   <?php if(Session::get('jabatan')=='Dokter'): ?>

<?php else: ?>
<div align="left">
<!-- <a href="<?php echo e(route('pasien.create')); ?>" class="btn btn-primary"><span class="fa fa-plus"></span>
  Pasien Baru</a> -->
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalTambahPasien"><span class="fa fa-plus"></span> Pasien Baru
</button>
</div><br>
<?php endif; ?>
<table border="1" width="100%" class="table table-bordered" id="dataPasien">
	<thead>
		<tr>
			<th width="5%">No</th>
      <th>Kode Pasien</th>
      <th>Nama Pasien</th>
      <th>Tanggal Lahir</th>
      <th>Jenis Kelamin</th>
      <th>Alergi</th>
      <th>Alamat</th>
      <?php if(Session::get('jabatan')=='Dokter'): ?>
			<th>Aksi</th>
      <?php else: ?>
      <th>Aksi</th>
      <?php endif; ?>

		</tr>
	</thead>
	<tbody>
    <?php $no=1; ?>
    <?php $__currentLoopData = $pasien; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?> </td>
      <td><?php echo e($p->kd_pasien); ?></td>
      <td><?php echo e($p->nama_pasien); ?></td>
      <td><?php echo e(Carbon\Carbon::parse($p->tanggal_lahir_pasien)->formatLocalized('%d %B %Y')); ?></td>
      <td><?php echo e($p->jenis_kelamin_pasien); ?></td>
      <td><?php echo e($p->alergi); ?></td>
      <td><?php echo e($p->alamat_pasien); ?></td>
      <td>
        
        <?php if(Session::get('jabatan')=='Dokter'): ?>
            <a title="Detail Pasien" data-toggle="modal" data-target="#modalDetailPasien" data-id="<?php echo $p->id; ?>" ><span class="btn btn-warning  btn-sm"><span class="fa fa-eye"></a>
            <a title="Detail Rekam Medis" data-toggle="modal" href="<?php echo e(url('pasien/detailRekamMedis/'.$p->id)); ?>" data-id="<?php echo $p->id; ?>"><span class="btn btn-success  btn-sm"><span class="fa fa-medkit"></a>
        <?php else: ?>
            <a title="Detail Pasien" data-toggle="modal" data-target="#modalDetailPasien" data-id="<?php echo $p->id; ?>" ><span class="btn btn-warning  btn-sm"><span class="fa fa-eye"></a>
            <a title="Edit Pasien" data-toggle="modal" data-target="#modalEditPasien" data-id="<?php echo $p->id; ?>"><span class="btn btn-primary  btn-sm"><span class="fa fa-edit"></a>
            <a title="Detail Rekam Medis" data-toggle="modal" href="<?php echo e(url('pasien/detailRekamMedis/'.$p->id)); ?>" data-id="<?php echo $p->id; ?>"><span class="btn btn-success  btn-sm"><span class="fa fa-medkit"></a>
        <?php endif; ?>
      </td>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
</tbody>

</table>
</div>


<!-- kode otomastis -->
<?php

// koneksi ke mysql
include ('public/config/config.php');

// membaca kode barang terbesar
$query = "SELECT max(kd_pasien) as maxKode FROM tb_pasien";
$hasil = mysqli_query($conn,$query);
$data  = mysqli_fetch_array($hasil);
$KodePasien = $data['maxKode'];

$noUrut = (int) substr($KodePasien, 3, 3);

$noUrut++;

$char = "PS";
$newID = $char . sprintf("%03s", $noUrut);
?>
<!-- Modal Tambah Pasien-->
<div class="modal fade" id="modalTambahPasien" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header"> 
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FORM TAMBAH PASIEN</strong></h5>
      </div>
      <div class="modal-body">
        <form id="tambahpasien" method="POST" action="<?php echo e(route('pasien.store')); ?>" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>

          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Kode Pasien</label>
            <input type="text" class="form-control" name="txtKode_pasien" value="<?php echo e($newID); ?>" readonly="" required="">
          </div>
         <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">No KK</label>
            <input type="text" class="form-control" name="txtNo_kk" value="<?php echo e(old('txtNo_kk')); ?>" placeholder="No Kartu Keluarga" autofocus required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Nama Pasien</label>
            <input type="text" class="form-control" name="txtNama_pasien" value="<?php echo e(old('txtNama_pasien')); ?>" placeholder="Nama Pasien" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Tanggal Lahir</label>
            <input type="date" class="form-control" name="txtTgl_lahir" placeholder="Tanggal Lahir Pasien" required="">
          </div>
         
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Agama</label>
            <select name="txtAgama" class="form-control" required="">
              <option value="">- Pilih Agama -</option>
              <option value="Hindu">Hindu</option>
              <option value="Islam">Islam</option>
              <option value="Kristen">Kristen</option>
              <option value="Budha">Budha</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jenis Kelamin</label>
            <select name="txtJenis_kelamin" class="form-control" required="">
                <option value="">- Jenis Kelamin -</option>
                <option value="Laki-Laki">Laki-Laki</option>
                <option value="Perempuan">Perempuan</option>
            </select>
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Alergi</label>
            <input type="text" name="txtAlergi" class="form-control" placeholder="Alergi Pasien" value="<?php echo e(old('txtAlergi')); ?>" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Pekerjaan</label>
            <input type="text" class="form-control" name="txtPekerjaan" value="<?php echo e(old('txtPekerjaan')); ?>" placeholder="Pekerjaan Pasien" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Telepon</label>
            <input type="text" class="form-control" name="txtTelepon" value="<?php echo e(old('txtNo_hp')); ?>" placeholder="Telepon Pasien" required="">
          </div>
          <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Jaminan Kesehatan</label>
            <input type="text" name="txtJamkes" class="form-control" placeholder="Jaminan Kesehatan" value="<?php echo e(old('txtJamkes')); ?>" required="">
          </div>
           <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Alamat</label>
            <textarea name="txtAlamat" class="form-control" rows="2" placeholder="Alamat Pasien" required=""><?php echo e(old('txtAlamat')); ?></textarea>           
          </div>
          
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Simpan</button>
          <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
        </div>
      </form>
      
      </div>
       
     
    </div>
  </div>
</div>

<!-- modal detail pasien-->
<div class="modal fade" id="modalDetailPasien" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>DETAIL PASIEN</strong></h5>
      </div>
      <div class="modal-body" id="loadDetailPasien">
        
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<!-- modal detail rekam medis-->
<div class="modal fade" id="modalDetailRekamMedisPasien" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>DETAIL REKAM MEDIS PASIEN</strong></h5>
      </div>
      <div class="modal-body" id="loadDetailRekamMedisPasien">
        
      
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Cetak Laporan Rekam Medis</button>
        <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
      </div>
    </div>
  </div>
</div>

<!-- modal edit pasien -->
<div class="modal fade" id="modalEditPasien" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FORM UBAH DATA PASIEN</strong></h5>
      </div>
      <div class="modal-body" id="loadEditPasien">
        
      
      </div>

    </div>
  </div>
</div>

<!-- modal hapus produk -->
<div class="modal" tabindex="-1" role="dialog" id="modalHapusProduk">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title">Warning !</h5>
      </div>

      <div class="modal-body" id="loadHapusProduk">
        
      </div>
      
    </div>
  </div>
</div>

<script type="text/javascript">
$(document).ready(function() {
    var t = $('#dataPasien').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0,
        } ],
        "order": [[ 1, 'desc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );


</script> 
<script>
$(document).ready(function(){
  $('[data-toggle="modal"]').tooltip();   
});
</script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>