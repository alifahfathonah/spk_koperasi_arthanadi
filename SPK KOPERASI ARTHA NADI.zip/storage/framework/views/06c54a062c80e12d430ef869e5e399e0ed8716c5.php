 <?php 
 $title="Laporan Obat -";
 ?>

<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">LAPORAN DATA OBAT</h3>

              <div class="box-tools pull-right">
              </div>
            </div> 
<div class="row kotak">

<table border="1" width="100%" class="table table-bordered" id="dataobat">
  <thead>
    <tr>
      <th width="5%">No</th>
      <th width="15%">Kode Obat</th>
      <th width="25%">Nama Obat</th>
      <th width="15%">Kategori</th>
      <th width="10%">Stok</th>
      <th width="15%">Jenis Obat</th>
      <th width="15%">Satuan</th>
    </tr>
  </thead>
  <tbody>
     <?php

      $no=1;
      ?>
      <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?> </td>
      <td><?php echo e($o->kd_obat); ?></td>
      <td><?php echo e($o->nama_obat); ?></td>
      <td><?php echo e($o->kategori_obat); ?></td>
      <td><?php echo e($o->stok_obat); ?></td>
      <td><?php echo e($o->jenis_obat); ?></td>
      <td><?php echo e($o->satuan_obat); ?></td>
    
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
</tbody>

</table>



<script type="text/javascript">
$(document).ready(function() {
    var t = $('#dataobat').DataTable( {
      "dom": 'Bfrtip',
      "paging": true,
      "autoWidth": true,
      lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ],
        buttons: [
         'pageLength',
          {
                title: 'LAPORAN DATA OBAT' +'\n' + 'UPT. PUSKESMAS SUSUT I BANGLI',
                text: 'Cetak',
                extend: 'pdfHtml5',
                orientation: 'portait',
                pageSize: 'A4',
                filename: 'laporan_data_obat',
                messageTop: function() {
                return $('#awal').val()
                  }
            },

        ],
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0,
        } ],
        "order": [[ 1, 'desc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );


</script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>