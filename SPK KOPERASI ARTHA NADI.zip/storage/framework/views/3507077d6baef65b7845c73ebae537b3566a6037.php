<?php
$title="- Detail Produk";
?>
<table class="table">
<tr>
	<td> Nama Produk</td>
	<td>:</td>
	<td><?php echo e($produk->nama_produk); ?></td>
</tr>
<tr>
	<td>Deskripsi</td>
	<td>:</td>
	<td><?php echo ($produk->deskripsi); ?></td>
</tr>
<tr>
	<td>Fitur</td>
	<td>:</td>
	<td><?php echo ($produk->fitur); ?></td>
</tr>
<tr>
	<td>Studi Kasus</td>
	<td>:</td>
	<td><?php echo ($produk->studi_kasus); ?></td>
</tr>

<tr>
	<td>Kategori</td>
	<td>:</td>
	<td><?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($produk->category==$k->id): ?>
					<?php echo e($k->nama_category); ?>

			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</td>
</tr>
<tr>
	<td>Status</td>
	<td>:</td>
	<td><?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($produk->status==$l->id): ?>
					<?php echo e($l->nama_status); ?>

			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</td>
</tr>
<tr>
	<td>Dibuat</td>
	<td>:</td>
	<td><?php echo e($produk->created_at); ?></td>
</tr>
<tr>
	<td>Gambar</td>
	<td>:</td>
	<td><?php $__currentLoopData = $gambar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($produk->id==$m->produk_id): ?>
<img src="<?php echo e(asset('public/image/produk/'.$m->image)); ?>" width="150px" height="150px">
<?php endif; ?>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
</tr>	
<tr>
	<td>Video</td>
	<td>:</td>
	<td><?php echo ($produk->link_video); ?></td>
</tr>
</table>