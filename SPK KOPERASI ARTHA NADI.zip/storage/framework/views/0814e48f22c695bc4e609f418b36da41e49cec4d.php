<form action="<?php echo e(route ('penyewa.update',[$penyewa->id])); ?>" method="POST" id="formEditPenyewa" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($penyewa->id); ?>">
   
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">ID Penyewa</label>
    <input type="text" class="form-control" name="txtIdPenyewa" value="<?php echo e($penyewa->penyewa_id); ?>" readonly="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Nama Penyewa</label>
    <input type="text" class="form-control" name="txtNamaPenyewa" value="<?php echo e($penyewa->nama_penyewa); ?>" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Jenis Kelamin</label>
    <select name="txtJenisKelamin" class="form-control" required="">
            <option value="<?php echo e($penyewa->jenis_kelamin); ?>">
                <?php if($penyewa->jenis_kelamin=='L'): ?>
                    <?php echo e("Laki-Laki"); ?>

                <?php else: ?>
                    <?php echo e("Perempuan"); ?>

                <?php endif; ?>
            </option>
            <?php if($penyewa->jenis_kelamin=='L'): ?>
              <option value="P">Perempuan</option>
            <?php else: ?>
              <option value="L">Laki-Laki</option>
            <?php endif; ?>
    </select>
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Nama Band</label>
    <input type="text" class="form-control" name="txtNamaBand" value="<?php echo e($penyewa->nama_band); ?>" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Telepon</label>
    <input type="text" class="form-control" name="txtTelepon" value="<?php echo e($penyewa->no_telepon); ?>" required="">
</div>

<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Alamat</label>
    <textarea name="txtAlamat" class="form-control" rows="2" required=""><?php echo e($penyewa->alamat); ?></textarea>           
</div>

<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Status</label>
    <select name="txtStatus" class="form-control" required="">
        <option value="<?php echo e($penyewa->status); ?>"><?php echo e($penyewa->status); ?></option>
            <?php if($penyewa->status=='Aktif'): ?>
              <option value="Tidak Aktif">Tidak Aktif</option>
            <?php else: ?>
              <option value="Aktif">Aktif</option>
            <?php endif; ?>
    </select>
</div>
<div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Username</label>
        <input type="text" class="form-control" name="txtUsername" value="<?php echo e($penyewa->username); ?>" required="">
</div>
<div class="form-group">
        <label for="name" class="cols-sm-2 control-label">Password</label>
        <input type="password" class="form-control" name="txtPassword" value="<?php echo e($penyewa->password); ?>"  required="">
</div>

 <div class="form-group">
        <label for="exampleInputFile">Foto</label><br>
        <img src="<?php echo e(asset('public/image/foto_penyewa/'.$penyewa->foto)); ?>" style="width: 100px;" id="profile-img-tag_p2"><br>
</div>
<div class="form-group">
        <label for="exampleInputFile">Ganti Foto</label><br>
        <input type="file" name="txtFoto" id="profile-img_p2" class="form-control"><br>
</div>
<div class="modal-footer">
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
</div>
</form>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag_p2').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img_p2").change(function(){
        readURL(this);
    });
</script>