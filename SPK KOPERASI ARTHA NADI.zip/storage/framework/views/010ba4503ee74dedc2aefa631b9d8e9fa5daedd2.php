<form action="<?php echo e(url('user/aksi_delete/'.$user->id)); ?>" id="formDeleteUser" method="POST" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

<input type="hidden" name="id" value="<?php echo e($user->id); ?>">
	Apakah Anda yakin menghapus data user ini?
<div class="form-group">

</div>
<?php echo $__env->make('layouts.modal_footer_hapus', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>