 <?php 
 $title="Lembar Disposisi |";
 ?>

<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">LEMBAR DISPOSISI</h3>

              <div class="box-tools pull-right">
              </div>
            </div> 
<div class="row kotak">
<div class="col-xs-12">
<div align="right" style="margin-bottom: 10px;">
    <a href="<?php echo e(url('surat_masuk/cetak/'.$suratMasuk->id)); ?>" class="btn btn-primary" target="blank">Cetak</a>
    <a href="javascript:history.go(-1)" class="btn btn-danger">Batal</a>
</div>


<input type="hidden" name="id" value="">
<table class="table" border="1">
    <tr>
        <td colspan="5" align="center"><h2>LEMBAR DISPOSISI</h2></td>
    </tr>
    <tr>
        <th width="25%">Indexs : </th>
        <th colspan="2" width="25%">Kode : <?php echo e($suratMasuk->kode_surat); ?></th>
        <th width="25%">No Urut</th>
        <th width="25%">Tgl Penyelesaian</th>
    </tr>
    <tr>
        <th colspan="5" style="padding-bottom: 60px;">Perihal Isi Ringkasan <br> <?php echo e($suratMasuk->perihal_surat_masuk); ?></th>
    </tr>
    <tr>
        <th colspan="2">Asal Surat : <?php echo e($suratMasuk->asal_surat_masuk); ?></th>
        <th>Tgl : <?php echo e(Carbon\Carbon::parse($suratMasuk->tanggal_surat_masuk)->formatLocalized('%d %b %Y')); ?></th>
        <th>Nomor : <?php echo e($suratMasuk->no_surat_masuk); ?></th>
        <th>Lampiran</th>
    </tr>
    <tr>
        <th colspan="2" style="padding-bottom: 250px;">Diajukan diteruskan Kepada : <?php echo e($suratMasuk->jabatan); ?></th>
        <th colspan="3">Instruksi / Informasi</th>
    </tr>
</table>
</div>
</div>
</div>   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>