<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<table border="1" width="100%" class="table table-bordered table-hover" id="<?php echo e($idDataTable); ?>">
	<thead>
		<tr>
			<th width="5%">No</th>
      <th>Kode Aturan</th>
      <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th><?php echo e($c->nama_kriteria); ?></th>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <th>Klasifikasi</th>
      <?php if(Session::get('jabatan')=='Direktur'): ?>
      <?php else: ?>
        <th>Aksi</th>
      <?php endif; ?>
		</tr>
	</thead>
<tbody>
    <?php $no=1; ?>
    <?php $__currentLoopData = $dataAturan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?></td>
      <td><?php echo e($b->kode_aturan); ?></td>
      <?php $__currentLoopData = $detailDataAturan->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($b->kode_aturan==$c->kode_aturan): ?>
                <td><?php echo e($c->keterangan); ?></td>
            <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <td><?php echo e($b->klasifikasi); ?></td>
      <?php if(Session::get('jabatan')=='Direktur'): ?>
      <?php else: ?>
      <td> 
          <a title="<?php echo e($headerModalEdit); ?>" data-toggle="modal" data-target="#<?php echo e($idModalEdit); ?>" data-id="<?php echo $b->id; ?>" ><i class="btn fa fa-edit fa-lg" style="color: coral"></i></a> |
          <a title="<?php echo e($headerModalHapus); ?>" data-toggle="modal" data-target="#<?php echo e($idModalHapus); ?>" data-id="<?php echo $b->id; ?>" ><i class="btn fa fa-trash fa-lg" style="color: red"></i></a>
      </td>
      <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>

<!-- MODAL HAPUS ATURAN -->
<div class="modal fade" id="<?php echo e($idModalHapus); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>PERHATIAN!</strong></h5>
      </div>
      <div class="modal-body" id="loadDeleteAturan">
            
    </div>
  </div>
  </div>
</div>

<!-- modal kosongkan data aturan-->
<div class="modal fade" id="modalKosongkanDataAturan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>PERHATIAN!</strong></h5>
      </div>
      <div class="modal-body" id="loadKosongkanDataAturan">
        
      
      </div>
    </div>
  </div>
</div>

<!-- MODAL TAMBAH & EDIT--> 
<?php echo $__env->make('layouts.header_modal_tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('data_aturan.tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.modal_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- DataTable -->
<?php echo $__env->make('layouts.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>