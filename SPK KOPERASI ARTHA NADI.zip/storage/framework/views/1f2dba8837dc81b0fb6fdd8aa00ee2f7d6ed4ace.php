 <?php 
 $title="Laporan Register Pasien |";
 ?>
<?php $__env->startSection('content'); ?>
<div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title">Laporan Register Pasien Per Kecamatan</h3>
      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
      </div>
  </div>
<div class="row kotak">
<div class="box-body">
<div align="left">


<!-- FILTER DATA -->
<form action="<?php echo e(url('/laporan/register-pasien/filter')); ?>" method="GET">
<div class="modal fade" id="modalFilterKecamatan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FILTER KECAMATAN</strong></h5>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label for="name" class="col-sm-2 control-label tengah2">Sampai</label>
          <div class="col-md-10">
           <select name="kecamatan" class="form-control" id="select2" required="" style="width: 100%">
              <option value="">- Pilih Kecamatan - </option>
                <?php $__currentLoopData = $filterKecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e(ucfirst($nk->kecamatan)); ?>"> <?php echo e(ucfirst($nk->kecamatan)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        	</div>
        </div>
      </div>
      <div class="modal-footer" style="border-top: 0px;">
        <input type="submit" name="btnCari" value="Tampilkan" class="btn btn-success tombolform">
        <button type="button" class="btn btn-warning tombolform" data-dismiss="modal">Tutup</button>
      </div>
    
    </div>
  </div>
</div>
</form>




<table width="100%">
  <tr>
    <td width="20%">
       <button type="button" title="Filter Kecamatan"  class="btn btn-success" data-toggle="modal" data-target="#modalFilterKecamatan"><span class="fa fa-search"></span> Filter Kecamatan</button>
        <?php
      if(isset($_GET['btnCari'])){
    ?>
	   <a href="<?php echo e(url('/laporan/register-pasien/cetak/'.$id)); ?>" class="btn btn-primary" target="blank" data-toggle="modal" title="Cetak PDF">Cetak PDF</a>
    <?php
      }else{
      ?>
      	<a href="<?php echo e(url('/laporan/register-pasien/cetak')); ?>" class="btn btn-primary" target="blank" data-toggle="modal" title="Cetak PDF">Cetak PDF</a>
      <?php
      }
    ?>
        
    </td>
    <td align="right">Jumlah Kecamatan : <?php echo e($namaKecamatan->total()); ?></td>
    
  </tr>
</table>
<br>

<style type="text/css">
  #borderxx{
    border: 1px solid #e4e0e0
  }
</style>


 <div class="row">
        <?php $__currentLoopData = $namaKecamatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <div class="box box-solid" id="borderxx">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(strtoupper($nk->kecamatan)); ?></h3>
            </div>
            <!-- /.box-header -->
                   <div class="box-body">
              <table width="100%" style="line-height: 1.5em;">
                <tr>
                  <td width="40%">Kecamatan</td>
                  <td>:</td>
                  <td><?php echo e(ucfirst($nk->kecamatan)); ?></td>
                </tr>
                <tr>
                  <td>Kabupaten</td>
                  <td>:</td>
                  <td><?php echo e(ucfirst($nk->kabupaten)); ?></td>
                </tr>
                <tr>
                  <td>Jumlah Pasien</td>
                  <td>:</td>
                  <td><?php echo e($nk->jumlah_pasien); ?></td>
                </tr>
                <tr>
                  <td>Pekerjaan Terbanyak</td>
                  <td>:</td>
                  <td><?php $__currentLoopData = $pekerjaanTerbanyak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key==$nk->kecamatan): ?>
                            <?php echo e(ucfirst($value['nama'])); ?>

                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                </tr>
                <tr>
                  <td>Pendidikan Terbanyak</td>
                  <td>:</td>
                  <td>
                    <?php $__currentLoopData = $pendidikanTerbanyak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key==$nk->kecamatan): ?>
                            <?php echo e(ucfirst($value['nama'])); ?>

                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                </tr>
                <tr>
                  <td>Usia Terbanyak</td>
                  <td>:</td>
                  <td>
                      <?php $__currentLoopData = $usiaTerbanyak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key==$nk->kecamatan): ?>
                            <?php echo e(ucfirst($value['nama'])); ?> Tahun
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                </tr>
                <tr>
                  <td>Penyakit Terbanyak</td>
                  <td>:</td>
                  <td>
                    <?php $__currentLoopData = $penyakitTerbanyak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key==$nk->kecamatan): ?>
                            <?php echo e(str_limit($value['nama'],30)); ?>

                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                </tr>
                <tr>
                  <td>Pasien BPJS</td>
                  <td>:</td>
                  <td><?php $__currentLoopData = $bpjs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($bp->kecamatan==$nk->kecamatan): ?>
                          <?php echo e($bp->jumlah); ?>

                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                </tr>
                <tr>
                  <td>Pasien UMUM</td>
                  <td>:</td>
                  <td><?php $__currentLoopData = $umum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($bp->kecamatan==$nk->kecamatan): ?>
                        <?php echo e($bp->jumlah); ?>

                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                </tr>
                <tr>
                  <td>Pasien IKS</td>
                  <td>:</td>
                  <td><?php $__currentLoopData = $iks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($bp->kecamatan==$nk->kecamatan): ?>
                          <?php echo e($bp->jumlah); ?>

                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                </tr>
                <tr>
                  <td>Pasien Eksekutif</td>
                  <td>:</td>
                  <td><?php $__currentLoopData = $eksekutif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($bp->kecamatan==$nk->kecamatan): ?>
                          <?php echo e($bp->jumlah); ?>

                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                </tr>
              </table>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- ./col -->
       
        <!-- ========================================= -->
        <!-- ./col -->
      </div>
      <!-- /.row -->
<div align="right"><?php echo e($namaKecamatan->links()); ?></div>

</div></div></div></div>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>