
</style>
 <!DOCTYPE html>
 <html>
 <head>
     <title></title>
      <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>SMK PGRI 1 DENPASAR</title>

        <!-- Styles -->

      
      <!-- <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>"> -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <?php echo Html::style('assets/plugin/bootstrap/dist/css/bootstrap.min.css'); ?>

        <?php echo Html::style('assets/plugin/font-awesome/css/font-awesome.min.css'); ?>

        <?php echo Html::style('assets/dist/css/AdminLTE.min.css'); ?>

        <?php echo Html::style('assets/login.css'); ?>

 </head>
 <body>
        <div class="col-md-5 wraplogin">
            <div class="login-logo">
                 <img  src="<?php echo e(asset('assets/images/logo.png')); ?> ">
            </div>
           
            <div class="account-wall">
                <form class="form-signin" method="POST" action="<?php echo e(URL('login')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <p class="login-box-msg"> <strong>PT. M.TANI MAJU MUNDUR</strong></p>

                    <div class="form-group has-feedback <?php echo e($errors->has('username') ? ' has-error' : ''); ?>" >
                        <input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username">
                        <span class="glyphicon glyphicon-user form-control-feedback"></span>
                        <?php if($errors->has('username')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('username')); ?></strong>
                            </span>
                        <?php endif; ?>
                     </div>

                    <div class="form-group has-feedback <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <input id="password" type="password" class="form-control" name="password"  placeholder="Password">
                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>      
                    </div>

                    <div class="row">
                        <div class="col-xs-8">
                          
                                    
                                     <input type="checkbox" name="lihatPassword" onclick="LihatPass()" id="lihatPassword"> 
                                <label for="lihatPassword">Lihat Password</label>
                            
        
                        </div>
        <!-- /.col -->
                        <div class="col-xs-4">
                          <button type="submit" class="btn btn-primary btn-block btn-flat" id="btnLogin">Login</button>
                        </div>
        <!-- /.col -->
                    </div>
                </form>
                </div>
            </div>
 </body>
 </html>