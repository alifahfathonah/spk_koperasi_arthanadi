<form action="<?php echo e(route ('slide.update',[$slide->id])); ?>" method="POST" id="formEditSlide" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

<div class="form-group">
  <input type="hidden" name="id" value="<?php echo e($slide->id); ?>">
    <label for="nama">Title</label>
    <input type="text" class="form-control" name="txtNama" value="<?php echo e($slide->title); ?>">
</div>
<div class="form-group">
    <label for="image">Gambar Slide</label><br>
    <img src="<?php echo e(asset('public/image/slide/'.$slide->slide)); ?>" width="150px" height="150px" id="profile-img-tag2"><br>
    <input type="file" name="txtImage" id="profile-img2">
</div>
<div class="form-group">
    <label for="ket">Keterangan</label>
    <textarea name="txtKeterangan" id="" cols="30" rows="4" class="form-control"><?php echo e($slide->keterangan); ?></textarea>
</div>
<div class="form-group">
           <label>Status</label>
              <select class="form-control" name="txtStatus">
                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k->id); ?>" <?php if($slide->status==$k->id): ?> selected <?php endif; ?>><?php echo e($k->nama_status); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
                <?php if($errors->has('txtStatus')): ?>
                        <span class="help-block">
                            <strong style="color: red;"><?php echo e($errors->first('txtStatus')); ?></strong>
                        </span>
                    <?php endif; ?>
        </div>
<div class="modal-footer">
    <button type="submit" class="btn btn-primary">Simpan</button>
    <button type="button" class="btn btn-warning" data-dismiss="modal">Batal</button>
</div>
</form>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#profile-img-tag2').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#profile-img2").change(function(){
        readURL(this);
    });
</script>