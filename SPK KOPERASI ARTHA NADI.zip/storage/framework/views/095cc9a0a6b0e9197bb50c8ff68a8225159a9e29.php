<?php
$title="- Detail Obat";
?>
<table class="table">
<tr>
	<td>Kode Obat</td>
	<td>:</td>
	<td><?php echo e($obat->kd_obat); ?></td>
</tr>
<tr>
	<td>Nama Obat</td>
	<td>:</td>
	<td><?php echo e($obat->nama_obat); ?></td>
</tr>
<tr>
	<td>Jenis Obat</td>
	<td>:</td>
	<td><?php echo e($obat->jenis_obat); ?></td>
</tr>
<tr>
	<td>Kategori Obat</td>
	<td>:</td>
	<td><?php echo e($obat->kategori_obat); ?></td>
</tr>
<tr>
	<td>Stok</td>
	<td>:</td>
	<td><?php echo e($obat->stok_obat); ?></td>
</tr>

<tr>
	<td>Satuan</td>
	<td>:</td>
	<td><?php echo e($obat->satuan_obat); ?>

	</td>
</tr>
</table>