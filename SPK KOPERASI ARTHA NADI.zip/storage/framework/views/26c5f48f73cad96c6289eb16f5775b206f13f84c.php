<form  method="POST" action="" class="form-horizontal" name="form_crud">
	<?php echo e(csrf_field()); ?>

	  <div class="form-group">
		<label class="col-lg-3 control-label">Deskripsi *</label>
		<div class="col-lg-9">
		  <input type="text" class="form-control" name="f[deskripsi]" id="deskripsi" value="<?php echo e(@$item->deskripsi); ?>" placeholder="Deskripsi" required="">
		</div>
	  </div>
	  <div class="form-group">
		<label class="col-lg-3 control-label">Nominal *</label>
		<div class="col-lg-9">
		  <input type="text" class="form-control mask-number" name="f[jumlah]" id="jumlah" value="<?php echo e(@$item->jumlah); ?>" placeholder="Jumlah" required="">
		</div>
	  </div>
	<div class="form-group">
		<div class="col-lg-offset-3 col-lg-9">
		  <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i> Tutup</button>
		  <button id="btn_submit_detail" type="submit" class="btn btn-success"><i class="fa fa-check" aria-hidden="true"></i> Simpan</button> 
		</div>
	</div>
  </form>
		
<script type="text/javascript">//<![CDATA[
	$("button#btn_submit_detail").on("click", function(e) {
        e.preventDefault();
        if( $("#deskripsi").val() == null || $("#jumlah").val() == null) {
            message = "Silahkan lengkapi data terlebih dahulu";
            $.alert_warning( message );
            return;
        }
        let deskripsi = $("#deskripsi").val();
        check = $("#dt_detail_pengeluaran").DataTable().rows( function ( idx, data, node ) {
                    return data.deskripsi === deskripsi ?	true : false;
                } ).data();

        if ( check.any() )
        {	
            message = "Kategori yang sama sudah ada pada list";
            $.alert_error( message );
            return;
        }
        try {                                        
            var collections = {
                    "jumlah": mask_number.currency_remove($("#jumlah").val()),
                    "deskripsi":$("#deskripsi").val(),
                };
   
            $("#dt_detail_pengeluaran").DataTable().row.add( collections ).draw();
			ajax_modal.hide();
			$('body').removeClass('modal-open');
			$('.modal-backdrop').remove();
			$('body').removeAttr("style");
                
        } catch (e){console.log();}
    });

	$(document).ready(function() {
		$('.select2').select2({
		dropdownParent: $("#ajax-modal")
		});
		mask_number.init();
	});
	//]]></script>
	