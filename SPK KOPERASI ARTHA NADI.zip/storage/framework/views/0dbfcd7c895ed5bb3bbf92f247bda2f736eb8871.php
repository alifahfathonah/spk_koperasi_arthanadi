<?php $__env->startSection('breadcrumb'); ?>  
  <h1>
    <?php echo e(@$title); ?>

  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Master</a></li>
    <li class="active"><?php echo e(@$title); ?></li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
    <div class="box">
      <div class="box-header">
        <h3 class="box-title"><?php echo e(@$title); ?></h3>
        <div class="box-tools pull-right">
          <?php if(Helpers::isKepalaSekolah()): ?>
          <?php else: ?>
            <div class="btn-group">
              <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
              Tindakan <i class="fa fa-wrench"></i></button>
              <ul class="dropdown-menu" role="menu">
                <li><a href="" id="modalCreate"><i class="fa fa-plus" aria-hidden="true"></i> Tambah Baru</a></li>
              </ul>
            </div>
          <?php endif; ?>
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
          </button>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <table class="table table-striped table-bordered table-hover" id="<?php echo e($idDatatables); ?>" width="100%">   
            <thead>
              <tr>
                <th class="no-sort">No</th>
                <th>Nama Jabatan</th>
                <th>Status Jabatan</th>
                <?php if(Helpers::isKepalaSekolah()): ?>
                <?php else: ?>
                  <th class="no-sort">Aksi</th>
                <?php endif; ?>
              </tr>
            </thead>
            <tbody>
            
          </tbody>
          </table>
      </div>
    </div>

<!-- DataTable -->
<script type="text/javascript">
    let lookup = {
      lookup_modal_create: function() {
          $('#modalCreate').on( "click", function(e){
            e.preventDefault();
            var _prop= {
              _this : $( this ),
              remote : "<?php echo e(url("$nameroutes")); ?>/create",
              size : 'modal-md',
              title : "<?= @$headerModalTambah ?>",
            }
            ajax_modal.show(_prop);											
          });  
        },
    };
    let _datatables_show = {
      dt_jabatan:function(){
        var _this = $("#<?php echo e($idDatatables); ?>");
            _datatable = _this.DataTable({									
							ajax: "<?php echo e(url($urlDatatables)); ?>",
              columns: [
                          {
                              data: "id",
                              className: "text-center",
                              render: function (data, type, row, meta) {
                                  return meta.row + meta.settings._iDisplayStart + 1;
                              }
                          },
                          { 
                                data: "jabatan", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "status_jabatan", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          <?php if(Helpers::isKepalaSekolah()): ?>
                          <?php else: ?>
                          { 
                                data: "id",
                                className: "text-center",
                                render: function ( val, type, row ){
                                    var buttons = '<div class="btn-group" role="group">';
                                      buttons += '<a class=\"btn btn-info btn-xs modalEdit\"><i class=\"fa fa-pencil\"></i> Ubah</a>';
                                      buttons += "</div>";
                                    return buttons
                                  }
                              },
                          <?php endif; ?>
                      ],
                      createdRow: function ( row, data, index ){		
                        $( row ).on( "click", ".modalEdit",  function(e){
                            e.preventDefault();
                            var id = data.id;
                            var _prop= {
                                _this : $( this ),
                                remote : "<?php echo e(url("$nameroutes")); ?>/edit/" + id,
                                size : 'modal-md',
                                title : "<?= @$headerModalEdit ?>",
                            }
                            ajax_modal.show(_prop);											
                        })

                      }
                                                  
                  });
							
                  return _this;
				}
			}

$(document).ready(function() {
    _datatables_show.dt_jabatan();
    lookup.lookup_modal_create();
});
</script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('themes.AdminLTE.layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>