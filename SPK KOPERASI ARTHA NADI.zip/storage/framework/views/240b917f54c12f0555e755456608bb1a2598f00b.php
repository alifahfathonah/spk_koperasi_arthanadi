
<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	    <title><?php echo e($title); ?> SIGASOM </title>
  	<!-- Tell the browser to be responsive to screen width -->
  	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<?php echo Html::style('public/assets/plugin/bootstrap/dist/css/bootstrap.min.css'); ?>

	<?php echo Html::style('public/assets/plugin/font-awesome/css/font-awesome.min.css'); ?>

	<?php echo Html::style('public/assets/dist/css/AdminLTE.min.css'); ?>

	<?php echo Html::style('public/assets/dist/css/skins/_all-skins.min.css'); ?>

	<?php echo Html::style('public/assets/plugin/datatables/dataTables.bootstrap.css'); ?>

	<?php echo Html::style('public/assets/plugin/datatables/responsive.dataTables.min.css'); ?>

	<?php echo Html::style('public/assets/select2/select2.min.css'); ?>

	<?php echo Html::style('public/assets/dist/css/bootstrap-datepicker.min.css'); ?>

	<?php echo Html::style('public/css/buttons.dataTables.min.css'); ?>

	<?php echo Html::style('public/css/bootstrap-select.min.css'); ?>

	<?php echo Html::style('public/css/toastr.min.css'); ?>




	
	<script src="<?php echo e(url('public/js/jquery.js')); ?>"></script>
	<script src="<?php echo e(url('public/js/chartjs/Chart.js')); ?>"></script>

	<!-- loading harap tunggu -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('public/css/loading.css')); ?>"> 
	<script type="text/javascript" src="<?php echo e(url('public/js/loading.js')); ?>"></script>
	 <!-- end -->
  

   <link rel="shortcut icon" href="<?php echo e(url('public/image/House.ico')); ?>">
   <script type="text/javascript" src="<?php echo e(url('public/js/toastr.min.js')); ?>"></script>
   <script src="<?php echo e(url('public/js/bootstrap-select.min.js')); ?>"></script>


	
</head>
