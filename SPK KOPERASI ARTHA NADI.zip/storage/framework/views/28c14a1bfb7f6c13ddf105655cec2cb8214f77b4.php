<section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel" style="border: 0px solid #ddd;background-color: #0e1315">
        <div class="pull-left image">
          <img src="" class="img-circle" alt="User Image" >
        </div>

        <div class="pull-left info">
          <p><!-- <?php echo e(Session::get('jabatan')); ?> --></p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i><!--  <?php echo e(Session::get('nama_pegawai')); ?> --></a>
        </div>

      </div>


      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
         
          <li class="<?php echo e(Request::is('dashboard')?'active':null); ?>"><a href="<?php echo e(url('/dashboard')); ?>"><i class="fa fa-university"></i><span> Dashboard</span></a></li>
          <!-- <li class="header">MASTER DATA</li> -->
         <li class="<?php echo e(Request::is('pengguna')?'active':null); ?>"><a href="<?php echo e(url('/pengguna')); ?>"><i class="fa fa-envelope"></i> <span>Data Pengguna</span></a></li>
        <li class=""><a href=""><i class="fa fa-envelope"></i> <span>Data Biaya Kuliah</span></a></li>
        <li class="<?php echo e(Request::is('mahasiswa')?'active':null); ?>"><a href="<?php echo e(url('/mahasiswa')); ?>"><i class="fa fa-paper-plane-o"></i> <span>Data Mahasiswa</span></a></li>
        <li class=""><a href=""><i class="fa fa-list-alt"></i> <span>Data Pengajuan Dana</span></a></li>
        <li class=""><a href=""><i class="fa fa-list-alt"></i> <span>Transaksi Pengeluaran</span></a></li>
         <li class=""><a href=""><i class="fa fa-list-alt"></i> <span>Transaksi Pemasukan</span></a></li>

        <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>Laporan</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href=""><i class="fa fa-file-text-o"></i> <span>Laporan Pengeluaran</span></a></li>
            <li class=""><a href=""><i class="fa fa-file-text-o"></i> <span>Laporan Pemasukan</span></a></li>
            <li class=""><a href=""><i class="fa fa-file-text-o"></i> <span>Laporan Pembayaran Kuliah</span></a></li>
            <li class=""><a href=""><i class="fa fa-file-text-o"></i> <span>Laporan Arus Kas</span></a></li>
            <li class=""><a href=""><i class="fa fa-file-text-o"></i> <span>Laporan Arus Kas Keseluruhan</span></a></li>
          </ul>
        </li>

        
      </ul>
      <!-- /.sidebar-menu -->
</section>