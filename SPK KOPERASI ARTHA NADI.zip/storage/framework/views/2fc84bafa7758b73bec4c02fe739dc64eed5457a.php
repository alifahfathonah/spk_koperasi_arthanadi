<form action="<?php echo e(route ('pasien.update',[$pasien->id])); ?>" method="POST" id="formEditPasien" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($pasien->id); ?>">
   
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">No KK</label>
    <input type="text" class="form-control" name="txtNo_kk" value="<?php echo e($pasien->no_kk); ?>" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Nama Pasien</label>
    <input type="text" class="form-control" name="txtNama_pasien" placeholder="Masukkan Nama Pasien" value="<?php echo e($pasien->nama_pasien); ?>" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Tanggal Lahir</label>
    <input type="date" class="form-control" name="txtTgl_lahir" value="<?php echo e($pasien->tanggal_lahir_pasien); ?>" placeholder="Masukkan Tanggal Lahir Pasien" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Agama</label>
    <select name="txtAgama" class="form-control" required="">
        <option value="<?php echo e($pasien->agama_pasien); ?>"><?php echo e($pasien->agama_pasien); ?></option>
            <?php if($pasien->agama_pasien=='Hindu'): ?>
                <option value="Islam">Islam</option>
                <option value="Kristen">Kristen</option>
                <option value="Budha">Budha</option>
            <?php elseif($pasien->agama_pasien=='Islam'): ?>
                <option value="Hindu">Hindu</option>
                <option value="Kristen">Kristen</option>
                <option value="Budha">Budha</option>
            <?php elseif($pasien->agama_pasien=='Kristen'): ?>
                <option value="Hindu">Hindu</option>
                <option value="Islam">Islam</option>
                <option value="Budha">Budha</option>
            <?php else: ?>
                <option value="Hindu">Hindu</option>
                <option value="Islam">Islam</option>
                <option value="Kristen">Kristen</option>
            <?php endif; ?>
      </select>
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Jenis Kelamin</label>
    <select name="txtJenis_kelamin" class="form-control" required="">
        <option value="<?php echo e($pasien->jenis_kelamin_pasien); ?>"><?php echo e($pasien->jenis_kelamin_pasien); ?></option>
            <?php if($pasien->jenis_kelamin_pasien=='Laki-Laki'): ?>
              <option value="Perempuan">Perempuan</option>
            <?php else: ?>
              <option value="Laki-Laki">Laki-Laki</option>
            <?php endif; ?>
    </select>
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Alergi</label>
    <input type="text" name="txtAlergi" class="form-control" placeholder="Masukkan Alergi Pasien" value="<?php echo e($pasien->alergi); ?>" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Pekerjaan</label>
    <input type="text" class="form-control" name="txtPekerjaan" value="<?php echo e($pasien->pekerjaan); ?>" placeholder="Masukkan Pekerjaan Pasien" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Telepon</label>
    <input type="text" class="form-control" name="txtTelepon" value="<?php echo e($pasien->no_hp_pasien); ?>" placeholder="Masukkan Telepon Pasien" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Jaminan Kesehatan</label>
    <input type="text" name="txtJamkes" class="form-control" value="<?php echo e($pasien->jamkes); ?>" required="">
</div>
<div class="form-group">
    <label for="name" class="cols-sm-2 control-label">Alamat</label>
    <textarea name="txtAlamat" class="form-control" rows="2" placeholder="Masukkan Alamat Pasien" required=""><?php echo e($pasien->alamat_pasien); ?></textarea>
</div>

<div class="modal-footer">
    <button type="submit" class="btn btn-primary">Perbarui</button>
    <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
</div>
</form>
