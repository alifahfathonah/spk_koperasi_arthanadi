<?php echo Html::script('assets/plugin/jquery/dist/jquery.min.js'); ?>

<?php echo Html::script('assets/plugin/bootstrap/dist/js/bootstrap.min.js'); ?>

<?php echo Html::script('assets/dist/js/adminlte.min.js'); ?>

<?php echo Html::script('assets/dist/js/demo.js'); ?>

<?php echo Html::script('assets/plugin/datatables/jquery.dataTables.min.js'); ?>

<?php echo Html::script('assets/plugin/datatables/dataTables.bootstrap.min.js'); ?>

<?php echo Html::script('assets/plugin/datatables/dataTables.responsive.min.js'); ?>

<?php echo Html::script('assets/plugin/datatables/responsive.bootstrap.min.js'); ?>

<?php echo Html::script('assets/select2/select2.min.js'); ?>

<?php echo Html::script('assets/main.js'); ?>

<?php echo Html::script('assets/penjualan.js'); ?>











