<section class="sidebar">
  <div class="user-panel" style="border: 0px solid #ddd;background-color: #0e1315">
    <div class="pull-left image">
      <img src="<?php echo e(url('public/image/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image" >
    </div>
    <div class="pull-left info">
      <p><?php echo e(Session::get('jabatan')); ?></p>
      <a href="#"><i class="fa fa-circle text-success"></i> <?php echo e(Session::get('nama_user')); ?></a>
    </div>
  </div>
    <!-- Sidebar Menu -->
    <ul class="sidebar-menu" data-widget="tree">
        <li class="<?php echo e(Request::is('dashboard')?'active':null); ?>">
            <a href="<?php echo e(url('/dashboard')); ?>"><i class="fa fa-university"></i><span> Dashboard</span></a>
        </li>
          <li class="<?php echo e(Request::is('user') ? 'active':null); ?>">
              <a href="<?php echo e(url('/user')); ?>"><i class="fa fa-user"></i> <span>Data User</span></a>
          </li>
          <li class="<?php echo e(Request::is('guide') ? 'active':null); ?>">
              <a href="<?php echo e(url('/guide')); ?>"><i class="fa fa-users"></i> <span>Data Guide</span></a>
          </li>
          <li class="<?php echo e(Request::is('driver') ? 'active':null); ?>">
            <a href="<?php echo e(url('/driver')); ?>"><i class="fa fa-car"></i> <span>Data Driver</span></a>
          </li>
          <li class="<?php echo e(Request::is('aktivitas_wisata') ? 'active':null); ?>">
            <a href="<?php echo e(url('/aktivitas_wisata')); ?>"><i class="fa fa-wheelchair"></i> <span>Data Aktivitas Wisata</span></a>
          </li>
          <li class="<?php echo e(Request::is('tiket') ? 'active':null); ?>">
            <a href="<?php echo e(url('/tiket')); ?>"><i class="fa fa-file-text-o"></i> <span>Data Tiket</span></a>
          </li>
          <li class="<?php echo e(Request::is('paket_tour') ? 'active':null); ?>">
            <a href="<?php echo e(url('/paket_tour')); ?>"><i class="fa fa-suitcase"></i> <span>Data Paket Tour</span></a>
          </li>
          <li class="<?php echo e(Request::is('pemesanan_tour') ? 'active':null); ?>">
            <a href="<?php echo e(url('/pemesanan_tour')); ?>"><i class="fa fa-suitcase"></i> <span>Data Pemesanan Tour</span></a>
          </li>
          <li class="treeview <?php echo e(Request::is('laporan/register-pasien')?'active':null); ?><?php echo e(Request::is('laporan/hasil-spk')?'active':null); ?> <?php echo e(Request::is('laporan/hasil-spk/detail/*/*')?'active':null); ?>">
              <a href="#">
                <i class="fa fa-clipboard"></i>
                <span>Laporan</span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <li class="<?php echo e(Request::is('laporan/hasil-spk')?'active':null); ?> <?php echo e(Request::is('laporan/hasil-spk/detail/*/*')?'active':null); ?>"><a href="<?php echo e(url('/laporan/hasil-spk')); ?>"><i class="fa fa-book"></i> <span>Hasil SPK</span></a></li>
                <li class="<?php echo e(Request::is('laporan/register-pasien')?'active':null); ?>"><a href="<?php echo e(url('/laporan/register-pasien')); ?>"><i class="fa fa-book"></i> <span>Register Pasien</span></a></li>
              </ul>
          </li>
    </ul>
      <!-- /.sidebar-menu -->
</section>