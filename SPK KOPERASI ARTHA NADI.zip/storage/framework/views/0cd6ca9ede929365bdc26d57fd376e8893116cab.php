<?php
$title="- Detail Register Pasien";
?>
<style type="text/css">
	td{
		padding: 4px;
	}
</style>
<table width="100%" cellpadding="4" style="padding: 8px 8px 8px 8px">
<tr>
	<td width="30%">No Registrasi</td>
	<td width="4%">:</td>
	<td><?php echo e($registerPasien->no_reg); ?></td>
</tr>
<tr>
	<td>Nama Pasien</td>
	<td>:</td>
	<td><?php echo e($registerPasien->nama_pasien); ?></td>
</tr>
<tr>
	<td>NRM</td>
	<td>:</td>
	<td><?php echo e($registerPasien->nrm); ?></td>
</tr>
<tr>
	<td>Tipe Parawatan</td>
	<td>:</td>
	<td><?php echo e($registerPasien->tipe_perawatan); ?></td>
</tr>
<tr>
	<td>Jenis Kelamain</td>
	<td>:</td>
	<td><?php echo e($registerPasien->jenis_kelamin); ?></td>
</tr>
<tr>
	<td>Tipe Pasien</td>
	<td>:</td>
	<td><?php echo e($registerPasien->tipe_pasien); ?></td>
</tr>
<tr>
	<td>Nama Customer</td>
	<td>:</td>
	<td><?php echo e($registerPasien->nama_customer); ?></td>
</tr>
<tr>
	<td>Pekerjaan</td>
	<td>:</td>
	<td><?php echo e($registerPasien->pekerjaan); ?></td>
</tr>
<tr>
	<td>Pendidikan</td>
	<td>:</td>
	<td><?php echo e($registerPasien->pendidikan); ?></td>
</tr>
<tr>
	<td>Usia</td>
	<td>:</td>
	<td><?php echo e($registerPasien->usia); ?> Tahun</td>
</tr>
<tr>
	<td>Agama</td>
	<td>:</td>
	<td><?php echo e($registerPasien->agama); ?></td>
</tr>
<tr>
	<td>Alamat</td>
	<td>:</td>
	<td> <?php echo e($registerPasien->alamat); ?></td>
</tr>
<tr>
	<td>Desa</td>
	<td>:</td>
	<td> <?php echo e($registerPasien->desa); ?></td>
</tr>
<tr>
	<td>Kecamatan</td>
	<td>:</td>
	<td> <?php echo e($registerPasien->kecamatan); ?></td>
</tr>
<tr>
	<td>Kabupaten</td>
	<td>:</td>
	<td> <?php echo e($registerPasien->kabupaten); ?></td>
</tr>
<tr>
	<td>Diagnosa</td>
	<td>:</td>
	<td><?php echo e($registerPasien->diagnosa); ?></td>
</tr>
<tr>
	<td>Dokter</td>
	<td>:</td>
	<td> <?php echo e($registerPasien->dokter); ?></td>
</tr>

</table>