<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1 align="center">
    <strong><?php echo e(config('app.app_name')); ?></strong>
  </h1>
</section>
<br><br>
<div class="row">
  <a href="" id="modalPemasukan">
  <div class="col-md-3 col-sm-6 col-xs-12">
    <div class="info-box bg-aqua">
      <span class="info-box-icon"><i class="fa fa-sign-in"></i></span>

      <div class="info-box-content">
        <span class="info-box-text"></span>
        <span class="info-box-number">Rp 100</span>

        <div class="progress">
          <div class="progress-bar" style="width: 100%"></div>
        </div>
            <span class="progress-description">
              Pemasukan
            </span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
  </a>
  <!-- /.col -->
  <a href="" id="modalPengeluaran">
  <div class="col-md-3 col-sm-6 col-xs-12">
    <div class="info-box bg-green">
      <span class="info-box-icon"><i class="fa fa-cloud-upload"></i></span>

      <div class="info-box-content">
        <span class="info-box-text"></span>
        <span class="info-box-number">Rp 100</span>

        <div class="progress">
          <div class="progress-bar" style="width: 100%"></div>
        </div>
            <span class="progress-description">
              Pengeluaran
            </span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
  </a>
  <!-- /.col -->
  <div class="col-md-3 col-sm-6 col-xs-12">
    <div class="info-box bg-yellow">
      <span class="info-box-icon"><i class="fa fa-calculator"></i></span>

      <div class="info-box-content">
        <span class="info-box-text"></span>
        <span class="info-box-number">Rp 100</span>

        <div class="progress">
          <div class="progress-bar" style="width: 100%"></div>
        </div>
            <span class="progress-description">
              Total
            </span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
  <!-- /.col -->
  <a href="" id="modalSiswa">
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box bg-red">
        <span class="info-box-icon"><i class="fa fa-users"></i></span>

        <div class="info-box-content">
          <span class="info-box-text"></span>
          <span class="info-box-number">100</span>

          <div class="progress">
            <div class="progress-bar" style="width: 100%"></div>
          </div>
              <span class="progress-description">
                Siswa
              </span>
        </div>
        <!-- /.info-box-content -->
      </div>
      
      <!-- /.info-box -->
    </div>
  </a>
  <!-- /.col -->
</div>
<!-- /.row -->
       <div class="row">
        <section class="col-lg-12 connectedSortable">
          <!-- BAR CHART -->
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Data Keuangan Sekolah Per Tahun</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body chart-responsive">
              <div class="col-md-2 pull-right">
                <select name="year" id="select_year" class="form-control">
                  <option value="2018">2016</option>
                  <option value="2019">2017</option>
                  <option value="2018">2018</option>
                  <option value="2019">2019</option>
                  <option value="2020">2020</option>
                  <option value="2021" selected>2021</option>
                </select>
              </div>

              <div class="graph">
                <div class="chart" id="bar-chart" style="height:230px"></div>
              </div>
            </div>
            <!-- /.box-body -->
          </div>
        </section>
        </div>
        <!-- /.box -->
        </section>
      </div>
      <!-- /.col -->
    <!-- /.row -->
    <script>
    let lookup = {
      lookup_modal_create: function() {
          $('#modalSiswa').on( "click", function(e){
            e.preventDefault();
            var _prop= {
              _this : $( this ),
              remote : "<?php echo e(url('dashboard')); ?>/info_siswa",
              size : 'modal-lg',
              title : "<?= 'Informasi Siswa' ?>",
            }
            ajax_modal.show(_prop);											
          });  
        },
        lookup_modal_pemasukan: function() {
          $('#modalPemasukan').on( "click", function(e){
            e.preventDefault();
            var _prop= {
              _this : $( this ),
              remote : "<?php echo e(url('dashboard')); ?>/info_pemasukan",
              size : 'modal-lg',
              title : "<?= 'Informasi Pemasukan' ?>",
            }
            ajax_modal.show(_prop);											
          });  
        },
        lookup_modal_pengeluaran: function() {
          $('#modalPengeluaran').on( "click", function(e){
            e.preventDefault();
            var _prop= {
              _this : $( this ),
              remote : "<?php echo e(url('dashboard')); ?>/info_pengeluaran",
              size : 'modal-lg',
              title : "<?= 'Informasi Pengeluaran' ?>",
            }
            ajax_modal.show(_prop);											
          });  
        },
    };

    $(function () {
      $.fn.extend({
        functionGraph: { 
          init:function(){
                var post_data = {};
                    post_data.header = {
                      'year':$('#select_year').val()
                    }
                $.post( "<?php echo e(url('dashboard/chart')); ?>", post_data, function( response, status, xhr ){
                    if ( response.status == 'error')
                    {
                      return false;
                    }
                    $.fn.functionGraph.chart(response.data);    
                  });												
              $('#select_year').on( "change",  function(e){
                $('#bar-chart').remove();
                var post_data = {};
                    post_data.header = {
                      'year':$('#select_year').val()
                    }
                $.post( "<?php echo e(url('dashboard/chart')); ?>", post_data, function( response, status, xhr ){
                    if ( response.status == 'error')
                    {
                      return false;
                    }

                    $( ".graph" ).append( " <div class=\"chart\" id=\"bar-chart\"></div>" );
                    $.fn.functionGraph.chart(response.data);    
                  });												
              });
          },
        chart: function(data)
            {
              var bar = new Morris.Bar({
                  barSizeRatio:0.2,
                  element: 'bar-chart',
                  resize: true,
                  data: data,
                  barColors: ['#00a65a', '#dd4b39'],
                  xkey: 'Bulan',
                  ykeys: ['Pemasukan', 'Pengeluaran'],
                  labels: ['Pemasukan', 'Pengeluaran'],
                  hideHover: 'auto',
                  xLabelAngle: 10,
              });

            },
          }
      });

      $(document).ready(function(){
        $.fn.functionGraph.init();
        lookup.lookup_modal_create();
        lookup.lookup_modal_pemasukan();
        lookup.lookup_modal_pengeluaran();
      })
    }); 
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('themes.AdminLTE.layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>