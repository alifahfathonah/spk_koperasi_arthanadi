<form action="<?php echo e(route ('SubKriteria.update',[$subKriteria->id])); ?>" method="POST" id="formEditSubKriteria" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="id" value="<?php echo e($subKriteria->id); ?>">
    <input type="hidden" name="id_kriteria" value="<?php echo e($subKriteria->id_kriteria); ?>">
    <div class="form-group">
            <label for="name" class="col-sm-3 control-label tengah2">Nama Kriteria</label>
            <div class="col-md-9">
            <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($x->id==$subKriteria->id_kriteria): ?>
                <input type="text" class="form-control" name="txtNamaKriteria" value="<?php echo e($x->nama_kriteria); ?>" required="" readonly="">
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </div>
    <div class="form-group">
            <label for="name" class="col-sm-3 control-label tengah2">Nilai</label>
            <div class="col-md-9">
            <input type="text" class="form-control" name="txtNilai" value="<?php echo e($subKriteria->nilai); ?>" required="">
            </div>
          </div>
         <div class="form-group">
            <label for="name" class="col-sm-3 control-label tengah2">Keterangan</label>
            <div class="col-md-9">
            <input type="text" class="form-control" name="txtKeterangan" value="<?php echo e($subKriteria->keterangan); ?>" required="">
          </div>
          </div>
<?php echo $__env->make('layouts.modal_footer_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
