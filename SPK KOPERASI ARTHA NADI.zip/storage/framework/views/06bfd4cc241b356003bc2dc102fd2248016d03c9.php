<form method="POST" action="<?php echo e(url($submit_url)); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="col-md-12">
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">No Bukti</label>
                <div class="col-md-9">
                  <input type="text" class="form-control" id="no_bukti" name="f[no_bukti]" value="<?php echo e(@$item->no_bukti); ?>" placeholder="No Bukti" autofocus autocomplete="off" required="" readonly>
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">Tanggal</label>
                <div class="col-md-9">
                  <input type="date" class="form-control" id="tanggal" name="f[tanggal]" value="<?php echo e(@$item->tanggal); ?>" placeholder="Tanggal Transaksi" autofocus autocomplete="off" required="">
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">Keterangan</label>
                <div class="col-md-9">
                  <textarea name="f[keterangan]" id="keterangan" cols="30" rows="3" class="form-control" required> <?php echo e(@$item->keterangan); ?> </textarea>
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">Akun Debet</label>
                <div class="col-md-9">
                  <select name="f[akun_debet]" id="" required class="form-control" <?php echo e((@$is_edit) ? 'disabled':null); ?>>
                    <?php $__currentLoopData = $akun_debet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akuns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($akuns->id); ?>"><?php echo e($akuns->no_akun); ?> - <?php echo e($akuns->nama_akun); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">Akun Kredit</label>
                <div class="col-md-3">
                      <input type="text" id="no_akun" name="no_akun" value="<?php echo e(@$item->no_akun); ?>" class="form-control" placeholder="No Akun" readonly style="background-color: #fff" required>
                </div>
                <div class="col-md-6">
                  <div class="input-group mb-3">
                    <input type="hidden" id="akun_id" name="f[akun_id]" value="<?php echo e(@$item->akun_id); ?>" class="form-control" placeholder="ID AKun" aria-describedby="basic-addon2" readonly>
                    <input type="text" id="nama_akun" name="nama_akun" value="<?php echo e(@$item->nama_akun); ?>" class="form-control" placeholder="Nama Akun" readonly style="background-color: #fff" required>
                    <div class="input-group-append">
                      <a data-toggle="modal" data-target="<?php echo e((@$is_edit) ? null:"#ModalAkun"); ?>" title="" class="btn btn-info tip" data-original-title="" <?php echo e((@$is_edit) ? 'disabled':null); ?>><i class="fa fa-gear"></i></a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2">Total</label>
                <div class="col-md-9">
                  <input type="number" id="total" class="form-control" name="f[total]" value="<?php echo e(@$item->total); ?>" placeholder="Total" autofocus autocomplete="off" required="">
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-3 control-label tengah2"></label>
                <div class="col-md-9">
                  <h3 for="" class="total"></h3>
                </div>
              </div>
            </div>
            <h4 align="center" style="color: red">
              <?php echo e((@$item->tutup_buku == 1) ? 'Sudah dilakukan tutup buku':null); ?>

            </h4>
            <div class="modal-footer" style="border-top: 0px;">
                <button type="button" class="btn btn-danger tombolform" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i> Batal</button>
                <button id="submit_form" type="submit" class="btn btn-success tombolform" <?php echo e((@$item->tutup_buku == 1) ? 'disabled':null); ?>><i class="fa fa-floppy-o" aria-hidden="true"></i> Simpan</button> 
           </div>
          </form>
        </div>
      </div>
    </div>
</div>    
<?php echo $__env->make('pemasukan.lookup.akun', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
$("#total").on('keyup', function() {
    $('.total').text( currency_add($(this).val()) );
});

$('#submit_form').on('click',function(){
  if (!$('#nama_akun').val()) {
  alert('Please fill in all required fields.');
  return false
  }else if (!$('#keterangan').val()) {
    alert('Please fill in all required fields.');
    return false
  }
  else if (!$('#total').val() || $('#total').val() == 0) {
    alert('Please fill in all required fields.');
    return false
  }
});

</script>
