<!DOCTYPE html>
<html>
	<?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<body class="hold-transition skin-blue sidebar-mini">
	<div class="wrapper">
		<?php echo $__env->make('layouts.top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<aside class="main-sidebar">
			<?php echo $__env->make('layouts.left', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</aside>
		<div class="content-wrapper">
			<section class="content-header">
		      <?php echo $__env->yieldContent('bread'); ?>
   			</section>
   			<section class="content container-fluid">

		      <?php echo $__env->yieldContent('content'); ?>

		    </section>
		</div>
		<footer class="main-footer">
    		<!-- To the right -->
		    <div class="pull-right hidden-xs">
		      Anything you want
		    </div>
    		<!-- Default to the left -->
    		<strong>Copyright &copy; 2016 <a href="#">Company</a>.</strong> All rights reserved.
  		</footer>
  		<?php echo $__env->make('layouts.right', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	</div>
	<?php echo $__env->make('layouts.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?><?php echo $__env->yieldPushContent('scripts'); ?>
	<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>