 <?php 
 $title="Detail Hasil SPK | ";
 ?>

<?php $__env->startSection('content'); ?>
 <div class="row rowEdit">
      <div class="box-header with-border boxHeader">
        <h4 class="box-title boxTitle"><i class="fa fa-balance-scale"></i> LAPORAN DETAIL HASIL SPK 
        </h4><hr>

      <p><span class="circleBlue"><?php echo e($data->nama_kecamatan); ?></span> 
        <span style="float: right;"> <a href="<?php echo e(url('laporan/hasil-spk/cetak-detail/'.$data->id.'/'.$data->nama_kecamatan)); ?>" class="circleGreen" title="Cetak PDF" target="blank">Cetak PDF <i class="fa fa-print" aria-hidden="true"></i></a></span></p>
        <div class="box box-primary collapsed-box">
          <div class="box-header with-border">
            <h3 class="box-title">Likehood</h3>
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse" data-widget="collapse" title="Lihat Detail" data-toggle="modal" data-target="#"><i class="fa fa-eye fa-lg"></i></button>
              </div>
          </div>
        <div class="row kotak">
        <div class="box-body">
        <div align="left">

        <table border="1" width="100%" class="table table-bordered table-hover" id="">
        	<thead>
        		<tr>
              <th>Klasifikasi</th>
              <th>Nilai</th>
              <th>Total</th>
              <th>Probabilitas</th>
        		</tr>
        	</thead>
        <tbody>
            <tr>
              <td>Strategis</td>
              <td><span data-widget="collapse" title="Jumlah Data Aturan Strategis" data-toggle="modal" data-target="#"><?php echo e($data->jumlah_data_aturan_strategis); ?></span></td>
              <td><span data-widget="collapse" title="Jumlah Data Aturan" data-toggle="modal" data-target="#"><?php echo e($data->jumlah_data_aturan); ?></span></td>
              <td><span data-widget="collapse" title="Jumlah Data Aturan Strategis (<?php echo e($data->jumlah_data_aturan_strategis); ?>) : Jumlah Data Aturan (<?php echo e($data->jumlah_data_aturan); ?>)" data-toggle="modal" data-target="#"><?php echo e(round($data->likehood_strategis,6)); ?></span></td>
            </tr>
            <tr>
              <td>Tidak Strategis</td>
              <td>
                <span data-widget="collapse" title="Jumlah Data Aturan Tidak Strategis" data-toggle="modal" data-target="#">
                  <?php echo e($data->jumlah_data_aturan_tidak_strategis); ?>

                </span>
              </td>
              <td>
                <span data-widget="collapse" title="Jumlah Data Aturan" data-toggle="modal" data-target="#"> 
                  <?php echo e($data->jumlah_data_aturan); ?>

                </span>
              </td>
              <td>
                <span data-widget="collapse" title="Jumlah Data Aturan Tidak Strategis (<?php echo e($data->jumlah_data_aturan_tidak_strategis); ?>) : Jumlah Data Aturan (<?php echo e($data->jumlah_data_aturan); ?>)" data-toggle="modal" data-target="#">
                  <?php echo e(round($data->likehood_tidak_strategis,6)); ?>

                </span>
              </td>
            </tr>
        </tbody>
        </table>

        </div>
        </div>
        </div>
        </div>
        <!-- ===================== -->
        <?php $__currentLoopData = $detail->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($value->id_alternatif_lokasi==$data->id_alternatif_lokasi): ?>
                <div class="box box-primary collapsed-box">
                  <div class="box-header with-border">
                    <h3 class="box-title">Probabilitas Kriteria <?php echo e($value->nama_kriteria); ?></h3>
                      <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-widget="collapse" title="Lihat Detail" data-toggle="modal" data-target="#"><i class="fa fa-eye fa-lg"></i></button>
                      </div>
                  </div>
                  <div class="row kotak">
                    <div class="box-body">
                      <div align="left">
                        <table border="1" width="100%" class="table table-bordered table-hover" id="">
                          <thead>
                            <tr>
                              <th>Klasifikasi</th>
                              <th>Sub Kriteria</th>
                              <th>Nilai</th>
                              <th>Total</th>
                              <th>Probabilitas</th>
                            </tr>
                          </thead>
                        <tbody>
                            <tr>
                              <td>Strategis</td>
                              <td><?php echo e($value->keterangan); ?></td>
                              <td><?php echo e($value->jumlah_strategis); ?> </td>
                              <td><?php echo e($value->likehood); ?></td>
                              <td><?php echo e(round($value->probabilitas_strategis,6)); ?></td>
                            </tr>
                            <tr>
                              <td>Tidak Strategis</td>
                              <td><?php echo e($value->keterangan); ?></td>
                              <td><?php echo e($value->jumlah_tidak_strategis); ?> </td>
                              <td><?php echo e($value->likehood); ?></td>
                              <td><?php echo e(round($value->probabilitas_tidak_strategis,6)); ?></td>
                            </tr>
                        </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Probabilitas Akhir</h3>
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse" title="Lihat Detail" data-toggle="modal" data-target="#"><i class="fa fa-eye fa-lg"></i></button>
              </div>
          </div>
        <div class="row kotak">
        <div class="box-body">
        <div align="left">

        <table border="1" width="100%" class="table table-bordered table-hover" id="">
          <thead>
            <tr>
              <th>Klasifikasi</th>
              <th>Probabilitas</th>
            </tr>
          </thead>
        <tbody>
            <tr>
              <td>Strategis</td>
              <td>
                    <span class="circleGreen">
                        <span data-widget="collapse" title="Probabilitas Akhir Strategis" data-toggle="modal" data-target="#"><?php echo e(round($data->probabilitas_strategis,6)); ?>

                        </span>
                    </span>

              </td>
            </tr>
            <tr>
              <td>Tidak Strategis</td>
              <td>
                  <span class="circleRed" style="width: 50px">
                      <span data-widget="collapse" title="Probabilitas Akhir Tidak Strategis" data-toggle="modal" data-target="#"><?php echo e(round($data->probabilitas_tidak_strategis,6)); ?>

                      </span>
                  </span> 
              </td>
            </tr>
        </tbody>
        </table>
        <h3 class="box-title"><i class="fa fa-angle-double-right" aria-hidden="true"></i><i class="fa fa-angle-double-right" aria-hidden="true"></i> KESIMPULAN : <?php echo e(strtoupper($data->klasifikasi)); ?></h3>
        </div>
        </div></div></div><br> 
<!-- ============================ -->
<!-- =============================== -->
 </div>
</div>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>