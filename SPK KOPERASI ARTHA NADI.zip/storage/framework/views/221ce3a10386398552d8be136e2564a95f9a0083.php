<form  method="POST" action="<?php echo e(route('user.store')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>

  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Nama User</label>
    <div class="col-md-9">
      <input type="text" class="form-control" name="txtNamaUser" value="<?php echo e(old('txtNamaUser')); ?>" placeholder="Nama User" autofocus autocomplete="off" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Jenis Kelamin</label>
      <div class="col-md-9">
        <?php $jenis_kelamin =   
          [
              ['id' => 'Laki-Laki','desc' => 'Laki-Laki'],
              ['id' => 'Perempuan','desc' => 'Perempuan']
          ]; 
        ?>
        <select name="txtJenisKelamin" class="form-control" required="">
          <option value="" disabled="" selected="" hidden="">- Jenis Kelamin -</option>
          <?php foreach($jenis_kelamin as $dt): ?>
            <option value="<?php echo @$dt['id'] ?>" <?= @$dt['id'] == @$item->jenis_kelamin ? 'selected': null ?>><?php echo @$dt['desc'] ?></option>
          <?php endforeach; ?>
        </select>
      </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Jabatan</label>
      <div class="col-md-9">
        <?php $jabatan =   
          [
              ['id' => 'Admin','desc' => 'Admin'],
              ['id' => 'Customer','desc' => 'Customer'],
              ['id' => 'Reservation','desc' => 'Reservation'],
              ['id' => 'Manager','desc' => 'Manager'],
              ['id' => 'Operator','desc' => 'Operator'],
              ['id' => 'Finance Acounting','desc' => 'Finance Acounting'],
              ['id' => 'Chasier','desc' => 'Chasier']
          ]; 
        ?>
        <select name="txtJabatan" class="form-control" required="">
          <option value="" disabled="" selected="" hidden="">- Pilih Jabatan -</option>
          <?php foreach($jabatan as $dt): ?>
            <option value="<?php echo @$dt['id'] ?>" <?= @$dt['id'] == @$item->jabatan ? 'selected': null ?>><?php echo @$dt['desc'] ?></option>
          <?php endforeach; ?>
        </select>
      </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Username</label>
    <div class="col-md-9">
      <input type="text" name="txtUsername" class="form-control" placeholder="Username" value="<?php echo e(old('txtUsername')); ?>" required="">
    </div>
  </div>
  <div class="form-group">
    <label for="name" class="col-sm-3 control-label tengah2">Password</label>
    <div class="col-md-9">
      <input type="password" class="form-control" name="txtPassword" value="<?php echo e(old('txtPassword')); ?>" placeholder="Password" required="">
    </div>
  </div>
<?php echo $__env->make('layouts.modal_footer_tambah', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>
      
</div>
</div>
</div>
</div>