 <?php 
 $title="Laporan Kunjungan -";
 ?>

<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">LAPORAN DATA KUNJUNGAN</h3>

              <div class="box-tools pull-right">
              </div>
            </div> 
<div class="row kotak">
 

<form action="<?php echo e(url('/laporan_kunjungan/filter_kunjungan')); ?>" method="GET">
<div class="modal fade" id="modalFilterKunjungan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <h5 class="modal-title" align="center"><strong>FILTER DATA KUNJUNGAN BERDASARKAN TANGGAL</strong></h5>
      </div>
      <div class="modal-body">
        

     <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Periode</label>
            <input type="date" name="txtAwal" class="form-control" required="">
        </div>
        <div class="form-group">
            <label for="name" class="cols-sm-2 control-label">Sampai</label>
            <input type="date" name="txtAkhir" class="form-control" required="">
        </div>



      
      </div>
      <div class="modal-footer">
        <input type="submit" name="btnCari" value="Cari" class="btn btn-primary">
        <button type="button" class="btn btn-warning" data-dismiss="modal">Tutup</button>
      </div>
    
    </div>
  </div>
</div>
</form>


<table width="100%">
  <tr>
    <td width="20%">
       <button type="button" title="Filter"  class="btn btn-primary" data-toggle="modal" data-target="#modalFilterKunjungan"><span class="fa fa-search"></span>
                    Filter Periode
                  </button>
    </td>
    <td width="14%"><p class="total kunjungan">Total : <?php echo e($totalKunjungan); ?></p></td>
    <td><p class="total umum">P. Umum : <?php echo e($totalPoliUmum); ?></p></td>
    <td><p class="total gigi">P. Gigi dan Mulut : <?php echo e($totalPoliGigiMulut); ?></p></td>
    <td><p class="total mata">P. KIA/KB : <?php echo e($totalPoliKiaKb); ?></p></td>
    <td><p class="total anak">Kons. Terpadu : <?php echo e($totalKonsultasiTerpadu); ?></p></td>
    <td><p class="total a">Pel. Imunisasi : <?php echo e($totalPelayananImunisasi); ?></p></td>
    <td><p class="total b">Pel. Kes. Tradisional : <?php echo e($totalPelayananKesehatanTradisional); ?></p></td>
    
  </tr>
</table>
<br>
<p>
<?php
      if(isset($_GET['btnCari'])){
    ?>
      Periode <b><?php echo e(Carbon\Carbon::parse($awal)->formatLocalized('%d %B %Y')); ?></b> Sampai dengan <b><?php echo e(Carbon\Carbon::parse($akhir)->formatLocalized('%d %B %Y')); ?></b>
    <?php
    $periode=" Periode ".Carbon\Carbon::parse($awal)->formatLocalized('%d %B %Y'). " Sampai ".Carbon\Carbon::parse($akhir)->formatLocalized('%d %B %Y');
    ?>
    <input type="hidden" id="periode" value="<?php echo e($periode); ?>">
    <?php
      }
    ?>
</p>

<table border="1" width="100%" class="table table-bordered display nowrap" id="datakunjungan">
	<thead>
		<tr>
			<th width="5%">No</th>
      <th width="17%">Tanggal Kunjungan</th>
      <th>Nama Pasien</th>
      <th>Umur</th>
      <th>Alergi</th>
      <th>Keluhan</th>
			<th>Unit Tujuan</th>
		</tr>
	</thead>
	<tbody>
     <?php

      $no=1;
      
        ?>
      
      <?php $__currentLoopData = $kun->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($no++); ?></td>
      <td width="17%"><?php echo e(Carbon\Carbon::parse($k->tgl_periksa)->formatLocalized('%d %B %Y')); ?> | <?php echo e($k->jam_periksa); ?></td>
      <td><?php echo e($k->nama_pasien); ?></td>
      <td>
          <?php
// tanggal lahir
$tanggal = new DateTime($k->tanggal_lahir_pasien);

// tanggal hari ini
$today = new DateTime('today');

// tahun
$y = $today->diff($tanggal)->y;

// bulan
$m = $today->diff($tanggal)->m;

// hari
$d = $today->diff($tanggal)->d;

?>
<?php echo e($y . " Tahun "); ?>

      </td>
      <td><?php echo e($k->alergi); ?></td>
      <td><?php echo e($k->keluhan); ?></td>
      <td><?php echo e($k->unit_tujuan); ?></td>
    
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
</tbody>
 
</table>



<input type="hidden" id="totalKunjungan" value="Total Kunjungan : <?php echo e($totalKunjungan); ?>">
<input type="hidden" id="totalPoliUmum" value="P. Umum : <?php echo e($totalPoliUmum); ?>">
<input type="hidden" id="totalPoliKiaKb" value="P. KIA/KB : <?php echo e($totalPoliKiaKb); ?>">
<input type="hidden" id="totalPoliGigiMulut" value="P. Gigi & Mulut : <?php echo e($totalPoliGigiMulut); ?>">
<input type="hidden" id="totalKonsultasiTerpadu" value="Kons. Terpadu : <?php echo e($totalKonsultasiTerpadu); ?>">
<input type="hidden" id="totalPelayananImunisasi" value="Pel. Imunisasi : <?php echo e($totalPelayananImunisasi); ?>">
<input type="hidden" id="totalPelayananKesehatanTradisional" value="Pel. Kes. Tradisional : <?php echo e($totalPelayananKesehatanTradisional); ?>">
</div>


<script type="text/javascript">
$(document).ready(function() {
    var t = $('#datakunjungan').DataTable( {
      "dom": 'Bfrtip',
      "paging": true,
      "autoWidth": true,
      lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ],
        "buttons": [
         'pageLength',
          {
                title: 'LAPORAN DATA KUNJUNGAN' +'\n' + 'UPT. PUSKESMAS SUSUT I BANGLI',
                text: 'Cetak',
                extend: 'pdfHtml5',
                orientation: 'portait',
                pageSize: 'A4',
                filename: 'laporan_data_kunjungan',
                messageTop: function() {
                return $('#periode').val()
                  },
                messageBottom: function() {
                return $('#totalKunjungan').val() 
                +'\n' +  $('#totalPoliUmum').val()
                +'\n' +  $('#totalPoliKiaKb').val()
                +'\n' +  $('#totalPoliGigiMulut').val()
                +'\n' +  $('#totalKonsultasiTerpadu').val()
                +'\n' +  $('#totalPelayananImunisasi').val()
                +'\n' +  $('#totalPelayananKesehatanTradisional').val()
                
                  }
            },

        ],

        "oLanguage": {
      "sSearch": "Search",
      "sLengthMenu": "Tampilkan"
    },
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0,
        } ],
        "order": [[ 0, 'asc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );


</script>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>