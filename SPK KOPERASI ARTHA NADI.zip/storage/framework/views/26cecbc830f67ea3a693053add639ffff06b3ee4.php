<form  method="POST" action="<?php echo e(url($submit_url)); ?>" class="form-horizontal" name="form_crud">
  <?php echo e(csrf_field()); ?>

  <div class="form-group">
    <label class="col-lg-3 control-label">User ID</label>
    <div class="col-lg-9">
      : <label class="control-label"><?php echo e(@$item->id_user); ?></label>
    </div>
  </div>
  <div class="form-group">
      <label class="col-lg-3 control-label">Nama</label>
      <div class="col-lg-9">
        : <label class="control-label"><?php echo e(@$item->nama); ?></label>
      </div>
  </div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Username</label>
    <div class="col-lg-9">
      : <label class="control-label"><?php echo e(@$item->username); ?></label>
    </div>
</div>
<div class="form-group">
  <label class="col-lg-3 control-label">Password</label>
  <div class="col-lg-9">
    : <label class="control-label"><?php echo e('*******************'); ?></label>
  </div>
</div>
  <div class="form-group">
    <label class="col-lg-3 control-label">Jabatan</label>
    <div class="col-lg-9">
      : <label class="control-label"><?php echo e(@$item->jabatan); ?></label>
    </div>
  </div>
</form>
      
