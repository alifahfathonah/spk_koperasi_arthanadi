<?php $__env->startSection('breadcrumb'); ?>  
  <h1>
    <?php echo e(@$title); ?>

  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Master</a></li>
    <li class="active"><?php echo e(@$title); ?></li>
  </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>  
    <div class="box">
      <div class="box-header">
        <h3 class="box-title"><?php echo e(@$title); ?></h3>
        <div class="box-tools pull-right">

          <div class="btn-group">
            <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
            Tindakan <i class="fa fa-wrench"></i></button>
            <ul class="dropdown-menu" role="menu">
              <li><a href="<?php echo e(url(@$nameroutes)); ?>/create" title="Tambah Data"><i class="fa fa-plus" aria-hidden="true"></i> Tambah Baru</a></li>
            </ul>
          </div>
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
          </button>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <table class="table table-striped table-bordered table-hover" id="<?php echo e($idDatatables); ?>" width="100%">   
            <thead>
              <tr>
                <th class="no-sort">No</th>
                <th>Tanggal</th>
                <th>No Transaksi</th>
                <th>Pembayaran</th>
                <th>NIS</th>
                <th>Nama Siswa</th>
                <th>Angkatan</th>
                <th>Tahun Ajaran</th>
                <th>Total</th>
                <th class="no-sort"><i class="fa fa-cog" aria-hidden="true"></i></th>
              </tr>
            </thead>
            <tbody>
            
          </tbody>
          </table>
      </div>
    </div>

<!-- DataTable -->
<script type="text/javascript">
    var id_datatables = "<?php echo e($idDatatables); ?>";

      _datatables_show = {
        dt_datatables:function(){
        var _this = $("#"+id_datatables);
            _datatable = _this.DataTable({									
							ajax: "<?php echo e(url("{$urlDatatables}")); ?>",
              order: [1],
              columns: [
                          {
                              data: "id",
                              render: function (data, type, row, meta) {
                                  return meta.row + meta.settings._iDisplayStart + 1;
                              }
                          },
                          { 
                                data: "tanggal", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "no_transaksi", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "nama_kk", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "nis", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "nama_siswa", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "angkatan", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "tahun_ajaran", 
                                render: function ( val, type, row ){
                                    return val
                                  }
                          },
                          { 
                                data: "total", 
                                render: function ( val, type, row ){
                                    return mask_number.currency_add(val)
                                  }
                          },
                          { 
                                data: "id",
                                className: "text-center",
                                render: function ( val, type, row ){
                                    var buttons = '<div class="btn-group">' +
                                                    '<button type="button" class="btn btn-info btn-xs dropdown-toggle" data-toggle="dropdown">Tindakan <span class="caret"></span></button>' + 
                                                      '<ul class="dropdown-menu" role="menu">' +
                                                        '<li><a href=\"<?php echo e(url('pembayaran/edit')); ?>/'+ val +'\" title=\"Ubah Data\"><i class=\"fa fa-edit\"></i> Ubah</a></li>' +
                                                        '<li><a href=\"<?php echo e(url('pembayaran/view')); ?>/'+ val +'\" title=\"Lihat Data\"><i class=\"fa fa-eye\"></i> Lihat</a></li>' +
                                                      '</ul>' +                
                                                  '</div>';
                                    return buttons
                                  }
                              },
                      ],
                                                  
                  });
							
                  return _this;
				}

			}
  
$(document).ready(function() {
  _datatables_show.dt_datatables();
});
  </script>
<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('themes.AdminLTE.layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>