<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(@$title); ?> <?php echo e(config('app.app_name')); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="shortcut icon" href="<?php echo e(url('themes/default/images/favicon.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('themes/default/css/style_report.css')); ?>">
</head>
<body>
  <table style="border:none;">
    <tr>
      <td width="100px" style="border:none;"><img src="<?php echo e(url('themes/login/images/logo.png')); ?>" alt="" style="width: 100px;text-align:center"><br></td>
      <td style="border:none;">
        <h4 align="center">
          <span style="font: 18px"><?php echo e(config('app.app_alias')); ?></span> <br><?php echo e(config('app.unit')); ?> <br>
          Alamat : <?php echo e(config('app.address')); ?> <br>Telepon : <?php echo e(config('app.phone')); ?>

        </h4>
      </td>
      
    </tr>
  </table>
  <hr>
    <h5 align="center">
      <u><?php echo e(@$title); ?></u> <br>
    </h5>
    <div class="container">
        <table width="100%">
          <thead>
            <tr>
              <th>Urutan</th>
              <th>Alternatif</th>
              <th>Nama Nasabah</th>
              <th>Hasil Akhir</th>
              <th>Kesimpulan</th>
            </tr>
          </thead>
          <tbody>
            <?php  $no = 1;?>
            <?php if(!empty($item)): ?> 
              <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>Hasil Terbaik  <?php echo e($no++); ?></td>
                  <td><?php echo e($row->alternatif); ?></td>
                  <td><?php echo e($row->nama_nasabah); ?></td>
                  <td><?php echo e($row->hasil); ?></td>
                  <td><?php echo e($row->kesimpulan); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="5" align="center">Tidak terdapat data</td>
              </tr>
            <?php endif; ?>
          </tbody>
          <tfoot>
           
          </tfoot>
        </table>
        <br>
        <table style="border: 0px!important">
          <tr>
            <td width="50%" style="border: 0px!important">
              <p style="margin-bottom: 70px"></p>
  
              <p><i></i></p>
            </td>
            <td width="50%" align="right" style="border: 0px!important">
              <p style="margin-bottom: 70px"><?php echo e(date('d M Y')); ?>,<br>
                <?php echo e(@get_user()->jabatan); ?></p>
  
              <p><i><?php echo e(@get_user()->nama_pengguna); ?></i></p>
            </td>
          </tr>
        </table>

      </div>
    <p style="z-index: 100;position: absolute;bottom: 0px;float: right;font-size: 11px;"><i>Tanggal Cetak : <?php echo date('d-m-Y') ?></i></p>
</body>
</html>