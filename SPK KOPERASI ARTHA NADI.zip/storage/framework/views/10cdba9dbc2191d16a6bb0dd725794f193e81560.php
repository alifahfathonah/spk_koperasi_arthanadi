<head>
<title><?php echo e(config('app.app_name')); ?> |     Login    </title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
   <link rel="shortcut icon" href="<?php echo e(url('public/image/View.ico')); ?>">
   <link href="<?php echo e(url('public/themes/Inspinia/static/css/bootstrap.min.css')); ?>" rel="stylesheet">
   <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/themes/login/css/AdminLTE.min.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/themes/login/css/ionicons.min.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/themes/login/css/goggle_font.css')); ?>"> 
   <link rel="stylesheet" href="<?php echo e(url('public/themes/login/css/font-awesome.min.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/themes/login/css/adds.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/themes/login/css/jquery-ui.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/themes/login/css/cmxform.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/themes/login/css/pace.min.css')); ?>">
   <link rel="stylesheet" type="text/css" href="<?php echo e(url('public/themes/login/css/select2.css')); ?>">

   <script src="<?php echo e(url('public/themes/login/js/jquery.min.js')); ?>"></script>
   <script src="<?php echo e(url('public/themes/login/js/jquery.min.js')); ?>"></script>
   <script src="<?php echo e(url('public/themes/login/js/bootstrap.min.js')); ?>"></script>
    <!-- SweatAlert -->
    <script src="<?php echo e(url('public/themes/default/js/alert/sweetalert.min.js')); ?>"></script>

  <style type="text/css">
    .clBgBody {
      background: url('public/image/bg.jpg') no-repeat center center fixed;
      -webkit-background-size: cover;
      -moz-background-size: cover;
      -o-background-size: cover;
      background-size: cover;overflow: hidden;"
    }

    .clLoginBox{
       border: 1px solid #ddd;
       padding: 3px;
       z-index:200;
       position: fixed;
       left: 50%;
       top: 40%;
       transform: translate(-50%, -50%);
    }
  </style>

</head>