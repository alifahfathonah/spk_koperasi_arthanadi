<form action="<?php echo e(route ('user.update',[$item->id])); ?>" method="POST" id="formEditUser" enctype="multipart/form-data">
  <?php echo e(csrf_field()); ?>

  <?php echo e(method_field('PUT')); ?>

<input type="hidden" name="id" value="<?php echo e($item->id); ?>">
<div class="form-group">
  <label for="name" class="col-sm-3 control-label tengah2">Nama User</label>
  <div class="col-md-9">
    <input type="text" class="form-control" name="txtNama" value="<?php echo e(@$item->nama); ?>" placeholder="Nama User" autofocus autocomplete="off" required="">
  </div>
</div>
<div class="form-group">
  <label for="name" class="col-sm-3 control-label tengah2">Username</label>
  <div class="col-md-9">
    <input type="text" name="txtUsername" class="form-control" placeholder="Username" value="<?php echo e(@$item->username); ?>" required="">
  </div>
</div>
<div class="form-group">
  <label for="name" class="col-sm-3 control-label tengah2">Password</label>
  <div class="col-md-9">
    <input type="password" class="form-control" name="txtPassword" value="<?php echo e(@$item->password); ?>" placeholder="Password" required="">
  </div>
</div>
<div class="form-group">
  <label for="name" class="col-sm-3 control-label tengah2">Jabatan</label>
    <div class="col-md-9">
      <?php $jabatan =   
        [
            ['id' => 'Pegawai','desc' => 'Pegawai'],
            ['id' => 'Kasir','desc' => 'Kasir']
        ]; 
      ?>
      <select name="txtJabatan" class="form-control" required="">
        <option value="" disabled="" selected="" hidden="">- Pilih Jabatan -</option>
        <?php foreach(@$jabatan as $dt): ?>
          <option value="<?php echo @$dt['id'] ?>" <?= @$dt['id'] == @$item->jabatan ? 'selected': null ?>><?php echo @$dt['desc'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>
</div>
<div class="form-group">
  <label for="name" class="col-sm-3 control-label tengah2">No Telepon</label>
  <div class="col-md-9">
    <input type="text" class="form-control" name="txtTelepon" value="<?php echo e(@$item->telepon); ?>" placeholder="Telepon" required="">
  </div>
</div>
<div class="form-group">
  <label for="name" class="col-sm-3 control-label tengah2">Status</label>
    <div class="col-md-9">
      <?php $status =   
        [
            ['id' => 1,'desc' => 'Aktif'],
            ['id' => 0,'desc' => 'Tidak Aktif']
        ]; 
      ?>
      <select name="txtStatus" class="form-control" required="">
        <?php foreach(@$status as $dt): ?>
          <option value="<?php echo @$dt['id'] ?>" <?= @$dt['id'] == @$item->status ? 'selected': null ?>><?php echo @$dt['desc'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>
</div>
<?php echo $__env->make('modal.footer.modal_footer_edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>