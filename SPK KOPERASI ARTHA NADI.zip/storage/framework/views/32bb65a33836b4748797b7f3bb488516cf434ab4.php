<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(@$title); ?> <?php echo e(config('app.app_name')); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="shortcut icon" href="<?php echo e(url('themes/default/images/favicon.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('themes/default/css/style_report.css')); ?>">
</head>
<body>
    <h5 align="center">
      <?php echo e(config('app.app_name')); ?> <?php echo e(config('app.area')); ?> <br>
      Alamat : <?php echo e(config('app.address')); ?> <br>Telepon : <?php echo e(config('app.phone')); ?><hr>
    </h5>
    <h5 align="center">
      <?php echo e(@$title); ?> <br>
      Periode : <?php echo e($params->date_start ." s/d ". $params->date_end); ?>

    </h5>
    <div class="container">
        <table width="100%">
          <thead>
            <tr>
              <th style="text-align: center!important">No</th>
              <th>Nama Kategori</th>
              <th>Nominal</th>
              <th>Tanggal</th>
            </tr>
          </thead>
          <tbody>
            <?php  $no = 1; ?>
            <?php if(!$pemasukan->isEmpty()): ?> 
              <?php $__currentLoopData = $pemasukan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td align="center"><?php echo e($no++); ?></td>
                  <td><?php echo e($row->nama_kk); ?></td>
                  <td>Rp. <?php echo e(number_format($row->total)); ?></td>
                  <td><?php echo e(date('d M Y',strtotime($row->tanggal))); ?></td>

                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="4" align="center">Tidak terdapat data</td>
              </tr>
            <?php endif; ?>
          </tbody>

        </table>
      </div>
    <p style="z-index: 100;position: absolute;bottom: 0px;float: right;font-size: 11px;"><i>Tanggal Cetak : <?php echo date('d-m-Y') ?></i></p>
</body>
</html>