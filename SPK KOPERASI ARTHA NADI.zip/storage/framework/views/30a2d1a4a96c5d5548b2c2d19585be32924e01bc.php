<form action="<?php echo e(route('image_produk.destroy',[$image_produk->id])); ?>" id="formHapusImageProduk">
	 <?php echo e(csrf_field()); ?>

 	 <?php echo e(method_field('DELETE')); ?>


<input type="hidden" name="id" value="<?php echo e($image_produk->id); ?>" id="id">
	Apakah Anda yakin menghapus Gambar Produk <b>
		<?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($image_produk->produk_id==$x->id): ?>
				<?php echo e($x->nama_produk); ?>

			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</b> ini?
<div class="form-group">

</div>
<div class="modal-footer">
	<button type="submit" class="btn btn-warning">Ya</button>
	<button type="button" class="btn btn-warning" data-dismiss="modal">Tidak</button>
</div>
</form>