<?php
$title="Proses Resep Obat -";
?>

 

 <?php 
$dasboard1="Resep Obat";
$small="Halaman Detail Resep Obat";
 ?>


<!-- // -->

<!-- // -->
<?php $__env->startSection('content'); ?>
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">PROSES RESEP OBAT</h3>

              <div class="box-tools pull-right">
              </div>
            </div>
<div class="row kotak">
<?php $__currentLoopData = $detail->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<table class="table">
  <tr>
    <td width="10%">KRM</td>
    <td width="2%">:</td>
    <td width="38%"><?php echo e($r->kd_rekam_medis); ?> </td>

    <td width="10%">Tanggal Periksa</td>
    <td width="2%">:</td>
    <td><?php echo e(Carbon\Carbon::parse($r->tgl_periksa)->formatLocalized('%d %B %Y')); ?> | <?php echo e($r->jam_periksa); ?></td>
  </tr>
  <tr>
    <td width="10%">Pasien</td>
    <td width="2%">:</td>
    <td ><?php echo e($r->nama_pasien); ?></td>

    <td width="10%">Alergi</td>
    <td width="2%">:</td>
    <td ><?php echo e($r->alergi); ?></td>
  </tr>
  <tr>
    <td width="10%">Keluhan</td>
    <td width="2%">:</td>
    <td ><?php echo e($r->keluhan); ?></td>

    <td width="10%">Diagnosa</td>
    <td width="2%">:</td>
    <td ><?php echo e($r->diagnosa); ?></td> 
  </tr>
  <tr>
    <td width="10%">Penyakit</td>
    <td width="2%">:</td>
    <td ><?php echo e($r->penyakit); ?></td>   

    <td width="10%">Dokter</td>
    <td width="2%">:</td>
    <td ><?php echo e($r->nama_pegawai); ?></td>
  </tr>
</table>



<!-- tampil resep -->
<table class="table table-bordered">
    <thead>
  <tr>
    <th width="6%">No</th>
    <th>Nama Obat</th>
    <th>Tanggal Resep</th>
    <th>Jumlah</th>
    <th>Cara Pakai</th>
    <th>Keterangan</th>
    <th width="16%" style="text-align: center">Status</th>
  </tr>
    </thead>
            <tbody>
<?php $no=1; ?>
<?php $__currentLoopData = $detail->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <tr>
    <td><?php echo e($no++); ?></td>
    <td><?php echo e($r->nama_obat); ?></td>
    <td><?php echo e(Carbon\Carbon::parse($r->tgl_obatkeluar)->formatLocalized('%d %B %Y')); ?></td>
    <td><?php echo e($r->jml_obatkeluar); ?></td>
    <td><?php echo e($r->cara_pakai); ?></td>
    <td><?php echo e($r->keterangan); ?></td>
    <td>
      <?php if($r->status==0): ?>
        <div align="center">
       <!--  <label class="btn btn-danger active">
        <span class="glyphicon glyphicon-remove" title="Belum Diproses"></span>
        </label> -->
        <span style="background-color: #f73636;padding: 6px;border-radius: 4px;color: #fff;font-size: 11.2px;">Belum diproses</span>
      </div>
      <?php else: ?>
      <div align="center">
  <!--       <label class="btn btn-success active">
        <span class="glyphicon glyphicon-ok" title="Sudah Diproses"></span>
        </label> -->
        <span style="background-color: #66b91a;padding: 6px;border-radius: 4px;color: #fff;font-size: 11.2px;">Sudah diproses</span>
      </div>
      <?php endif; ?>
    </td>

  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

</table>
<?php if($r->status==0): ?>
     <div align="right"><a href="<?php echo e(url('resep_obat/proses/'.$r->id)); ?>" class="btn btn-success" data-toggle="modal" title="Proses Resep"> Proses</a></div>
<?php else: ?>
      <div align="right"><a href="#" class="btn btn-success" disabled data-toggle="modal" title="Sudah Diproses"> Proses</a></div>
<?php endif; ?>

</div>

<script>
$(document).ready(function(){
  $('[data-toggle="modal"]').tooltip();   
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>